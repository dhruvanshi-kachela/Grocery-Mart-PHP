<?php
require_once __DIR__ . '/../config/db.php';

class Address {
    private $db;

    public function __construct() {
        $this->db = getDB();
    }

    /**
     * Get all addresses for a specific user
     * @param int $userId
     * @return array
     */
    public function getByUser($userId) {
        $stmt = $this->db->prepare("SELECT * FROM addresses WHERE user_id = :user_id ORDER BY id DESC");
        $stmt->execute(['user_id' => $userId]);
        return $stmt->fetchAll();
    }

    /**
     * Find a single address by ID and verify user ownership
     * @param int $id
     * @param int $userId
     * @return array|false
     */
    public function findById($id, $userId) {
        $stmt = $this->db->prepare("SELECT * FROM addresses WHERE id = :id AND user_id = :user_id");
        $stmt->execute(['id' => $id, 'user_id' => $userId]);
        return $stmt->fetch();
    }

    /**
     * Add a new shipping address
     * @param int $userId
     * @param string $fullAddress
     * @param string $city
     * @param string $state
     * @param string $zipcode
     * @param string $country Default 'India'
     * @return int|false The inserted address ID
     */
    public function add($userId, $fullAddress, $city, $state, $zipcode, $country = 'India') {
        $stmt = $this->db->prepare("
            INSERT INTO addresses (user_id, full_address, city, state, country, zipcode) 
            VALUES (:user_id, :full_address, :city, :state, :country, :zipcode)
        ");
        
        $result = $stmt->execute([
            'user_id' => $userId,
            'full_address' => htmlspecialchars(strip_tags($fullAddress)),
            'city' => htmlspecialchars(strip_tags($city)),
            'state' => htmlspecialchars(strip_tags($state)),
            'country' => htmlspecialchars(strip_tags($country)),
            'zipcode' => htmlspecialchars(strip_tags($zipcode))
        ]);

        return $result ? $this->db->lastInsertId() : false;
    }

    /**
     * Update an existing address
     */
    public function update($id, $userId, $fullAddress, $city, $state, $zipcode, $country = 'India') {
        $stmt = $this->db->prepare("
            UPDATE addresses 
            SET full_address = :full_address, city = :city, state = :state, country = :country, zipcode = :zipcode 
            WHERE id = :id AND user_id = :user_id
        ");
        
        return $stmt->execute([
            'full_address' => htmlspecialchars(strip_tags($fullAddress)),
            'city' => htmlspecialchars(strip_tags($city)),
            'state' => htmlspecialchars(strip_tags($state)),
            'country' => htmlspecialchars(strip_tags($country)),
            'zipcode' => htmlspecialchars(strip_tags($zipcode)),
            'id' => $id,
            'user_id' => $userId
        ]);
    }

    /**
     * Delete an address
     * @param int $id
     * @param int $userId
     * @return bool
     */
    public function delete($id, $userId) {
        $stmt = $this->db->prepare("DELETE FROM addresses WHERE id = :id AND user_id = :user_id");
        return $stmt->execute(['id' => $id, 'user_id' => $userId]);
    }
}
