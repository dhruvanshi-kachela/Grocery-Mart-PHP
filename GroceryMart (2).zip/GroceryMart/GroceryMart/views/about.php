<?php
$page_title = "About Us";
include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/navbar.php';
?>

<!-- About Hero Section -->
<section class="hero-section py-5 mb-5 text-center text-lg-start">
    <div class="container">
        <div class="row align-items-center g-5">
            <div class="col-lg-6">
                <h1 class="fw-bold mb-4">About <span>GroceryMart</span></h1>
                <p class="lead text-muted mb-4">
                    Founded in 2026, GroceryMart is dedicated to providing high-quality, farm-fresh grocery items and organic farm products at affordable prices.
                </p>
                <p class="text-muted mb-4">
                    We partner directly with local growers, milk dairies, and premium bakeries to ensure that everything delivered to your home represents the highest tier of purity, freshness, and quality.
                </p>
            </div>
            <div class="col-lg-6 text-center">
                <img src="https://images.unsplash.com/photo-1578916171728-46686eac8d58?auto=format&fit=crop&w=600&q=80" alt="About Us" class="img-fluid rounded-4 shadow-lg" style="max-height: 350px; object-fit: cover; width: 100%;">
            </div>
        </div>
    </div>
</section>

<!-- Mission & Vision -->
<div class="container my-5">
    <div class="row g-4 text-center">
        <div class="col-md-6">
            <div class="card card-custom p-5 border-0 h-100 bg-success-subtle text-success-emphasis">
                <div class="category-card-img-wrapper bg-white mb-4" style="width: 70px; height: 70px; display: inline-flex; align-items: center; justify-content: center;">
                    <i class="fa-solid fa-bullseye text-success" style="font-size: 30px;"></i>
                </div>
                <h3 class="fw-bold mb-3">Our Mission</h3>
                <p class="mb-0">
                    To make fresh, organic, and nutritious groceries accessible, affordable, and easily deliverable for every household, ensuring quality and sustainability in every package we pack.
                </p>
            </div>
        </div>
        <div class="col-md-6">
            <div class="card card-custom p-5 border-0 h-100 bg-warning-subtle text-warning-emphasis">
                <div class="category-card-img-wrapper bg-white mb-4" style="width: 70px; height: 70px; display: inline-flex; align-items: center; justify-content: center;">
                    <i class="fa-solid fa-eye text-warning" style="font-size: 30px;"></i>
                </div>
                <h3 class="fw-bold mb-3">Our Vision</h3>
                <p class="mb-0">
                    To become the most customer-centric grocery delivery ecosystem, simulating leading edge logistical speeds, and bridging the gap between local farming and modern convenient lifestyles.
                </p>
            </div>
        </div>
    </div>
</div>

<!-- Values Section -->
<section class="bg-light py-5 my-5">
    <div class="container">
        <div class="text-center mb-5">
            <h3 class="fw-bold">Our Core Values</h3>
            <p class="text-muted">The principles that drive our daily operations</p>
        </div>
        
        <div class="row g-4">
            <div class="col-md-4 text-center">
                <div class="p-4 bg-white rounded-4 shadow-sm border h-100">
                    <i class="fa-solid fa-shield-heart text-success mb-3" style="font-size: 36px;"></i>
                    <h5 class="fw-bold">Quality First</h5>
                    <p class="text-muted small mb-0">We inspect every single piece of fruit, packet of milk, and loaf of bread before it goes out for delivery.</p>
                </div>
            </div>
            <div class="col-md-4 text-center">
                <div class="p-4 bg-white rounded-4 shadow-sm border h-100">
                    <i class="fa-solid fa-people-carry-box text-success mb-3" style="font-size: 36px;"></i>
                    <h5 class="fw-bold">Community Support</h5>
                    <p class="text-muted small mb-0">We pay fair market rates to local farmers and vendors, support local food grids, and minimize waste.</p>
                </div>
            </div>
            <div class="col-md-4 text-center">
                <div class="p-4 bg-white rounded-4 shadow-sm border h-100">
                    <i class="fa-solid fa-lock text-success mb-3" style="font-size: 36px;"></i>
                    <h5 class="fw-bold">Trust & Integrity</h5>
                    <p class="text-muted small mb-0">Secure sessions, encrypted transactions, no hidden delivery fees, and direct refund protocols.</p>
                </div>
            </div>
        </div>
    </div>
</section>

<?php include __DIR__ . '/../includes/footer.php'; ?>
