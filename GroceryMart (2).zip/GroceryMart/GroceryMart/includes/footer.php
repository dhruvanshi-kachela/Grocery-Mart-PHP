<footer class="footer-custom">
    <div class="container">
        <div class="row g-4">
            <!-- About Section -->
            <div class="col-lg-4 col-md-6">
                <h5 class="navbar-brand-custom text-white mb-3">
                    <i class="fa-solid fa-basket-shopping"></i> GroceryMart
                </h5>
                <p class="text-white-50 small mb-3">
                    Your neighborhood grocery store, now online! Sourcing the freshest organic fruits, vegetables, dairy, bakery, staples, and daily essentials delivered right to your doorstep.
                </p>
                <p class="small text-white-50 mb-1"><i class="fa-solid fa-phone me-2 text-warning"></i> +1 (234) 567-890</p>
                <p class="small text-white-50 mb-3"><i class="fa-solid fa-envelope me-2 text-warning"></i> support@grocerymart.com</p>
                <div class="social-icons">
                    <a href="#" class="social-icon-btn"><i class="fa-brands fa-facebook-f"></i></a>
                    <a href="#" class="social-icon-btn"><i class="fa-brands fa-twitter"></i></a>
                    <a href="#" class="social-icon-btn"><i class="fa-brands fa-instagram"></i></a>
                    <a href="#" class="social-icon-btn"><i class="fa-brands fa-linkedin-in"></i></a>
                </div>
            </div>

            <!-- Quick Links -->
            <div class="col-lg-2 col-md-6">
                <h6 class="footer-title">Quick Links</h6>
                <ul class="footer-links">
                    <li><a href="index.php">Home</a></li>
                    <li><a href="shop.php">Shop</a></li>
                    <li><a href="about.php">About Us</a></li>
                    <li><a href="contact.php">Contact Us</a></li>
                    <li><a href="profile.php">My Account</a></li>
                </ul>
            </div>

            <!-- Categories -->
            <div class="col-lg-3 col-md-6">
                <h6 class="footer-title">Popular Categories</h6>
                <ul class="footer-links">
                    <li><a href="shop.php?category=1">Fresh Fruits</a></li>
                    <li><a href="shop.php?category=2">Fresh Vegetables</a></li>
                    <li><a href="shop.php?category=3">Dairy & Eggs</a></li>
                    <li><a href="shop.php?category=4">Bakery & Bread</a></li>
                    <li><a href="shop.php?category=5">Beverages</a></li>
                </ul>
            </div>

            <!-- Newsletter -->
            <div class="col-lg-3 col-md-6">
                <h6 class="footer-title">Newsletter</h6>
                <p class="text-white-50 small mb-3">
                    Subscribe to our newsletter to receive the latest updates, deals, and discount coupon codes directly.
                </p>
                <form action="index.php" method="POST" class="mt-2" onsubmit="event.preventDefault(); alert('Thank you for subscribing to our newsletter!');">
                    <div class="input-group">
                        <input type="email" class="form-control border-0 rounded-start-pill py-2 bg-light text-dark" placeholder="Your Email Address" required>
                        <button class="btn btn-accent-custom rounded-end-pill px-3 py-2 border-0" type="submit">
                            <i class="fa-solid fa-paper-plane"></i>
                        </button>
                    </div>
                </form>
            </div>
        </div>

        <hr class="border-secondary my-4">

        <div class="row align-items-center">
            <div class="col-md-6 text-center text-md-start">
                <p class="small text-white-50 mb-0">
                    &copy; <?php echo date('Y'); ?> GroceryMart. All Rights Reserved. Built as a Final Year University Project.
                </p>
            </div>
            <div class="col-md-6 text-center text-md-end mt-2 mt-md-0">
                <div class="d-inline-flex align-items-center gap-2 flex-wrap justify-content-center justify-content-md-end">
                    <span class="text-white-50 small me-1">Pay with:</span>
                    <span style="background:#1a1f71;color:#fff;font-size:11px;font-weight:800;padding:4px 10px;border-radius:6px;letter-spacing:.5px;">VISA</span>
                    <span style="background:#fff;padding:3px 7px;border-radius:6px;display:inline-flex;align-items:center;gap:0;">
                        <span style="width:14px;height:14px;background:#eb001b;border-radius:50%;display:inline-block;"></span>
                        <span style="width:14px;height:14px;background:#f79e1b;border-radius:50%;display:inline-block;margin-left:-5px;"></span>
                    </span>
                    <span style="background:#003087;color:#fff;font-size:11px;font-weight:800;padding:4px 10px;border-radius:6px;">Pay<span style="color:#009cde;">Pal</span></span>
                    <span style="background:#5a0fc8;color:#fff;font-size:11px;font-weight:700;padding:4px 10px;border-radius:6px;">Stripe</span>
                    <span style="background:#f5f5f5;color:#333;font-size:11px;font-weight:700;padding:4px 10px;border-radius:6px;display:inline-flex;align-items:center;gap:4px;"><i class="fa-solid fa-building-columns" style="color:#555;font-size:10px;"></i>COD</span>
                </div>
            </div>
        </div>
    </div>
</footer>

<!-- Bootstrap 5 Bundle JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<!-- jQuery (Required for AJAX features specified in PRD) -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<!-- Custom JavaScript -->
<script src="assets/js/main.js"></script>
</body>
</html>
