<?php
$page_title = "Customer Dashboard";
include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/navbar.php';
?>

<div class="container my-5">
    <div class="row g-4">
        <!-- Sidebar Navigation -->
        <div class="col-lg-3">
            <div class="dashboard-sidebar text-center mb-4">
                <div class="category-card-img-wrapper mb-3" style="width: 80px; height: 80px; display: inline-flex; align-items: center; justify-content: center; background-color: var(--primary-light);">
                    <i class="fa-regular fa-user text-success" style="font-size: 36px;"></i>
                </div>
                <h5 class="fw-bold mb-1"><?php echo htmlspecialchars($user['name']); ?></h5>
                <p class="text-muted small mb-4"><?php echo htmlspecialchars($user['email']); ?></p>
                <hr class="my-3">
                <div class="text-start">
                    <a href="profile.php?page=dashboard" class="dashboard-menu-link <?php echo $page === 'dashboard' ? 'active' : ''; ?>">
                        <i class="fa-solid fa-gauge"></i> Overview
                    </a>
                    <a href="profile.php?page=orders" class="dashboard-menu-link <?php echo $page === 'orders' ? 'active' : ''; ?>">
                        <i class="fa-solid fa-box-open"></i> My Orders
                    </a>
                    <a href="profile.php?page=addresses" class="dashboard-menu-link <?php echo $page === 'addresses' ? 'active' : ''; ?>">
                        <i class="fa-solid fa-location-dot"></i> Address Book
                    </a>
                    <a href="profile.php?page=profile" class="dashboard-menu-link <?php echo $page === 'profile' ? 'active' : ''; ?>">
                        <i class="fa-solid fa-user-gear"></i> Edit Profile
                    </a>
                    <a href="login.php?logout=1" class="dashboard-menu-link text-danger mt-3">
                        <i class="fa-solid fa-right-from-bracket"></i> Logout
                    </a>
                </div>
            </div>
        </div>

        <!-- Dashboard Content Area -->
        <div class="col-lg-9">
            <!-- 1. OVERVIEW PAGE -->
            <?php if ($page === 'dashboard'): ?>
                <div class="card card-custom p-4 border-light shadow-sm mb-4">
                    <h5 class="fw-bold mb-4">Account Overview</h5>
                    <p class="small text-muted">Welcome, <strong><?php echo htmlspecialchars($user['name']); ?></strong>! From your dashboard, you can track orders, manage addresses, and update account details.</p>
                    
                    <!-- Stats Cards Row -->
                    <div class="row g-3 my-2">
                        <div class="col-md-3 col-sm-6">
                            <div class="p-3 bg-light rounded-4 border text-center">
                                <h2 class="fw-bold text-success mb-1"><?php echo $stats['total_orders']; ?></h2>
                                <span class="text-muted small">Total Orders</span>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-6">
                            <div class="p-3 bg-light rounded-4 border text-center">
                                <h2 class="fw-bold text-warning mb-1"><?php echo $stats['pending_orders']; ?></h2>
                                <span class="text-muted small">Pending Orders</span>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-6">
                            <div class="p-3 bg-light rounded-4 border text-center">
                                <h2 class="fw-bold text-primary mb-1"><?php echo $stats['delivered_orders']; ?></h2>
                                <span class="text-muted small">Delivered</span>
                            </div>
                        </div>
                        <div class="col-md-3 col-sm-6">
                            <div class="p-3 bg-light rounded-4 border text-center">
                                <h2 class="fw-bold text-danger mb-1"><?php echo $stats['wishlist_count']; ?></h2>
                                <span class="text-muted small">Wishlist Size</span>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Recent Orders Preview -->
                <div class="card card-custom p-4 border-light shadow-sm">
                    <div class="d-flex justify-content-between align-items-center mb-4">
                        <h5 class="fw-bold mb-0">Recent Orders</h5>
                        <a href="profile.php?page=orders" class="text-success small fw-semibold text-decoration-none">View All</a>
                    </div>
                    <?php if (!empty($orders)): ?>
                        <div class="table-responsive">
                            <table class="table align-middle small mb-0">
                                <thead>
                                    <tr class="text-muted">
                                        <th scope="col" class="border-0">Order ID</th>
                                        <th scope="col" class="border-0">Date</th>
                                        <th scope="col" class="border-0">Payment</th>
                                        <th scope="col" class="border-0">Total</th>
                                        <th scope="col" class="border-0 text-center">Status</th>
                                        <th scope="col" class="border-0 text-end">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach (array_slice($orders, 0, 3) as $o): ?>
                                        <tr>
                                            <td class="fw-semibold">#GM-<?php echo str_pad($o['id'], 6, '0', STR_PAD_LEFT); ?></td>
                                            <td><?php echo date('d M Y', strtotime($o['created_at'])); ?></td>
                                            <td><?php echo $o['payment_method']; ?> (<?php echo $o['payment_status']; ?>)</td>
                                            <td class="fw-bold text-success"><?php echo formatPrice($o['total']); ?></td>
                                            <td class="text-center">
                                                <span class="badge rounded-pill px-2 py-1 <?php 
                                                    echo $o['order_status'] === 'Delivered' ? 'bg-success-subtle text-success border border-success-subtle' : 
                                                         ($o['order_status'] === 'Cancelled' ? 'bg-danger-subtle text-danger border border-danger-subtle' : 'bg-warning-subtle text-warning border border-warning-subtle'); 
                                                ?>">
                                                    <?php echo $o['order_status']; ?>
                                                </span>
                                            </td>
                                            <td class="text-end">
                                                <a href="profile.php?page=orders&order_id=<?php echo $o['id']; ?>" class="btn btn-outline-primary-custom btn-sm rounded-pill px-2.5 py-1">Track</a>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <p class="text-muted small mb-0 py-3 text-center">No orders placed yet. <a href="shop.php" class="text-success">Browse groceries now!</a></p>
                    <?php endif; ?>
                </div>

            <!-- 2. ORDERS SECTION -->
            <?php elseif ($page === 'orders'): ?>
                <!-- Order details subview -->
                <?php if ($order_details): ?>
                    <div class="card card-custom p-4 border-light shadow-sm mb-4">
                        <div class="d-flex justify-content-between align-items-center mb-4 border-bottom pb-3">
                            <h5 class="fw-bold mb-0">Order Details: #GM-<?php echo str_pad($order_details['id'], 6, '0', STR_PAD_LEFT); ?></h5>
                            <a href="profile.php?page=orders" class="btn btn-outline-secondary btn-sm rounded-pill"><i class="fa-solid fa-arrow-left me-1"></i> Back to History</a>
                        </div>
                        
                        <!-- Tracking Stepper UI Timeline -->
                        <?php if ($order_details['order_status'] === 'Cancelled'): ?>
                            <div class="alert alert-danger alert-custom mb-4" role="alert">
                                <i class="fa-solid fa-circle-xmark me-2"></i> This order was cancelled. Restocked inventory was returned to the shelves.
                            </div>
                        <?php else: 
                            $status_stages = ['Placed', 'Packed', 'Shipped', 'Out for Delivery', 'Delivered'];
                            $current_index = array_search($order_details['order_status'], $status_stages);
                            if ($current_index === false) $current_index = 0;
                        ?>
                            <div class="order-tracking-stepper">
                                <div class="step-item <?php echo $current_index >= 0 ? 'completed' : ''; ?> <?php echo $current_index == 0 ? 'active' : ''; ?>">
                                    <div class="step-icon-box"><i class="fa-solid fa-receipt"></i></div>
                                    <span class="step-title">Placed</span>
                                </div>
                                <div class="step-item <?php echo $current_index >= 1 ? 'completed' : ''; ?> <?php echo $current_index == 1 ? 'active' : ''; ?>">
                                    <div class="step-icon-box"><i class="fa-solid fa-box"></i></div>
                                    <span class="step-title">Packed</span>
                                </div>
                                <div class="step-item <?php echo $current_index >= 2 ? 'completed' : ''; ?> <?php echo $current_index == 2 ? 'active' : ''; ?>">
                                    <div class="step-icon-box"><i class="fa-solid fa-truck"></i></div>
                                    <span class="step-title">Shipped</span>
                                </div>
                                <div class="step-item <?php echo $current_index >= 3 ? 'completed' : ''; ?> <?php echo $current_index == 3 ? 'active' : ''; ?>">
                                    <div class="step-icon-box"><i class="fa-solid fa-truck-ramp-box"></i></div>
                                    <span class="step-title">Out for Delivery</span>
                                </div>
                                <div class="step-item <?php echo $current_index >= 4 ? 'completed' : ''; ?> <?php echo $current_index == 4 ? 'active' : ''; ?>">
                                    <div class="step-icon-box"><i class="fa-solid fa-house-chimney-user"></i></div>
                                    <span class="step-title">Delivered</span>
                                </div>
                            </div>
                        <?php endif; ?>

                        <!-- Items details list -->
                        <h6 class="fw-bold mb-3">Products Purchased</h6>
                        <div class="table-responsive mb-4">
                            <table class="table align-middle small table-bordered mb-0">
                                <thead class="bg-light text-muted">
                                    <tr>
                                        <th>Product</th>
                                        <th class="text-center">Weight</th>
                                        <th class="text-center">Price</th>
                                        <th class="text-center">Quantity</th>
                                        <th class="text-end">Subtotal</th>
                                        <th class="text-center">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($order_items as $item): ?>
                                        <tr>
                                            <td>
                                                <div class="d-flex align-items-center gap-2">
                                                    <img src="<?php echo getProductImage($item['image'], $item['name']); ?>" alt="" style="width: 40px; height: 40px; object-fit: contain;" class="rounded border p-1">
                                                    <span class="fw-semibold text-dark"><?php echo htmlspecialchars($item['name']); ?></span>
                                                </div>
                                            </td>
                                            <td class="text-center"><?php echo htmlspecialchars($item['weight'] ?? '1 unit'); ?></td>
                                            <td class="text-center"><?php echo formatPrice($item['price']); ?></td>
                                            <td class="text-center"><?php echo $item['quantity']; ?></td>
                                            <td class="text-end fw-bold text-success"><?php echo formatPrice($item['price'] * $item['quantity']); ?></td>
                                            <td class="text-center">
                                                <a href="product.php?id=<?php echo $item['product_id']; ?>#reviewsSection" class="btn btn-outline-success btn-sm rounded-pill py-0.5 px-2.5" style="font-size: 11px;">Review</a>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>

                        <!-- Summary calculations and shipping location -->
                        <div class="row g-4 pt-3 border-top">
                            <div class="col-md-7">
                                <h6 class="fw-bold mb-2">Delivery Details</h6>
                                <p class="text-muted small mb-1"><strong>Receiver Name:</strong> <?php echo htmlspecialchars($user['name']); ?></p>
                                <p class="text-muted small mb-1"><strong>Mobile Number:</strong> <?php echo htmlspecialchars($user['mobile']); ?></p>
                                <p class="text-muted small mb-0"><strong>Address:</strong> <?php echo htmlspecialchars($order_details['full_address']); ?>, <?php echo htmlspecialchars($order_details['city']); ?>, <?php echo htmlspecialchars($order_details['state']); ?> - <?php echo htmlspecialchars($order_details['zipcode']); ?></p>
                            </div>
                            <div class="col-md-5 bg-light p-3 rounded-4 border border-light">
                                <div class="d-flex justify-content-between mb-2 small text-muted">
                                    <span>Discount Saved:</span>
                                    <span class="text-danger fw-bold">- <?php echo formatPrice($order_details['discount']); ?></span>
                                </div>
                                <div class="d-flex justify-content-between mb-2 fs-6 fw-bold">
                                    <span class="text-dark">Total Paid:</span>
                                    <span class="text-success"><?php echo formatPrice($order_details['total']); ?></span>
                                </div>
                                <div class="d-flex justify-content-between mb-0 small text-muted">
                                    <span>Payment Method:</span>
                                    <span class="text-dark fw-bold"><?php echo $order_details['payment_method']; ?></span>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php else: ?>
                    <!-- Orders History list Table -->
                    <div class="card card-custom p-4 border-light shadow-sm">
                        <h5 class="fw-bold mb-4">My Orders History</h5>
                        
                        <?php if (!empty($orders)): ?>
                            <div class="table-responsive">
                                <table class="table align-middle small mb-0">
                                    <thead>
                                        <tr class="text-muted">
                                            <th scope="col" class="border-0">Order ID</th>
                                            <th scope="col" class="border-0">Date</th>
                                            <th scope="col" class="border-0">Payment Method</th>
                                            <th scope="col" class="border-0">Total</th>
                                            <th scope="col" class="border-0 text-center">Status</th>
                                            <th scope="col" class="border-0 text-end">Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($orders as $o): ?>
                                            <tr>
                                                <td class="fw-semibold">#GM-<?php echo str_pad($o['id'], 6, '0', STR_PAD_LEFT); ?></td>
                                                <td><?php echo date('d M Y', strtotime($o['created_at'])); ?></td>
                                                <td><?php echo $o['payment_method']; ?> (<?php echo $o['payment_status']; ?>)</td>
                                                <td class="fw-bold text-success"><?php echo formatPrice($o['total']); ?></td>
                                                <td class="text-center">
                                                    <span class="badge rounded-pill px-2 py-1 <?php 
                                                        echo $o['order_status'] === 'Delivered' ? 'bg-success-subtle text-success border border-success-subtle' : 
                                                             ($o['order_status'] === 'Cancelled' ? 'bg-danger-subtle text-danger border border-danger-subtle' : 'bg-warning-subtle text-warning border border-warning-subtle'); 
                                                    ?>">
                                                        <?php echo $o['order_status']; ?>
                                                    </span>
                                                </td>
                                                <td class="text-end">
                                                    <div class="d-inline-flex gap-2">
                                                        <a href="profile.php?page=orders&order_id=<?php echo $o['id']; ?>" class="btn btn-primary-custom btn-sm rounded-pill px-2.5 py-1" style="font-size: 11px;">Track</a>
                                                        <?php if (in_array($o['order_status'], ['Placed', 'Packed'])): ?>
                                                            <a href="profile.php?cancel_order=<?php echo $o['id']; ?>" onclick="return confirm('Are you sure you want to cancel this order? This will restore inventory stocks.')" class="btn btn-outline-danger btn-sm rounded-pill px-2.5 py-1" style="font-size: 11px;">Cancel</a>
                                                        <?php endif; ?>
                                                    </div>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php else: ?>
                            <p class="text-muted small mb-0 py-3 text-center">You have placed no orders yet. <a href="shop.php" class="text-success">Browse groceries now!</a></p>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>

            <!-- 3. ADDRESS BOOK CRUD -->
            <?php elseif ($page === 'addresses'): ?>
                <div class="card card-custom p-4 border-light shadow-sm mb-4">
                    <div class="d-flex justify-content-between align-items-center mb-4">
                        <h5 class="fw-bold mb-0">My Saved Addresses</h5>
                        <!-- Trigger add form -->
                        <button class="btn btn-primary-custom btn-sm rounded-pill px-3" type="button" data-bs-toggle="collapse" data-bs-target="#addAddressForm" aria-expanded="false" aria-controls="addAddressForm">
                            <i class="fa-solid fa-plus me-1"></i> Add Address
                        </button>
                    </div>

                    <!-- Add Address Collapse Form -->
                    <div class="collapse mb-4" id="addAddressForm">
                        <div class="card p-4 rounded-4 border border-light bg-light">
                            <h6 class="fw-bold mb-3">Add Shipping Location</h6>
                            <form action="profile.php?page=addresses" method="POST" class="needs-validation" novalidate>
                                <input type="hidden" name="action" value="add_address">
                                <div class="mb-3">
                                    <label for="full_address" class="form-label small fw-medium">Street Address / Landmark</label>
                                    <input type="text" class="form-control bg-white border-0 py-2" id="full_address" name="full_address" required placeholder="e.g. Apartment/Villa, Area Name">
                                    <div class="invalid-feedback">Address is required.</div>
                                </div>
                                <div class="row g-3 mb-3">
                                    <div class="col-md-4">
                                        <label for="city" class="form-label small fw-medium">City</label>
                                        <input type="text" class="form-control bg-white border-0 py-2" id="city" name="city" required placeholder="e.g. Bangalore">
                                        <div class="invalid-feedback">City is required.</div>
                                    </div>
                                    <div class="col-md-4">
                                        <label for="state" class="form-label small fw-medium">State</label>
                                        <input type="text" class="form-control bg-white border-0 py-2" id="state" name="state" required placeholder="e.g. Karnataka">
                                        <div class="invalid-feedback">State is required.</div>
                                    </div>
                                    <div class="col-md-4">
                                        <label for="zipcode" class="form-label small fw-medium">PIN / Zip Code</label>
                                        <input type="text" class="form-control bg-white border-0 py-2" id="zipcode" name="zipcode" required placeholder="e.g. 560103">
                                        <div class="invalid-feedback">Zipcode is required.</div>
                                    </div>
                                </div>
                                <button type="submit" class="btn btn-success rounded-pill px-4">Save Location</button>
                            </form>
                        </div>
                    </div>

                    <!-- Addresses Cards List -->
                    <?php if (!empty($addresses)): ?>
                        <div class="row g-3">
                            <?php foreach ($addresses as $index => $addr): ?>
                                <div class="col-md-6" id="address-block-<?php echo $addr['id']; ?>">
                                    <div class="card p-3 rounded-4 border border-light bg-light h-100 d-flex flex-column justify-content-between">
                                        <div>
                                            <h6 class="fw-bold text-dark small mb-2"><i class="fa-solid fa-location-arrow text-success me-1"></i> Address #<?php echo $index + 1; ?></h6>
                                            <p class="text-muted small mb-0 font-monospace">
                                                <?php echo htmlspecialchars($addr['full_address']); ?>, <br>
                                                <?php echo htmlspecialchars($addr['city']); ?>, <?php echo htmlspecialchars($addr['state']); ?> - <?php echo htmlspecialchars($addr['zipcode']); ?>
                                            </p>
                                        </div>
                                        <div class="d-flex gap-2 mt-3 pt-2 border-top border-secondary-subtle">
                                            <button class="btn btn-sm btn-outline-success border-0 rounded-circle" type="button" data-bs-toggle="collapse" data-bs-target="#editFormCollapse_<?php echo $addr['id']; ?>"><i class="fa-regular fa-pen-to-square"></i></button>
                                            <a href="profile.php?delete_address=<?php echo $addr['id']; ?>" onclick="return confirm('Delete this address?')" class="btn btn-sm btn-outline-danger border-0 rounded-circle"><i class="fa-regular fa-trash-can"></i></a>
                                        </div>

                                        <!-- Edit Address Form Collapse -->
                                        <div class="collapse mt-3" id="editFormCollapse_<?php echo $addr['id']; ?>">
                                            <form action="profile.php?page=addresses" method="POST" class="needs-validation mt-2" novalidate>
                                                <input type="hidden" name="action" value="edit_address">
                                                <input type="hidden" name="address_id" value="<?php echo $addr['id']; ?>">
                                                <div class="mb-2">
                                                    <input type="text" class="form-control form-control-sm bg-white" name="full_address" required value="<?php echo htmlspecialchars($addr['full_address']); ?>">
                                                </div>
                                                <div class="row g-2 mb-2">
                                                    <div class="col-4"><input type="text" class="form-control form-control-sm bg-white" name="city" required value="<?php echo htmlspecialchars($addr['city']); ?>"></div>
                                                    <div class="col-4"><input type="text" class="form-control form-control-sm bg-white" name="state" required value="<?php echo htmlspecialchars($addr['state']); ?>"></div>
                                                    <div class="col-4"><input type="text" class="form-control form-control-sm bg-white" name="zipcode" required value="<?php echo htmlspecialchars($addr['zipcode']); ?>"></div>
                                                </div>
                                                <button type="submit" class="btn btn-success btn-xs rounded-pill px-3 py-1 font-size-11">Update</button>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php else: ?>
                        <p class="text-muted small py-4 text-center">No addresses saved. Click Add Address to configure shipping locations.</p>
                    <?php endif; ?>
                </div>

            <!-- 4. EDIT PROFILE SECTION -->
            <?php elseif ($page === 'profile'): ?>
                <div class="card card-custom p-4 border-light shadow-sm">
                    <h5 class="fw-bold mb-4">Edit Profile Information</h5>
                    
                    <form action="profile.php?page=profile" method="POST" class="needs-validation" novalidate>
                        <input type="hidden" name="action" value="update_profile">
                        
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label for="name" class="form-label small fw-medium">Full Name</label>
                                <input type="text" class="form-control bg-light border-0 py-2" id="name" name="name" required value="<?php echo htmlspecialchars($user['name']); ?>">
                                <div class="invalid-feedback">Name is required.</div>
                            </div>
                            
                            <div class="col-md-6">
                                <label for="mobile" class="form-label small fw-medium">Mobile Number</label>
                                <input type="tel" class="form-control bg-light border-0 py-2" id="mobile" name="mobile" required pattern="[0-9]{10}" value="<?php echo htmlspecialchars($user['mobile']); ?>">
                                <small class="form-text text-muted">10 digits without leading zeros.</small>
                                <div class="invalid-feedback">A valid 10 digit mobile is required.</div>
                            </div>

                            <div class="col-md-12 pt-3 border-top mt-4">
                                <h6 class="fw-bold mb-2">Reset Password (Optional)</h6>
                                <p class="text-muted small">Enter a new password below if you wish to reset your current login password.</p>
                            </div>

                            <div class="col-md-6">
                                <label for="password" class="form-label small fw-medium">New Password</label>
                                <input type="password" class="form-control bg-light border-0 py-2" id="password" name="password" minlength="8" placeholder="Enter at least 8 characters">
                                <div class="invalid-feedback">Password must be at least 8 characters.</div>
                            </div>
                        </div>

                        <button type="submit" class="btn btn-primary-custom rounded-pill mt-4 px-4 py-2">Update Profile</button>
                    </form>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>
