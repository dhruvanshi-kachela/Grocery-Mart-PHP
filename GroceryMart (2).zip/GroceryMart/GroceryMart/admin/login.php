<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../controllers/AuthController.php';

$auth = new AuthController();

// Handle admin logout if requested
if (isset($_GET['logout'])) {
    $auth->adminLogout();
}

// Redirect to dashboard if already logged in as admin
if (isset($_SESSION['admin_id']) || (isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'admin')) {
    header("Location: dashboard.php");
    exit();
}

$auth->adminLogin();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login — GroceryMart Control Panel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">

    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }

        body {
            font-family: 'Inter', sans-serif;
            min-height: 100vh;
            display: flex;
            overflow: hidden;
            background: #0d1117;
        }

        /* ── Left Branding Panel ── */
        .brand-panel {
            width: 52%;
            min-height: 100vh;
            background: linear-gradient(145deg, #1a3a2a 0%, #2d5a3d 40%, #1e4a30 70%, #0f2d1c 100%);
            position: relative;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: flex-start;
            padding: 60px 56px;
            overflow: hidden;
        }

        /* Decorative circles */
        .brand-panel::before {
            content: '';
            position: absolute;
            top: -120px; right: -120px;
            width: 420px; height: 420px;
            border-radius: 50%;
            background: radial-gradient(circle, rgba(76,175,80,0.18) 0%, transparent 70%);
        }
        .brand-panel::after {
            content: '';
            position: absolute;
            bottom: -80px; left: -80px;
            width: 320px; height: 320px;
            border-radius: 50%;
            background: radial-gradient(circle, rgba(46,125,50,0.2) 0%, transparent 70%);
        }

        .brand-logo {
            font-size: 32px;
            font-weight: 800;
            color: #fff;
            letter-spacing: -0.5px;
            display: flex;
            align-items: center;
            gap: 12px;
            margin-bottom: 56px;
            position: relative;
            z-index: 2;
        }
        .brand-logo .logo-icon {
            width: 52px; height: 52px;
            background: linear-gradient(135deg, #4CAF50, #66BB6A);
            border-radius: 16px;
            display: flex; align-items: center; justify-content: center;
            font-size: 22px;
            box-shadow: 0 8px 24px rgba(76,175,80,0.4);
        }

        .brand-headline {
            font-size: 42px;
            font-weight: 800;
            color: #fff;
            line-height: 1.15;
            letter-spacing: -1px;
            margin-bottom: 20px;
            position: relative;
            z-index: 2;
        }
        .brand-headline span {
            background: linear-gradient(135deg, #69F0AE, #00E676);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }

        .brand-sub {
            font-size: 15px;
            color: rgba(255,255,255,0.6);
            line-height: 1.7;
            max-width: 380px;
            margin-bottom: 48px;
            position: relative;
            z-index: 2;
        }

        .feature-pills {
            display: flex;
            flex-direction: column;
            gap: 14px;
            position: relative;
            z-index: 2;
        }
        .feature-pill {
            display: flex;
            align-items: center;
            gap: 14px;
            background: rgba(255,255,255,0.07);
            border: 1px solid rgba(255,255,255,0.1);
            border-radius: 14px;
            padding: 14px 18px;
            backdrop-filter: blur(10px);
            transition: background 0.2s;
        }
        .feature-pill:hover { background: rgba(255,255,255,0.11); }
        .feature-pill .pill-icon {
            width: 38px; height: 38px;
            background: linear-gradient(135deg, rgba(76,175,80,0.3), rgba(102,187,106,0.2));
            border-radius: 10px;
            display: flex; align-items: center; justify-content: center;
            color: #69F0AE;
            font-size: 16px;
            flex-shrink: 0;
        }
        .feature-pill .pill-text strong { color: #fff; font-size: 13px; display: block; margin-bottom: 2px; }
        .feature-pill .pill-text span   { color: rgba(255,255,255,0.5); font-size: 12px; }

        /* Floating grocery icons */
        .float-icon {
            position: absolute;
            font-size: 28px;
            opacity: 0.06;
            animation: floatAnim 6s ease-in-out infinite;
            z-index: 1;
        }
        .float-icon:nth-child(1) { top: 8%;  right: 12%; animation-delay: 0s;   font-size: 36px; }
        .float-icon:nth-child(2) { top: 22%; right: 6%;  animation-delay: 1.2s; font-size: 24px; }
        .float-icon:nth-child(3) { top: 45%; right: 16%; animation-delay: 0.6s; font-size: 30px; }
        .float-icon:nth-child(4) { top: 65%; right: 8%;  animation-delay: 2s;   font-size: 22px; }
        .float-icon:nth-child(5) { top: 80%; right: 20%; animation-delay: 1.5s; font-size: 28px; }
        @keyframes floatAnim {
            0%,100% { transform: translateY(0px) rotate(0deg); }
            50%      { transform: translateY(-14px) rotate(5deg); }
        }

        /* ── Right Login Panel ── */
        .login-panel {
            width: 48%;
            min-height: 100vh;
            background: #0d1117;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            padding: 48px 40px;
            position: relative;
        }
        .login-panel::before {
            content: '';
            position: absolute;
            top: 0; left: 0; right: 0; bottom: 0;
            background: radial-gradient(ellipse at 60% 20%, rgba(46,125,50,0.12) 0%, transparent 60%);
            pointer-events: none;
        }

        .login-card {
            width: 100%;
            max-width: 420px;
            position: relative;
            z-index: 2;
        }

        .login-title {
            font-size: 28px;
            font-weight: 800;
            color: #fff;
            letter-spacing: -0.5px;
            margin-bottom: 6px;
        }
        .login-subtitle {
            color: rgba(255,255,255,0.45);
            font-size: 14px;
            margin-bottom: 36px;
        }

        /* Form inputs */
        .input-group-admin {
            background: rgba(255,255,255,0.05);
            border: 1px solid rgba(255,255,255,0.1);
            border-radius: 14px;
            overflow: hidden;
            transition: border-color 0.2s, box-shadow 0.2s;
            display: flex;
            align-items: center;
        }
        .input-group-admin:focus-within {
            border-color: #4CAF50;
            box-shadow: 0 0 0 3px rgba(76,175,80,0.15);
        }
        .input-group-admin .icon-box {
            width: 48px;
            display: flex; align-items: center; justify-content: center;
            color: rgba(255,255,255,0.3);
            font-size: 15px;
            flex-shrink: 0;
        }
        .input-group-admin input {
            flex: 1;
            background: transparent;
            border: none;
            outline: none;
            color: #fff;
            font-family: 'Inter', sans-serif;
            font-size: 14px;
            padding: 14px 16px 14px 0;
        }
        .input-group-admin input::placeholder { color: rgba(255,255,255,0.25); }
        .input-group-admin .toggle-pw {
            width: 44px;
            display: flex; align-items: center; justify-content: center;
            color: rgba(255,255,255,0.3);
            cursor: pointer;
            font-size: 14px;
            transition: color 0.2s;
            background: transparent;
            border: none;
        }
        .input-group-admin .toggle-pw:hover { color: #4CAF50; }

        .form-label-admin {
            color: rgba(255,255,255,0.65);
            font-size: 12px;
            font-weight: 600;
            letter-spacing: 0.5px;
            text-transform: uppercase;
            margin-bottom: 8px;
            display: block;
        }

        /* Sign In button */
        .btn-signin {
            width: 100%;
            background: linear-gradient(135deg, #2E7D32, #4CAF50);
            border: none;
            border-radius: 14px;
            color: #fff;
            font-family: 'Inter', sans-serif;
            font-size: 15px;
            font-weight: 700;
            padding: 15px;
            cursor: pointer;
            transition: all 0.25s;
            position: relative;
            overflow: hidden;
            letter-spacing: 0.3px;
            box-shadow: 0 4px 20px rgba(76,175,80,0.35);
        }
        .btn-signin:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 28px rgba(76,175,80,0.45);
        }
        .btn-signin:active { transform: translateY(0); }

        /* Alert styles */
        .alert-admin {
            border-radius: 12px;
            border: none;
            font-size: 13px;
            padding: 12px 16px;
            display: flex;
            align-items: center;
            gap: 10px;
            margin-bottom: 20px;
        }
        .alert-admin.success { background: rgba(76,175,80,0.15); color: #69F0AE; border: 1px solid rgba(76,175,80,0.25); }
        .alert-admin.error   { background: rgba(244,67,54,0.12);  color: #ff8a80; border: 1px solid rgba(244,67,54,0.25); }

        /* Credentials hint */
        .cred-hint {
            background: rgba(255,255,255,0.04);
            border: 1px solid rgba(255,255,255,0.08);
            border-radius: 12px;
            padding: 14px 18px;
            margin-top: 28px;
        }
        .cred-hint p { color: rgba(255,255,255,0.35); font-size: 12px; margin: 0 0 4px; }
        .cred-hint code {
            color: #69F0AE;
            background: rgba(76,175,80,0.12);
            border-radius: 6px;
            padding: 2px 8px;
            font-size: 12px;
            user-select: all;
        }

        .back-link {
            display: inline-flex; align-items: center; gap: 6px;
            color: rgba(255,255,255,0.35);
            font-size: 13px;
            text-decoration: none;
            margin-top: 24px;
            transition: color 0.2s;
        }
        .back-link:hover { color: #4CAF50; }

        /* Responsive */
        @media (max-width: 900px) {
            body { flex-direction: column; overflow: auto; }
            .brand-panel { width: 100%; min-height: auto; padding: 40px 30px 36px; }
            .brand-headline { font-size: 30px; }
            .login-panel { width: 100%; padding: 40px 24px 56px; }
            .feature-pills { flex-direction: row; flex-wrap: wrap; }
            .float-icon { display: none; }
        }
    </style>
</head>
<body>

    <!-- ── Left Brand Panel ── -->
    <div class="brand-panel">
        <!-- Floating decorative icons -->
        <i class="fa-solid fa-basket-shopping float-icon" style="color:#fff;"></i>
        <i class="fa-solid fa-leaf float-icon" style="color:#fff;"></i>
        <i class="fa-solid fa-apple-whole float-icon" style="color:#fff;"></i>
        <i class="fa-solid fa-carrot float-icon" style="color:#fff;"></i>
        <i class="fa-solid fa-wheat-awn float-icon" style="color:#fff;"></i>

        <!-- Logo -->
        <div class="brand-logo">
            <div class="logo-icon">
                <i class="fa-solid fa-basket-shopping"></i>
            </div>
            GroceryMart
        </div>

        <!-- Headline -->
        <h1 class="brand-headline">
            Admin<br><span>Control Centre</span>
        </h1>

        <p class="brand-sub">
            Manage your entire grocery store from one powerful dashboard — products, orders, inventory, coupons and customer queries.
        </p>

        <!-- Feature pills -->
        <div class="feature-pills">
            <div class="feature-pill">
                <div class="pill-icon"><i class="fa-solid fa-chart-line"></i></div>
                <div class="pill-text">
                    <strong>Real-time Analytics</strong>
                    <span>Revenue, orders & customer insights</span>
                </div>
            </div>
            <div class="feature-pill">
                <div class="pill-icon"><i class="fa-solid fa-boxes-packing"></i></div>
                <div class="pill-text">
                    <strong>Inventory Management</strong>
                    <span>Low-stock alerts & quick restock</span>
                </div>
            </div>
            <div class="feature-pill">
                <div class="pill-icon"><i class="fa-solid fa-clipboard-list"></i></div>
                <div class="pill-text">
                    <strong>Order Fulfilment</strong>
                    <span>Track & update every order status</span>
                </div>
            </div>
        </div>
    </div>

    <!-- ── Right Login Panel ── -->
    <div class="login-panel">
        <div class="login-card">

            <h2 class="login-title">Welcome back 👋</h2>
            <p class="login-subtitle">Sign in to your admin panel to continue</p>

            <!-- Flash Messages -->
            <?php if (isset($_SESSION['success'])): ?>
                <div class="alert-admin success">
                    <i class="fa-solid fa-circle-check"></i>
                    <?php echo htmlspecialchars($_SESSION['success']); unset($_SESSION['success']); ?>
                </div>
            <?php endif; ?>
            <?php if (isset($_SESSION['error'])): ?>
                <div class="alert-admin error">
                    <i class="fa-solid fa-circle-exclamation"></i>
                    <?php echo htmlspecialchars($_SESSION['error']); unset($_SESSION['error']); ?>
                </div>
            <?php endif; ?>

            <!-- Login Form -->
            <form action="login.php" method="POST" id="adminLoginForm" novalidate>

                <div class="mb-4">
                    <label class="form-label-admin">Email Address</label>
                    <div class="input-group-admin">
                        <div class="icon-box"><i class="fa-regular fa-envelope"></i></div>
                        <input
                            type="email"
                            name="email"
                            id="adminEmail"
                            placeholder="admin@grocerymart.com"
                            autocomplete="email"
                            required
                        >
                    </div>
                </div>

                <div class="mb-5">
                    <label class="form-label-admin">Password</label>
                    <div class="input-group-admin">
                        <div class="icon-box"><i class="fa-solid fa-lock"></i></div>
                        <input
                            type="password"
                            name="password"
                            id="adminPassword"
                            placeholder="Enter your password"
                            autocomplete="current-password"
                            required
                        >
                        <button type="button" class="toggle-pw" onclick="togglePassword()" title="Show / Hide Password">
                            <i class="fa-regular fa-eye" id="toggleIcon"></i>
                        </button>
                    </div>
                </div>

                <button type="submit" class="btn-signin" id="signinBtn">
                    <i class="fa-solid fa-right-to-bracket me-2"></i> Sign In to Admin Panel
                </button>
            </form>

            <!-- Credentials hint -->
            <div class="cred-hint">
                <p><i class="fa-solid fa-circle-info me-1"></i> Default Admin Credentials</p>
                <div class="d-flex gap-3 flex-wrap mt-1">
                    <span>Email: <code>admin@grocerymart.com</code></span>
                    <span>Password: <code>admin123</code></span>
                </div>
            </div>

            <a href="../index.php" class="back-link">
                <i class="fa-solid fa-arrow-left"></i> Back to Public Website
            </a>
        </div>
    </div>

    <script>
        // Toggle password visibility
        function togglePassword() {
            const input = document.getElementById('adminPassword');
            const icon  = document.getElementById('toggleIcon');
            if (input.type === 'password') {
                input.type = 'text';
                icon.classList.replace('fa-eye', 'fa-eye-slash');
            } else {
                input.type = 'password';
                icon.classList.replace('fa-eye-slash', 'fa-eye');
            }
        }

        // Submit button loading state
        document.getElementById('adminLoginForm').addEventListener('submit', function(e) {
            const email    = document.getElementById('adminEmail').value.trim();
            const password = document.getElementById('adminPassword').value.trim();
            if (!email || !password) { e.preventDefault(); return; }
            const btn = document.getElementById('signinBtn');
            btn.innerHTML = '<i class="fa-solid fa-circle-notch fa-spin me-2"></i> Signing in...';
            btn.disabled  = true;
        });
    </script>

</body>
</html>
