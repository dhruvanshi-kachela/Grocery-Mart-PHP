<?php
$page_title = "Coupons Manager";
require_once __DIR__ . '/../includes/admin-header.php';
require_once __DIR__ . '/../includes/admin-sidebar.php';
require_once __DIR__ . '/../models/Coupon.php';

$couponModel = new Coupon();

// ── Handle POST ───────────────────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    // ADD
    if ($action === 'add') {
        $code           = strtoupper(trim($_POST['code']           ?? ''));
        $discount       = floatval($_POST['discount']              ?? 0);
        $minimum_amount = floatval($_POST['minimum_amount']        ?? 0);
        $expiry_date    = trim($_POST['expiry_date']               ?? '');

        if (empty($code) || $discount <= 0 || empty($expiry_date)) {
            $_SESSION['error'] = "Code, discount, and expiry date are required.";
        } else {
            $ok = $couponModel->create($code, $discount, $minimum_amount, $expiry_date);
            $_SESSION[$ok ? 'success' : 'error'] = $ok ? "Coupon '{$code}' created!" : "Failed — code may already exist.";
        }
        header("Location: coupons.php"); exit();
    }

    // EDIT
    if ($action === 'edit') {
        $id             = intval($_POST['coupon_id']               ?? 0);
        $code           = strtoupper(trim($_POST['code']           ?? ''));
        $discount       = floatval($_POST['discount']              ?? 0);
        $minimum_amount = floatval($_POST['minimum_amount']        ?? 0);
        $expiry_date    = trim($_POST['expiry_date']               ?? '');
        $status         = intval($_POST['status']                  ?? 1);

        if ($id > 0 && !empty($code) && $discount > 0 && !empty($expiry_date)) {
            $ok = $couponModel->update($id, $code, $discount, $minimum_amount, $expiry_date, $status);
            $_SESSION[$ok ? 'success' : 'error'] = $ok ? "Coupon updated!" : "Failed to update coupon.";
        } else {
            $_SESSION['error'] = "Invalid coupon data.";
        }
        header("Location: coupons.php"); exit();
    }
}

// DELETE
if (isset($_GET['delete_id'])) {
    $id = intval($_GET['delete_id']);
    if ($id > 0) {
        $ok = $couponModel->delete($id);
        $_SESSION[$ok ? 'success' : 'error'] = $ok ? "Coupon deleted." : "Failed to delete.";
    }
    header("Location: coupons.php"); exit();
}

$coupons = $couponModel->getAllCoupons();
$today   = date('Y-m-d');
?>

<!-- Header -->
<div class="d-flex justify-content-between align-items-center mb-4">
    <h5 class="fw-bold mb-0"><i class="fa-solid fa-tags text-success me-2"></i>Coupons Manager</h5>
    <button class="btn btn-primary-custom btn-sm rounded-pill px-3" data-bs-toggle="collapse" data-bs-target="#addCouponForm">
        <i class="fa-solid fa-plus me-1"></i> Add Coupon
    </button>
</div>

<!-- Add Coupon Form -->
<div class="collapse mb-4" id="addCouponForm">
    <div class="card p-4 rounded-4 border bg-light shadow-sm">
        <h6 class="fw-bold mb-3">Create New Coupon</h6>
        <form action="coupons.php" method="POST">
            <input type="hidden" name="action" value="add">
            <div class="row g-3">
                <div class="col-md-3"><label class="form-label small fw-medium">Coupon Code *</label>
                    <input type="text" class="form-control text-uppercase" name="code" required placeholder="e.g. SAVE50" style="letter-spacing:1px;"></div>
                <div class="col-md-3"><label class="form-label small fw-medium">Discount Amount (₹) *</label>
                    <input type="number" class="form-control" name="discount" required min="1" step="0.01" placeholder="50.00"></div>
                <div class="col-md-3"><label class="form-label small fw-medium">Minimum Order (₹)</label>
                    <input type="number" class="form-control" name="minimum_amount" min="0" step="0.01" value="0"></div>
                <div class="col-md-3"><label class="form-label small fw-medium">Expiry Date *</label>
                    <input type="date" class="form-control" name="expiry_date" required min="<?php echo $today; ?>"></div>
            </div>
            <button type="submit" class="btn btn-success rounded-pill px-4 mt-3">Create Coupon</button>
        </form>
    </div>
</div>

<!-- Coupons Table -->
<div class="card card-custom p-4 border-0 shadow-sm bg-white">
    <?php if (!empty($coupons)): ?>
        <div class="table-responsive">
            <table class="table align-middle small mb-0">
                <thead>
                    <tr class="text-muted">
                        <th>Code</th>
                        <th class="text-center">Discount (₹)</th>
                        <th class="text-center">Min. Order (₹)</th>
                        <th class="text-center">Expiry</th>
                        <th class="text-center">Status</th>
                        <th class="text-end">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($coupons as $c): 
                        $expired = $c['expiry_date'] < $today;
                    ?>
                        <tr>
                            <td><code class="fw-bold text-success fs-6" style="letter-spacing:1px;"><?php echo htmlspecialchars($c['code']); ?></code></td>
                            <td class="text-center fw-bold"><?php echo formatPrice($c['discount']); ?></td>
                            <td class="text-center text-muted"><?php echo $c['minimum_amount'] > 0 ? formatPrice($c['minimum_amount']) : '—'; ?></td>
                            <td class="text-center">
                                <span class="<?php echo $expired ? 'text-danger fw-semibold' : 'text-muted'; ?>">
                                    <?php echo date('d M Y', strtotime($c['expiry_date'])); ?>
                                    <?php if ($expired): ?><small>(Expired)</small><?php endif; ?>
                                </span>
                            </td>
                            <td class="text-center">
                                <span class="badge rounded-pill border <?php echo $c['status'] == 1 && !$expired ? 'bg-success-subtle text-success border-success-subtle' : 'bg-secondary-subtle text-secondary border-secondary-subtle'; ?>">
                                    <?php echo $c['status'] == 1 && !$expired ? 'Active' : 'Inactive'; ?>
                                </span>
                            </td>
                            <td class="text-end">
                                <div class="d-inline-flex gap-2">
                                    <button class="btn btn-sm btn-outline-success border-0 rounded-circle" data-bs-toggle="collapse" data-bs-target="#editCoupon_<?php echo $c['id']; ?>" title="Edit">
                                        <i class="fa-regular fa-pen-to-square"></i>
                                    </button>
                                    <a href="coupons.php?delete_id=<?php echo $c['id']; ?>" onclick="return confirm('Delete coupon <?php echo htmlspecialchars($c['code']); ?>?')" class="btn btn-sm btn-outline-danger border-0 rounded-circle" title="Delete">
                                        <i class="fa-regular fa-trash-can"></i>
                                    </a>
                                </div>
                                <!-- Inline edit collapse -->
                                <div class="collapse text-start mt-3" id="editCoupon_<?php echo $c['id']; ?>">
                                    <div class="card p-3 bg-light border rounded-4" style="min-width:300px;">
                                        <form action="coupons.php" method="POST">
                                            <input type="hidden" name="action"    value="edit">
                                            <input type="hidden" name="coupon_id" value="<?php echo $c['id']; ?>">
                                            <div class="mb-2">
                                                <label class="form-label small fw-medium">Code</label>
                                                <input type="text" class="form-control form-control-sm text-uppercase" name="code" required value="<?php echo htmlspecialchars($c['code']); ?>">
                                            </div>
                                            <div class="row g-2 mb-2">
                                                <div class="col-6"><label class="form-label small fw-medium">Discount (₹)</label>
                                                    <input type="number" class="form-control form-control-sm" name="discount" step="0.01" required value="<?php echo $c['discount']; ?>"></div>
                                                <div class="col-6"><label class="form-label small fw-medium">Min. Order (₹)</label>
                                                    <input type="number" class="form-control form-control-sm" name="minimum_amount" step="0.01" value="<?php echo $c['minimum_amount']; ?>"></div>
                                                <div class="col-6"><label class="form-label small fw-medium">Expiry Date</label>
                                                    <input type="date" class="form-control form-control-sm" name="expiry_date" required value="<?php echo $c['expiry_date']; ?>"></div>
                                                <div class="col-6"><label class="form-label small fw-medium">Status</label>
                                                    <select class="form-select form-select-sm" name="status">
                                                        <option value="1" <?php echo $c['status']==1?'selected':''; ?>>Active</option>
                                                        <option value="0" <?php echo $c['status']==0?'selected':''; ?>>Inactive</option>
                                                    </select></div>
                                            </div>
                                            <button type="submit" class="btn btn-success btn-sm rounded-pill px-3">Update</button>
                                        </form>
                                    </div>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php else: ?>
        <div class="text-center py-5 text-muted">
            <i class="fa-solid fa-tags fs-1 mb-3 d-block opacity-25"></i>
            <p class="mb-0">No coupons created yet.</p>
        </div>
    <?php endif; ?>
</div>

<?php require_once __DIR__ . '/../includes/admin-footer.php'; ?>
