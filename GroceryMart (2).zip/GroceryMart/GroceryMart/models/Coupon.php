<?php
require_once __DIR__ . '/../config/db.php';

class Coupon {
    private $db;

    public function __construct() {
        $this->db = getDB();
    }

    /**
     * Find a coupon by code
     * @param string $code
     * @return array|false
     */
    public function findByCode($code) {
        $stmt = $this->db->prepare("SELECT * FROM coupons WHERE code = :code");
        $stmt->execute(['code' => strtoupper(trim($code))]);
        return $stmt->fetch();
    }

    /**
     * Validate if coupon is applicable
     * @param array $coupon Coupon row
     * @param float $subtotal Current subtotal
     * @return array [bool 'valid', string 'message']
     */
    public function validate($coupon, $subtotal) {
        if (!$coupon) {
            return ['valid' => false, 'message' => 'Invalid coupon code.'];
        }

        if ($coupon['status'] != 1) {
            return ['valid' => false, 'message' => 'This coupon is inactive.'];
        }

        // Check expiry date
        $today = date('Y-m-d');
        if ($coupon['expiry_date'] < $today) {
            return ['valid' => false, 'message' => 'This coupon has expired.'];
        }

        // Check minimum amount
        if ($subtotal < $coupon['minimum_amount']) {
            return ['valid' => false, 'message' => 'Minimum purchase of ₹' . number_format($coupon['minimum_amount'], 2) . ' is required to apply this coupon.'];
        }

        return ['valid' => true, 'message' => 'Coupon applied successfully!'];
    }

    /**
     * Get all coupons (for admin CRUD)
     * @return array
     */
    public function getAllCoupons() {
        $stmt = $this->db->query("SELECT * FROM coupons ORDER BY id DESC");
        return $stmt->fetchAll();
    }

    /**
     * Create coupon (admin CRUD)
     */
    public function create($code, $discount, $minimum_amount, $expiry_date) {
        $stmt = $this->db->prepare("
            INSERT INTO coupons (code, discount, minimum_amount, expiry_date, status) 
            VALUES (:code, :discount, :minimum_amount, :expiry_date, 1)
        ");
        return $stmt->execute([
            'code' => strtoupper(trim($code)),
            'discount' => floatval($discount),
            'minimum_amount' => floatval($minimum_amount),
            'expiry_date' => $expiry_date
        ]);
    }

    /**
     * Update coupon (admin CRUD)
     */
    public function update($id, $code, $discount, $minimum_amount, $expiry_date, $status) {
        $stmt = $this->db->prepare("
            UPDATE coupons 
            SET code = :code, discount = :discount, minimum_amount = :minimum_amount, 
                expiry_date = :expiry_date, status = :status 
            WHERE id = :id
        ");
        return $stmt->execute([
            'code' => strtoupper(trim($code)),
            'discount' => floatval($discount),
            'minimum_amount' => floatval($minimum_amount),
            'expiry_date' => $expiry_date,
            'status' => intval($status),
            'id' => $id
        ]);
    }

    /**
     * Delete coupon (admin CRUD)
     * @param int $id
     * @return bool
     */
    public function delete($id) {
        $stmt = $this->db->prepare("DELETE FROM coupons WHERE id = :id");
        return $stmt->execute(['id' => $id]);
    }
}
