<?php
require_once __DIR__ . '/../models/Cart.php';
require_once __DIR__ . '/../includes/utils.php';
require_once __DIR__ . '/../models/Wishlist.php';
require_once __DIR__ . '/../models/Product.php';
require_once __DIR__ . '/../models/Coupon.php';

class CartController {
    private $cartModel;
    private $wishlistModel;
    private $productModel;
    private $couponModel;

    public function __construct() {
        $this->cartModel = new Cart();
        $this->wishlistModel = new Wishlist();
        $this->productModel = new Product();
        $this->couponModel = new Coupon();
    }

    /**
     * Render the Cart view page
     */
    public function cart() {
        if (session_status() == PHP_SESSION_NONE) {
            session_start();
        }

        // Fetch cart items based on auth state
        $cart_items = $this->getCartItemsHelper();

        // Calculate pricing details
        $subtotal = 0;
        foreach ($cart_items as $item) {
            $price = getDiscountedPrice($item['price'], $item['discount']);
            $subtotal += ($price * $item['quantity']);
        }

        // Shipping policy: Free above ₹499, else ₹40
        $shipping = ($subtotal >= 499.00 || $subtotal == 0) ? 0.00 : 40.00;

        // Apply coupon discount if set in session
        $coupon_discount = 0.00;
        $coupon_code = '';
        if (isset($_SESSION['applied_coupon'])) {
            $coupon_code = $_SESSION['applied_coupon']['code'];
            $coupon = $this->couponModel->findByCode($coupon_code);
            $validation = $this->couponModel->validate($coupon, $subtotal);
            if ($validation['valid']) {
                $coupon_discount = floatval($coupon['discount']);
            } else {
                // If coupon became invalid (e.g. subtotal drops below minimum purchase), remove it
                unset($_SESSION['applied_coupon']);
            }
        }

        $total = ($subtotal + $shipping) - $coupon_discount;
        if ($total < 0) $total = 0;

        // Load cart view
        include __DIR__ . '/../views/cart.php';
    }

    /**
     * AJAX Endpoint - Process Cart Operations (Add, Update, Delete, Coupon)
     */
    public function handleCartAjax() {
        if (session_status() == PHP_SESSION_NONE) {
            session_start();
        }

        $action = $_POST['action'] ?? '';
        $productId = intval($_POST['product_id'] ?? 0);
        $quantity = intval($_POST['quantity'] ?? 1);

        $response = ['success' => false, 'message' => 'Invalid Request'];

        if ($action === 'add') {
            // Check product exists
            $product = $this->productModel->findById($productId);
            if (!$product) {
                $response['message'] = "Product not found.";
                echo json_encode($response);
                exit();
            }

            // Check stock availability
            $requestedQty = $quantity;
            $currentCartQty = $this->getProductQuantityInCartHelper($productId);
            $totalRequested = $requestedQty + $currentCartQty;

            if ($product['stock'] < $totalRequested) {
                $response['message'] = "Cannot add requested quantity. Only {$product['stock']} units are in stock, and you have {$currentCartQty} in your cart.";
                echo json_encode($response);
                exit();
            }

            // Execute add
            if (isset($_SESSION['user_id'])) {
                $result = $this->cartModel->add($_SESSION['user_id'], $productId, $quantity);
            } else {
                // Guest session cart
                if (!isset($_SESSION['cart'])) {
                    $_SESSION['cart'] = [];
                }
                if (isset($_SESSION['cart'][$productId])) {
                    $_SESSION['cart'][$productId] += $quantity;
                } else {
                    $_SESSION['cart'][$productId] = $quantity;
                }
                $result = true;
            }

            if ($result) {
                $response['success'] = true;
                $response['message'] = "Added to cart!";
                $response['cart_count'] = $this->getCartCountHelper();
            } else {
                $response['message'] = "Failed to add product to cart.";
            }
        } 
        
        elseif ($action === 'update') {
            $product = $this->productModel->findById($productId);
            if (!$product) {
                $response['message'] = "Product not found.";
                echo json_encode($response);
                exit();
            }

            // Check stock limits
            if ($product['stock'] < $quantity) {
                $response['message'] = "Cannot update quantity. Only {$product['stock']} units are in stock.";
                echo json_encode($response);
                exit();
            }

            // Execute update
            if (isset($_SESSION['user_id'])) {
                $result = $this->cartModel->update($_SESSION['user_id'], $productId, $quantity);
            } else {
                if ($quantity <= 0) {
                    unset($_SESSION['cart'][$productId]);
                } else {
                    $_SESSION['cart'][$productId] = $quantity;
                }
                $result = true;
            }

            if ($result) {
                $response['success'] = true;
                $response['message'] = "Cart updated successfully!";
                $response['cart_count'] = $this->getCartCountHelper();
            } else {
                $response['message'] = "Failed to update cart.";
            }
        } 
        
        elseif ($action === 'delete') {
            if (isset($_SESSION['user_id'])) {
                $result = $this->cartModel->delete($_SESSION['user_id'], $productId);
            } else {
                unset($_SESSION['cart'][$productId]);
                $result = true;
            }

            if ($result) {
                $response['success'] = true;
                $response['message'] = "Removed from cart.";
                $response['cart_count'] = $this->getCartCountHelper();
            } else {
                $response['message'] = "Failed to remove item.";
            }
        }

        echo json_encode($response);
        exit();
    }

    /**
     * POST Action - Apply coupon code
     */
    public function applyCoupon() {
        if (session_status() == PHP_SESSION_NONE) {
            session_start();
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $couponCode = trim($_POST['coupon_code'] ?? '');
            if (empty($couponCode)) {
                $_SESSION['error'] = "Please enter a coupon code.";
                header("Location: cart.php");
                exit();
            }

            $coupon = $this->couponModel->findByCode($couponCode);
            
            // Fetch cart items to calculate subtotal
            $cart_items = $this->getCartItemsHelper();
            $subtotal = 0;
            foreach ($cart_items as $item) {
                $subtotal += (getDiscountedPrice($item['price'], $item['discount']) * $item['quantity']);
            }

            $validation = $this->couponModel->validate($coupon, $subtotal);
            if ($validation['valid']) {
                $_SESSION['applied_coupon'] = [
                    'code' => $coupon['code'],
                    'discount' => floatval($coupon['discount'])
                ];
                $_SESSION['success'] = "Coupon code '{$coupon['code']}' applied successfully! You saved ₹" . number_format($coupon['discount'], 2);
            } else {
                $_SESSION['error'] = $validation['message'];
            }

            header("Location: cart.php");
            exit();
        }
    }

    /**
     * POST Action - Remove applied coupon code
     */
    public function removeCoupon() {
        if (session_status() == PHP_SESSION_NONE) {
            session_start();
        }
        unset($_SESSION['applied_coupon']);
        $_SESSION['success'] = "Coupon removed.";
        header("Location: cart.php");
        exit();
    }

    /**
     * Render the Wishlist view page
     */
    public function wishlist() {
        if (session_status() == PHP_SESSION_NONE) {
            session_start();
        }

        // Wishlists require customer login
        if (!isset($_SESSION['user_id'])) {
            $_SESSION['error'] = "Please log in to view your wishlist.";
            header("Location: login.php");
            exit();
        }

        $wishlist_items = $this->wishlistModel->getItems($_SESSION['user_id']);

        // Load wishlist view
        include __DIR__ . '/../views/wishlist.php';
    }

    /**
     * AJAX Endpoint - Toggle Wishlist Item
     */
    public function handleWishlistAjax() {
        if (session_status() == PHP_SESSION_NONE) {
            session_start();
        }

        if (!isset($_SESSION['user_id'])) {
            // Unauthenticated wishlist toggle redirect trigger
            echo json_encode([
                'success' => false,
                'message' => 'Please log in to manage your wishlist.',
                'redirect' => 'login.php'
            ]);
            exit();
        }

        $productId = intval($_POST['product_id'] ?? 0);
        $action = $_POST['action'] ?? '';

        if ($productId <= 0 || $action !== 'toggle') {
            echo json_encode(['success' => false, 'message' => 'Invalid params']);
            exit();
        }

        $status = $this->wishlistModel->toggle($_SESSION['user_id'], $productId);
        
        // Fetch current wishlist count
        $db = getDB();
        $stmt = $db->prepare("SELECT COUNT(*) FROM wishlist WHERE user_id = :uid");
        $stmt->execute(['uid' => $_SESSION['user_id']]);
        $wishlist_count = intval($stmt->fetchColumn());

        echo json_encode([
            'success' => true,
            'message' => $status === 'added' ? 'Product added to wishlist!' : 'Product removed from wishlist.',
            'status' => $status,
            'wishlist_count' => $wishlist_count
        ]);
        exit();
    }


    // PRIVATE HELPERS

    private function getCartItemsHelper() {
        if (isset($_SESSION['user_id'])) {
            return $this->cartModel->getItems($_SESSION['user_id']);
        } else {
            $cart_items = [];
            if (isset($_SESSION['cart']) && !empty($_SESSION['cart'])) {
                foreach ($_SESSION['cart'] as $pid => $qty) {
                    $prod = $this->productModel->findById($pid);
                    if ($prod) {
                        $cart_items[] = [
                            'product_id' => $pid,
                            'quantity' => $qty,
                            'name' => $prod['name'],
                            'price' => $prod['price'],
                            'discount' => $prod['discount'],
                            'stock' => $prod['stock'],
                            'weight' => $prod['weight'],
                            'unit' => $prod['unit'],
                            'image' => $prod['image'],
                            'brand' => $prod['brand']
                        ];
                    }
                }
            }
            return $cart_items;
        }
    }

    private function getProductQuantityInCartHelper($productId) {
        if (isset($_SESSION['user_id'])) {
            $db = getDB();
            $stmt = $db->prepare("SELECT quantity FROM cart WHERE user_id = :uid AND product_id = :pid");
            $stmt->execute(['uid' => $_SESSION['user_id'], 'pid' => $productId]);
            return intval($stmt->fetchColumn());
        } else {
            return intval($_SESSION['cart'][$productId] ?? 0);
        }
    }

    private function getCartCountHelper() {
        $count = 0;
        if (isset($_SESSION['user_id'])) {
            $db = getDB();
            $stmt = $db->prepare("SELECT SUM(quantity) FROM cart WHERE user_id = :uid");
            $stmt->execute(['uid' => $_SESSION['user_id']]);
            $count = intval($stmt->fetchColumn());
        } else {
            if (isset($_SESSION['cart'])) {
                foreach ($_SESSION['cart'] as $qty) {
                    $count += intval($qty);
                }
            }
        }
        return $count;
    }
}
