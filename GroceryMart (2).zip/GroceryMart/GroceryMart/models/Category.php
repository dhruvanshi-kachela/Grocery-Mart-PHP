<?php
require_once __DIR__ . '/../config/db.php';

class Category {
    private $db;

    public function __construct() {
        $this->db = getDB();
    }

    /**
     * Get all active categories
     * @return array
     */
    public function getActiveCategories() {
        $stmt = $this->db->prepare("SELECT * FROM categories WHERE status = 1 ORDER BY name ASC");
        $stmt->execute();
        return $stmt->fetchAll();
    }

    /**
     * Get all categories (for admin)
     * @return array
     */
    public function getAllCategories() {
        $stmt = $this->db->prepare("SELECT * FROM categories ORDER BY id DESC");
        $stmt->execute();
        return $stmt->fetchAll();
    }

    /**
     * Find a category by ID
     * @param int $id
     * @return array|false
     */
    public function findById($id) {
        $stmt = $this->db->prepare("SELECT * FROM categories WHERE id = :id");
        $stmt->execute(['id' => $id]);
        return $stmt->fetch();
    }

    /**
     * Create a new category (admin)
     * @param string $name
     * @param string|null $image
     * @return int|false
     */
    public function create($name, $image = null) {
        $stmt = $this->db->prepare("INSERT INTO categories (name, image, status) VALUES (:name, :image, 1)");
        $result = $stmt->execute([
            'name' => htmlspecialchars(strip_tags($name)),
            'image' => $image
        ]);
        return $result ? $this->db->lastInsertId() : false;
    }

    /**
     * Update a category (admin)
     * @param int $id
     * @param string $name
     * @param string|null $image
     * @param int $status
     * @return bool
     */
    public function update($id, $name, $image = null, $status = 1) {
        if ($image) {
            $stmt = $this->db->prepare("
                UPDATE categories 
                SET name = :name, image = :image, status = :status 
                WHERE id = :id
            ");
            return $stmt->execute([
                'name' => htmlspecialchars(strip_tags($name)),
                'image' => $image,
                'status' => $status,
                'id' => $id
            ]);
        } else {
            $stmt = $this->db->prepare("
                UPDATE categories 
                SET name = :name, status = :status 
                WHERE id = :id
            ");
            return $stmt->execute([
                'name' => htmlspecialchars(strip_tags($name)),
                'status' => $status,
                'id' => $id
            ]);
        }
    }

    /**
     * Delete a category (admin)
     * @param int $id
     * @return bool
     */
    public function delete($id) {
        $stmt = $this->db->prepare("DELETE FROM categories WHERE id = :id");
        return $stmt->execute(['id' => $id]);
    }
}
