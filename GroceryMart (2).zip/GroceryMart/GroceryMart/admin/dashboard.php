<?php
$page_title = "Admin Dashboard";
require_once __DIR__ . '/../includes/admin-header.php';
require_once __DIR__ . '/../includes/admin-sidebar.php';

// Instantiate models or perform queries
$db = getDB();

// 1. Total statistics
$total_orders = intval($db->query("SELECT COUNT(*) FROM orders")->fetchColumn());
$total_revenue = floatval($db->query("SELECT COALESCE(SUM(total), 0) FROM orders WHERE order_status != 'Cancelled'")->fetchColumn());
$total_customers = intval($db->query("SELECT COUNT(*) FROM users WHERE role = 'customer'")->fetchColumn());
$low_stock_count = intval($db->query("SELECT COUNT(*) FROM products WHERE stock <= 10")->fetchColumn());

// 2. Recent orders list
$stmt_recent = $db->query("
    SELECT o.id, o.total, o.order_status, o.payment_method, o.created_at, u.name as user_name 
    FROM orders o
    JOIN users u ON o.user_id = u.id
    ORDER BY o.id DESC
    LIMIT 5
");
$recent_orders = $stmt_recent->fetchAll();

// 3. Low stock details
$stmt_low = $db->query("
    SELECT id, name, stock, unit, weight 
    FROM products 
    WHERE stock <= 10 AND status = 1 
    ORDER BY stock ASC 
    LIMIT 5
");
$low_stock_items = $stmt_low->fetchAll();

// 4. Chart 1 - Category distribution (Pie Chart)
$stmt_cat_chart = $db->query("
    SELECT c.name, COUNT(p.id) as count 
    FROM categories c 
    LEFT JOIN products p ON c.id = p.category_id 
    GROUP BY c.id
");
$cat_chart_data = $stmt_cat_chart->fetchAll();
$cat_labels = [];
$cat_counts = [];
foreach ($cat_chart_data as $row) {
    $cat_labels[] = $row['name'];
    $cat_counts[] = intval($row['count']);
}

// 5. Chart 2 - Monthly Sales (Bar Chart)
$stmt_sales_chart = $db->query("
    SELECT DATE_FORMAT(created_at, '%M %Y') as month, SUM(total) as revenue 
    FROM orders 
    WHERE order_status != 'Cancelled' 
    GROUP BY DATE_FORMAT(created_at, '%Y-%m') 
    ORDER BY created_at ASC 
    LIMIT 6
");
$sales_chart_data = $stmt_sales_chart->fetchAll();
$sales_labels = [];
$sales_revenue = [];
foreach ($sales_chart_data as $row) {
    $sales_labels[] = $row['month'];
    $sales_revenue[] = floatval($row['revenue']);
}

// Handle Quick Restock POST Action
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'restock') {
    $prodId = intval($_POST['product_id'] ?? 0);
    $qty = intval($_POST['quantity'] ?? 0);
    if ($prodId > 0 && $qty > 0) {
        $stmt_restock = $db->prepare("UPDATE products SET stock = stock + :qty WHERE id = :id");
        $stmt_restock->execute(['qty' => $qty, 'id' => $prodId]);
        $_SESSION['success'] = "Inventory stock successfully added!";
    } else {
        $_SESSION['error'] = "Invalid stock amount.";
    }
    header("Location: dashboard.php");
    exit();
}
?>

<!-- Analytics Stats Cards Row -->
<div class="row g-3 mb-4">
    <!-- Revenue -->
    <div class="col-md-3">
        <div class="card p-3 rounded-4 border-0 shadow-sm text-white" style="background: linear-gradient(135deg, #2E7D32, #4CAF50);">
            <div class="d-flex align-items-center justify-content-between">
                <div>
                    <span class="small opacity-75 d-block mb-1">Total Revenue</span>
                    <h3 class="fw-bold mb-0"><?php echo formatPrice($total_revenue); ?></h3>
                </div>
                <i class="fa-solid fa-coins fs-2 opacity-50"></i>
            </div>
        </div>
    </div>
    <!-- Orders -->
    <div class="col-md-3">
        <div class="card p-3 rounded-4 border-0 shadow-sm text-white" style="background: linear-gradient(135deg, #E65100, #FF9800);">
            <div class="d-flex align-items-center justify-content-between">
                <div>
                    <span class="small opacity-75 d-block mb-1">Total Orders</span>
                    <h3 class="fw-bold mb-0"><?php echo $total_orders; ?></h3>
                </div>
                <i class="fa-solid fa-dolly fs-2 opacity-50"></i>
            </div>
        </div>
    </div>
    <!-- Customers -->
    <div class="col-md-3">
        <div class="card p-3 rounded-4 border-0 shadow-sm text-white" style="background: linear-gradient(135deg, #1565C0, #2196F3);">
            <div class="d-flex align-items-center justify-content-between">
                <div>
                    <span class="small opacity-75 d-block mb-1">Registered Customers</span>
                    <h3 class="fw-bold mb-0"><?php echo $total_customers; ?></h3>
                </div>
                <i class="fa-solid fa-users fs-2 opacity-50"></i>
            </div>
        </div>
    </div>
    <!-- Low Stock -->
    <div class="col-md-3">
        <div class="card p-3 rounded-4 border-0 shadow-sm text-white" style="background: linear-gradient(135deg, #C62828, #F44336);">
            <div class="d-flex align-items-center justify-content-between">
                <div>
                    <span class="small opacity-75 d-block mb-1">Low Stock Alerts</span>
                    <h3 class="fw-bold mb-0"><?php echo $low_stock_count; ?></h3>
                </div>
                <i class="fa-solid fa-triangle-exclamation fs-2 opacity-50"></i>
            </div>
        </div>
    </div>
</div>

<!-- Charts Section -->
<div class="row g-4 mb-4">
    <!-- Monthly Sales Bar Chart -->
    <div class="col-lg-8">
        <div class="card card-custom p-4 border-0 shadow-sm h-100 bg-white">
            <h6 class="fw-bold mb-3"><i class="fa-solid fa-chart-simple text-success me-2"></i>Store Sales Performance</h6>
            <div style="position: relative; height:280px; width:100%">
                <canvas id="salesChart"></canvas>
            </div>
        </div>
    </div>
    <!-- Category distribution Pie Chart -->
    <div class="col-lg-4">
        <div class="card card-custom p-4 border-0 shadow-sm h-100 bg-white">
            <h6 class="fw-bold mb-3"><i class="fa-solid fa-chart-pie text-success me-2"></i>Product Shares by Category</h6>
            <div style="position: relative; height:280px; width:100%; display: flex; align-items: center; justify-content: center;">
                <canvas id="categoryChart"></canvas>
            </div>
        </div>
    </div>
</div>

<div class="row g-4">
    <!-- Recent Orders Fulfillment Table -->
    <div class="col-lg-7">
        <div class="card card-custom p-4 border-0 shadow-sm bg-white h-100">
            <h6 class="fw-bold mb-4"><i class="fa-solid fa-clock-rotate-left text-success me-2"></i>Recent Orders</h6>
            
            <?php if (!empty($recent_orders)): ?>
                <div class="table-responsive">
                    <table class="table align-middle small mb-0">
                        <thead>
                            <tr class="text-muted">
                                <th scope="col" class="border-0">Order ID</th>
                                <th scope="col" class="border-0">Customer</th>
                                <th scope="col" class="border-0">Total</th>
                                <th scope="col" class="border-0 text-center">Status</th>
                                <th scope="col" class="border-0 text-end">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($recent_orders as $o): ?>
                                <tr>
                                    <td class="fw-bold">#GM-<?php echo str_pad($o['id'], 6, '0', STR_PAD_LEFT); ?></td>
                                    <td><?php echo htmlspecialchars($o['user_name']); ?></td>
                                    <td class="fw-bold text-success"><?php echo formatPrice($o['total']); ?></td>
                                    <td class="text-center">
                                        <span class="badge rounded-pill px-2 py-1 <?php 
                                            echo $o['order_status'] === 'Delivered' ? 'bg-success-subtle text-success border border-success-subtle' : 
                                                 ($o['order_status'] === 'Cancelled' ? 'bg-danger-subtle text-danger border border-danger-subtle' : 'bg-warning-subtle text-warning border border-warning-subtle'); 
                                        ?>">
                                            <?php echo $o['order_status']; ?>
                                        </span>
                                    </td>
                                    <td class="text-end">
                                        <a href="orders.php?order_id=<?php echo $o['id']; ?>" class="btn btn-primary-custom btn-xs rounded-pill px-2 py-0.5">Details</a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <p class="text-muted py-4 text-center small mb-0">No orders received yet.</p>
            <?php endif; ?>
        </div>
    </div>

    <!-- Inventory Replenishment Alert Panel -->
    <div class="col-lg-5">
        <div class="card card-custom p-4 border-0 shadow-sm bg-white h-100">
            <h6 class="fw-bold mb-4 text-danger"><i class="fa-solid fa-triangle-exclamation me-2"></i>Critical Low Stock Items</h6>
            
            <?php if (!empty($low_stock_items)): ?>
                <div class="d-flex flex-column gap-3">
                    <?php foreach ($low_stock_items as $item): ?>
                        <div class="bg-light p-3 rounded-4 border d-flex align-items-center justify-content-between">
                            <div>
                                <span class="fw-bold small d-block mb-1 text-dark"><?php echo htmlspecialchars($item['name']); ?> (<?php echo htmlspecialchars($item['weight']); ?>)</span>
                                <span class="badge bg-danger rounded-pill px-2 py-1 small" style="font-size: 10px;">Stock: <?php echo $item['stock']; ?> <?php echo htmlspecialchars($item['unit']); ?> left</span>
                            </div>
                            <!-- Restock Form -->
                            <form action="dashboard.php" method="POST" class="d-flex gap-2 align-items-center">
                                <input type="hidden" name="action" value="restock">
                                <input type="hidden" name="product_id" value="<?php echo $item['id']; ?>">
                                <input type="number" class="form-control form-control-sm text-center py-1" name="quantity" min="5" value="20" required style="width: 60px;">
                                <button type="submit" class="btn btn-sm btn-primary-custom py-1 px-2.5 rounded-pill" title="Add Stock"><i class="fa-solid fa-plus"></i></button>
                            </form>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <div class="text-center py-4 bg-success-subtle text-success rounded-4 p-4 border border-success-subtle">
                    <i class="fa-solid fa-circle-check fs-2 mb-2 d-block"></i>
                    <p class="small mb-0 fw-semibold">All products have healthy inventory levels above warning thresholds.</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Chart.js Libraries and charts setups -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
document.addEventListener("DOMContentLoaded", function() {
    // 1. Bar Chart: Store Sales
    const salesCtx = document.getElementById('salesChart').getContext('2d');
    new Chart(salesCtx, {
        type: 'bar',
        data: {
            labels: <?php echo json_encode(!empty($sales_labels) ? $sales_labels : ['No Sales']); ?>,
            datasets: [{
                label: 'Monthly Revenue (₹)',
                data: <?php echo json_encode(!empty($sales_revenue) ? $sales_revenue : [0]); ?>,
                backgroundColor: 'rgba(46, 125, 50, 0.7)',
                borderColor: '#2E7D32',
                borderWidth: 2,
                borderRadius: 8
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    grid: { color: '#f0f0f0' }
                },
                x: { grid: { display: false } }
            }
        }
    });

    // 2. Pie Chart: Categories distribution
    const catCtx = document.getElementById('categoryChart').getContext('2d');
    new Chart(catCtx, {
        type: 'doughnut',
        data: {
            labels: <?php echo json_encode($cat_labels); ?>,
            datasets: [{
                data: <?php echo json_encode($cat_counts); ?>,
                backgroundColor: [
                    '#2E7D32', '#4CAF50', '#8BC34A', '#CDDC39', 
                    '#FFEB3B', '#FFC107', '#FF9800', '#FF5722'
                ],
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { position: 'bottom', labels: { boxWidth: 10, font: { size: 10 } } }
            }
        }
    });
});
</script>

<?php 
require_once __DIR__ . '/../includes/admin-footer.php'; 
?>
