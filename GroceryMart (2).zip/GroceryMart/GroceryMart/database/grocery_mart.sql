-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 15, 2026 at 09:07 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `grocery_mart`
--

-- --------------------------------------------------------

--
-- Table structure for table `addresses`
--

CREATE TABLE `addresses` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `full_address` varchar(255) NOT NULL,
  `city` varchar(100) NOT NULL,
  `state` varchar(100) NOT NULL,
  `country` varchar(100) DEFAULT 'India',
  `zipcode` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `addresses`
--

INSERT INTO `addresses` (`id`, `user_id`, `full_address`, `city`, `state`, `country`, `zipcode`) VALUES
(1, 1, 'Apt 4B, Green Glen Layout', 'Bangalore', 'Karnataka', 'India', '560103'),
(2, 1, 'House 12, Park Street', 'Kolkata', 'West Bengal', 'India', '700016'),
(3, 2, 'Flat 102, Sunrise Towers, Sector 62', 'Noida', 'Uttar Pradesh', 'India', '201301');

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `name`, `email`, `password`, `created_at`) VALUES
(1, 'System Admin', 'admin@grocerymart.com', '$2y$10$QPA3fmhkFs6OAmvpBtscteiqvx4ij.w5Q0ZKJAXUZZod09ftrQY7m', '2026-09-15 17:43:45');

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `status` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`, `image`, `status`, `created_at`) VALUES
(1, 'Fresh Fruits', 'fruits.png', 1, '2026-09-15 17:43:45'),
(2, 'Fresh Vegetables', 'vegetables.png', 1, '2026-09-15 17:43:45'),
(3, 'Dairy & Eggs', 'dairy.png', 1, '2026-09-15 17:43:45'),
(4, 'Bakery & Bread', 'bakery.png', 1, '2026-09-15 17:43:45'),
(5, 'Beverages', 'beverages.png', 1, '2026-09-15 17:43:45'),
(6, 'Snacks & Munchies', 'snacks.png', 1, '2026-09-15 17:43:45'),
(7, 'Staples & Spices', 'staples.png', 1, '2026-09-15 17:43:45'),
(8, 'Household & Cleaning', 'cleaning.png', 1, '2026-09-15 17:43:45'),
(9, 'dsfdsgfd', 'cat_1789494528.jpg', 1, '2026-09-15 17:48:48');

-- --------------------------------------------------------

--
-- Table structure for table `contact_messages`
--

CREATE TABLE `contact_messages` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `message` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `coupons`
--

CREATE TABLE `coupons` (
  `id` int(11) NOT NULL,
  `code` varchar(50) NOT NULL,
  `discount` decimal(10,2) NOT NULL,
  `minimum_amount` decimal(10,2) DEFAULT 0.00,
  `expiry_date` date NOT NULL,
  `status` tinyint(1) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `coupons`
--

INSERT INTO `coupons` (`id`, `code`, `discount`, `minimum_amount`, `expiry_date`, `status`) VALUES
(1, 'WELCOME50', 50.00, 299.00, '2027-12-31', 1),
(2, 'SAVEMORE100', 100.00, 599.00, '2027-12-31', 1),
(3, 'FESTIVE200', 200.00, 999.00, '2027-12-31', 1);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `address_id` int(11) DEFAULT NULL,
  `total` decimal(10,2) NOT NULL,
  `discount` decimal(10,2) DEFAULT 0.00,
  `payment_method` varchar(50) DEFAULT 'COD',
  `payment_status` varchar(50) DEFAULT 'Pending',
  `order_status` varchar(50) DEFAULT 'Placed',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `user_id`, `address_id`, `total`, `discount`, `payment_method`, `payment_status`, `order_status`, `created_at`) VALUES
(1, 1, 1, 340.00, 50.00, 'COD', 'Pending', 'Cancelled', '2026-09-15 18:12:35');

-- --------------------------------------------------------

--
-- Table structure for table `order_items`
--

CREATE TABLE `order_items` (
  `id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `price` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `order_items`
--

INSERT INTO `order_items` (`id`, `order_id`, `product_id`, `quantity`, `price`) VALUES
(1, 1, 1, 2, 135.00),
(2, 1, 4, 2, 40.00);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `category_id` int(11) DEFAULT NULL,
  `name` varchar(200) NOT NULL,
  `description` text DEFAULT NULL,
  `price` decimal(10,2) NOT NULL,
  `discount` decimal(5,2) DEFAULT 0.00,
  `stock` int(11) DEFAULT 0,
  `brand` varchar(100) DEFAULT NULL,
  `unit` varchar(20) DEFAULT 'kg',
  `weight` varchar(50) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `status` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `category_id`, `name`, `description`, `price`, `discount`, `stock`, `brand`, `unit`, `weight`, `image`, `status`, `created_at`) VALUES
(1, 1, 'Organic Red Apples', 'Crisp and sweet organic Washington apples, perfect for snacking or pies.', 150.00, 10.00, 50, 'FreshFarm', 'kg', '1 kg', 'apple.png', 1, '2026-09-15 17:43:45'),
(2, 1, 'Fresh Banana (Robusta)', 'High-energy sweet bananas. Perfect daily dose of potassium.', 60.00, 0.00, 120, 'Local', 'dozen', '12 units', 'banana.png', 1, '2026-09-15 17:43:45'),
(3, 1, 'Alphonso Mangoes', 'Sweet, juicy and rich mangoes directly sourced from Ratnagiri.', 450.00, 15.00, 20, 'KingFruits', 'box', '6 units', 'mango.png', 1, '2026-09-15 17:43:45'),
(4, 2, 'Fresh Potatoes', 'Starchy utility potatoes, ideal for roasting, boiling, and frying.', 40.00, 0.00, 200, 'Local', 'kg', '1 kg', 'potato.png', 1, '2026-09-15 17:43:45'),
(5, 2, 'Organic Red Tomatoes', 'Juicy red tomatoes sourced from organic farms.', 50.00, 5.00, 150, 'OrganicFarm', 'kg', '1 kg', 'tomato.png', 1, '2026-09-15 17:43:45'),
(6, 2, 'Fresh Onions', 'Essential kitchen staple, crisp and pungent pink onions.', 45.00, 0.00, 180, 'Local', 'kg', '1 kg', 'onion.png', 1, '2026-09-15 17:43:45'),
(7, 3, 'Fresh Cow Milk (Pasteurized)', 'Full cream pasteurized cow milk, rich in nutrients.', 70.00, 0.00, 60, 'DairyPure', 'packet', '1 Litre', 'milk.png', 1, '2026-09-15 17:43:45'),
(8, 3, 'Organic Butter', 'Salted creamery butter made from grass-fed cow milk.', 120.00, 8.00, 45, 'Amul', 'pack', '200g', 'butter.png', 1, '2026-09-15 17:43:45'),
(9, 3, 'Paneer (Cottage Cheese)', 'Soft and fresh block of cottage cheese.', 90.00, 5.00, 30, 'MotherDairy', 'pack', '200g', 'paneer.png', 1, '2026-09-15 17:43:45'),
(10, 4, 'Whole Wheat Sliced Bread', 'Healthy and soft whole wheat bread, baked daily.', 45.00, 0.00, 40, 'HarvestGold', 'pack', '400g', 'bread.png', 1, '2026-09-15 17:43:45'),
(11, 4, 'Chocolate Chip Cookies', 'Freshly baked buttery cookies loaded with chocolate chips.', 80.00, 10.00, 25, 'BakeryFresh', 'pack', '150g', 'cookies.png', 1, '2026-09-15 17:43:45'),
(12, 5, 'Pure Orange Juice', '100% pure squeezed orange juice with no added sugar.', 110.00, 15.00, 35, 'Real', 'pack', '1 Litre', 'orange_juice.png', 1, '2026-09-15 17:43:45'),
(13, 5, 'Premium Assam Tea', 'Rich and aromatic CTC black tea from the gardens of Assam.', 180.00, 5.00, 60, 'TataTea', 'box', '500g', 'tea.png', 1, '2026-09-15 17:43:45'),
(14, 6, 'Salted Potato Chips', 'Crisp and crunchy classic salted potato chips.', 30.00, 0.00, 100, 'Lays', 'pack', '90g', 'chips.png', 1, '2026-09-15 17:43:45'),
(15, 6, 'Roasted Salted Cashews', 'Premium handpicked roasted cashews lightly salted.', 250.00, 12.00, 40, 'Nutty', 'pack', '200g', 'cashews.png', 1, '2026-09-15 17:43:45'),
(16, 7, 'Basmati Rice (Premium Long Grain)', 'Aromatic and extra-long grain basmati rice.', 140.00, 10.00, 80, 'IndiaGate', 'bag', '1 kg', 'rice.png', 1, '2026-09-15 17:43:45'),
(17, 7, 'Cold Pressed Mustard Oil', '100% pure cold pressed mustard oil for traditional cooking.', 190.00, 5.00, 50, 'Fortune', 'bottle', '1 Litre', 'oil.png', 1, '2026-09-15 17:43:45'),
(18, 8, 'Dishwashing Liquid Gel', 'Tough on grease, gentle on hands lemon dishwash gel.', 115.00, 10.00, 40, 'Vim', 'bottle', '500ml', 'dishwash.png', 1, '2026-09-15 17:43:45'),
(19, 8, 'Multi-purpose Floor Cleaner', 'Kills 99.9% germs, leaves a refreshing citrus fragrance.', 160.00, 8.00, 30, 'Lizol', 'bottle', '1 Litre', 'floor_cleaner.png', 1, '2026-09-15 17:43:45');

-- --------------------------------------------------------

--
-- Table structure for table `product_images`
--

CREATE TABLE `product_images` (
  `id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `image` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `reviews`
--

CREATE TABLE `reviews` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `rating` int(11) DEFAULT NULL CHECK (`rating` between 1 and 5),
  `review` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `reviews`
--

INSERT INTO `reviews` (`id`, `user_id`, `product_id`, `rating`, `review`, `created_at`) VALUES
(1, 1, 1, 5, 'Absolutely delicious! Fresh and sweet.', '2026-09-15 17:43:45'),
(2, 2, 1, 4, 'Good quality apples, though slightly expensive.', '2026-09-15 17:43:45'),
(3, 1, 4, 5, 'Very soft and stays fresh for 3 days.', '2026-09-15 17:43:45'),
(4, 2, 7, 5, 'Best milk package in town. High fat creaminess.', '2026-09-15 17:43:45');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `mobile` varchar(15) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` varchar(20) DEFAULT 'customer',
  `profile_image` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `mobile`, `password`, `role`, `profile_image`, `created_at`) VALUES
(1, 'John Doe', 'user@grocerymart.com', '9876543210', '$2y$10$bDrSk/8SGwXfcsGC1HiTfeWJkOlWEpG08RH1kPPXgNZY9NlsTLTJy', 'customer', NULL, '2026-09-15 17:43:45'),
(2, 'Jane Smith', 'jane@example.com', '9123456789', '$2y$10$bDrSk/8SGwXfcsGC1HiTfeWJkOlWEpG08RH1kPPXgNZY9NlsTLTJy', 'customer', NULL, '2026-09-15 17:43:45');

-- --------------------------------------------------------

--
-- Table structure for table `wishlist`
--

CREATE TABLE `wishlist` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `wishlist`
--

INSERT INTO `wishlist` (`id`, `user_id`, `product_id`) VALUES
(1, 1, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `addresses`
--
ALTER TABLE `addresses`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contact_messages`
--
ALTER TABLE `contact_messages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `coupons`
--
ALTER TABLE `coupons`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `code` (`code`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `address_id` (`address_id`);

--
-- Indexes for table `order_items`
--
ALTER TABLE `order_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `order_id` (`order_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD KEY `category_id` (`category_id`);

--
-- Indexes for table `product_images`
--
ALTER TABLE `product_images`
  ADD PRIMARY KEY (`id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `reviews`
--
ALTER TABLE `reviews`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `wishlist`
--
ALTER TABLE `wishlist`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `product_id` (`product_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `addresses`
--
ALTER TABLE `addresses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `contact_messages`
--
ALTER TABLE `contact_messages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `coupons`
--
ALTER TABLE `coupons`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `order_items`
--
ALTER TABLE `order_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `product_images`
--
ALTER TABLE `product_images`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `reviews`
--
ALTER TABLE `reviews`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `wishlist`
--
ALTER TABLE `wishlist`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `addresses`
--
ALTER TABLE `addresses`
  ADD CONSTRAINT `addresses_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `cart`
--
ALTER TABLE `cart`
  ADD CONSTRAINT `cart_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `cart_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `orders_ibfk_2` FOREIGN KEY (`address_id`) REFERENCES `addresses` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `order_items`
--
ALTER TABLE `order_items`
  ADD CONSTRAINT `order_items_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `order_items_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `products_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `product_images`
--
ALTER TABLE `product_images`
  ADD CONSTRAINT `product_images_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `reviews`
--
ALTER TABLE `reviews`
  ADD CONSTRAINT `reviews_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `reviews_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `wishlist`
--
ALTER TABLE `wishlist`
  ADD CONSTRAINT `wishlist_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `wishlist_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
