<?php
$page_title = "Home";
include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/navbar.php';
?>

<!-- Hero Banner Section -->
<section class="hero-section">
    <div class="container">
        <div class="row align-items-center g-5">
            <div class="col-lg-6 text-center text-lg-start">
                <span class="badge bg-success-subtle text-success border border-success-subtle px-3 py-2 rounded-pill fw-semibold mb-3 small">
                    <i class="fa-solid fa-truck-fast me-1"></i> Super Fast Delivery in 30 Mins!
                </span>
                <h1 class="hero-title mb-4">
                    Freshness Delivered <br>Right to Your <span>Doorstep</span>
                </h1>
                <p class="lead text-muted mb-5">
                    Order fresh fruits, organic vegetables, dairy, bakery, beverages, and daily essentials at the best market prices.
                </p>
                <div class="d-flex flex-column flex-sm-row justify-content-center justify-content-lg-start gap-3">
                    <a href="shop.php" class="btn btn-primary-custom px-4 py-3 fs-5 rounded-pill shadow-sm">
                        <i class="fa-solid fa-cart-shopping me-2"></i> Shop Now
                    </a>
                    <a href="about.php" class="btn btn-outline-primary-custom px-4 py-3 fs-5 rounded-pill">
                        Learn More <i class="fa-solid fa-arrow-right ms-2"></i>
                    </a>
                </div>
            </div>
            <div class="col-lg-6 text-center">
                <img src="https://images.unsplash.com/photo-1542838132-92c53300491e?auto=format&fit=crop&w=600&q=80" alt="Fresh Groceries" class="img-fluid rounded-4 shadow-lg border border-light" style="max-height: 420px; object-fit: cover; width: 100%;">
            </div>
        </div>
    </div>
</section>

<!-- Featured Categories -->
<section class="container my-5 py-2">
    <div class="d-flex justify-content-between align-items-end mb-4 flex-wrap gap-2">
        <div>
            <span class="text-success fw-bold text-uppercase small tracking-wider" style="letter-spacing:1px;font-size:11px;">
                <i class="fa-solid fa-grid-2 me-1"></i> Fresh Essentials
            </span>
            <h3 class="fw-bold mb-0 text-dark mt-1" style="font-size:26px;letter-spacing:-0.5px;">Shop by Category</h3>
        </div>
        <a href="shop.php" class="btn btn-outline-success rounded-pill px-4 py-2 fs-6 fw-semibold">
            View All Categories <i class="fa-solid fa-arrow-right ms-1"></i>
        </a>
    </div>
    
    <div class="row row-cols-2 row-cols-sm-3 row-cols-md-4 row-cols-lg-6 g-3 g-md-4">
        <?php foreach ($categories as $cat): ?>
            <?php 
                $cName = trim($cat['name']);
                if (empty($cName)) continue;
                $imgUrl = getCategoryImage($cat['image'] ?? '', $cName);
            ?>
            <div class="col">
                <a href="shop.php?category=<?php echo $cat['id']; ?>" class="category-card">
                    <div class="category-card-img-wrapper">
                        <img 
                            src="<?php echo $imgUrl; ?>" 
                            alt="<?php echo htmlspecialchars($cName); ?>"
                            loading="lazy"
                            onerror="this.onerror=null; this.src='https://images.unsplash.com/photo-1542838132-92c53300491e?auto=format&fit=crop&w=400&q=80';"
                        >
                    </div>
                    <div class="category-card-title text-truncate w-100" title="<?php echo htmlspecialchars($cName); ?>">
                        <?php echo htmlspecialchars($cName); ?>
                    </div>
                    <span class="category-card-sub">Explore <i class="fa-solid fa-angle-right ms-1"></i></span>
                </a>
            </div>
        <?php endforeach; ?>
    </div>
</section>

<!-- Discounted / Today's Offers -->
<?php if (!empty($discounted_products)): ?>
<section class="container my-5 py-3">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h3 class="section-title mb-0">Today's Hot Offers</h3>
        <span class="badge bg-danger px-3 py-2 rounded-pill fw-semibold"><i class="fa-solid fa-fire-flame-curved me-1"></i> Limited Time Deals</span>
    </div>
    
    <div class="row g-4">
        <?php foreach ($discounted_products as $prod): ?>
            <div class="col-sm-6 col-md-4 col-lg-3">
                <div class="card card-custom h-100">
                    <!-- Discount Badge -->
                    <span class="discount-badge"><?php echo round($prod['discount']); ?>% OFF</span>
                    
                    <!-- Wishlist Btn -->
                    <?php 
                        $in_wishlist = false; 
                        if (isset($_SESSION['user_id'])) {
                            $wish_stmt = getDB()->prepare("SELECT COUNT(*) FROM wishlist WHERE user_id = :uid AND product_id = :pid");
                            $wish_stmt->execute(['uid' => $_SESSION['user_id'], 'pid' => $prod['id']]);
                            $in_wishlist = $wish_stmt->fetchColumn() > 0;
                        }
                    ?>
                    <button class="wishlist-btn <?php echo $in_wishlist ? 'active' : ''; ?>" onclick="toggleWishlist(<?php echo $prod['id']; ?>, this)" title="Add to Wishlist">
                        <i class="<?php echo $in_wishlist ? 'fa-solid' : 'fa-regular'; ?> fa-heart"></i>
                    </button>

                    <!-- Image -->
                    <div class="product-img-wrapper">
                        <a href="product.php?id=<?php echo $prod['id']; ?>">
                            <img src="<?php echo getProductImage($prod['image'], $prod['name']); ?>" alt="<?php echo htmlspecialchars($prod['name']); ?>" class="product-img">
                        </a>
                    </div>
                    
                    <!-- Card Body -->
                    <div class="card-body d-flex flex-column p-3">
                        <span class="text-muted small mb-1"><?php echo htmlspecialchars($prod['brand'] ?? 'GroceryMart'); ?></span>
                        <h6 class="card-title mb-2">
                            <a href="product.php?id=<?php echo $prod['id']; ?>" class="text-dark text-decoration-none fw-semibold">
                                <?php echo htmlspecialchars($prod['name']); ?>
                            </a>
                        </h6>
                        <div class="small text-muted mb-2">
                            Unit: <?php echo htmlspecialchars($prod['weight'] ?? '1 unit'); ?>
                        </div>
                        
                        <!-- Ratings -->
                        <div class="mb-3 text-warning small">
                            <i class="fa-solid fa-star"></i>
                            <i class="fa-solid fa-star"></i>
                            <i class="fa-solid fa-star"></i>
                            <i class="fa-solid fa-star"></i>
                            <i class="fa-solid fa-star-half-stroke"></i>
                            <span class="text-muted ms-1">(4.5)</span>
                        </div>

                        <!-- Price & Add Cart -->
                        <div class="mt-auto d-flex justify-content-between align-items-center pt-2 border-top">
                            <div>
                                <span class="fw-bold text-success fs-5">
                                    <?php echo formatPrice(getDiscountedPrice($prod['price'], $prod['discount'])); ?>
                                </span>
                                <br>
                                <span class="text-muted text-decoration-line-through small">
                                    <?php echo formatPrice($prod['price']); ?>
                                </span>
                            </div>
                            <?php if ($prod['stock'] > 0): ?>
                                <button onclick="addToCart(<?php echo $prod['id']; ?>, 1)" class="btn btn-primary-custom px-3 py-2 rounded-pill small">
                                    <i class="fa-solid fa-plus me-1"></i> Add
                                </button>
                            <?php else: ?>
                                <span class="badge bg-danger rounded-pill px-2 py-1">Out of Stock</span>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</section>
<?php endif; ?>

<!-- Popular Products -->
<section class="container my-5 py-3">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h3 class="section-title mb-0">Popular Products</h3>
        <a href="shop.php" class="btn btn-outline-primary-custom btn-sm rounded-pill px-3">View All Products</a>
    </div>
    
    <div class="row g-4">
        <?php foreach ($popular_products as $prod): ?>
            <div class="col-sm-6 col-md-4 col-lg-3">
                <div class="card card-custom h-100">
                    <!-- Discount Badge -->
                    <?php if ($prod['discount'] > 0): ?>
                        <span class="discount-badge"><?php echo round($prod['discount']); ?>% OFF</span>
                    <?php endif; ?>
                    
                    <!-- Wishlist Btn -->
                    <?php 
                        $in_wishlist = false; 
                        if (isset($_SESSION['user_id'])) {
                            $wish_stmt = getDB()->prepare("SELECT COUNT(*) FROM wishlist WHERE user_id = :uid AND product_id = :pid");
                            $wish_stmt->execute(['uid' => $_SESSION['user_id'], 'pid' => $prod['id']]);
                            $in_wishlist = $wish_stmt->fetchColumn() > 0;
                        }
                    ?>
                    <button class="wishlist-btn <?php echo $in_wishlist ? 'active' : ''; ?>" onclick="toggleWishlist(<?php echo $prod['id']; ?>, this)" title="Add to Wishlist">
                        <i class="<?php echo $in_wishlist ? 'fa-solid' : 'fa-regular'; ?> fa-heart"></i>
                    </button>

                    <!-- Image -->
                    <div class="product-img-wrapper">
                        <a href="product.php?id=<?php echo $prod['id']; ?>">
                            <img src="<?php echo getProductImage($prod['image'], $prod['name']); ?>" alt="<?php echo htmlspecialchars($prod['name']); ?>" class="product-img">
                        </a>
                    </div>
                    
                    <!-- Card Body -->
                    <div class="card-body d-flex flex-column p-3">
                        <span class="text-muted small mb-1"><?php echo htmlspecialchars($prod['brand'] ?? 'GroceryMart'); ?></span>
                        <h6 class="card-title mb-2">
                            <a href="product.php?id=<?php echo $prod['id']; ?>" class="text-dark text-decoration-none fw-semibold">
                                <?php echo htmlspecialchars($prod['name']); ?>
                            </a>
                        </h6>
                        <div class="small text-muted mb-2">
                            Unit: <?php echo htmlspecialchars($prod['weight'] ?? '1 unit'); ?>
                        </div>
                        
                        <!-- Ratings -->
                        <div class="mb-3 text-warning small">
                            <i class="fa-solid fa-star"></i>
                            <i class="fa-solid fa-star"></i>
                            <i class="fa-solid fa-star"></i>
                            <i class="fa-solid fa-star"></i>
                            <i class="fa-solid fa-star"></i>
                            <span class="text-muted ms-1">(5.0)</span>
                        </div>

                        <!-- Price & Add Cart -->
                        <div class="mt-auto d-flex justify-content-between align-items-center pt-2 border-top">
                            <div>
                                <span class="fw-bold text-success fs-5">
                                    <?php echo formatPrice(getDiscountedPrice($prod['price'], $prod['discount'])); ?>
                                </span>
                                <?php if ($prod['discount'] > 0): ?>
                                    <br>
                                    <span class="text-muted text-decoration-line-through small">
                                        <?php echo formatPrice($prod['price']); ?>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <?php if ($prod['stock'] > 0): ?>
                                <button onclick="addToCart(<?php echo $prod['id']; ?>, 1)" class="btn btn-primary-custom px-3 py-2 rounded-pill small">
                                    <i class="fa-solid fa-plus me-1"></i> Add
                                </button>
                            <?php else: ?>
                                <span class="badge bg-danger rounded-pill px-2 py-1">Out of Stock</span>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</section>

<!-- Why Choose Us -->
<section class="bg-light py-5 my-5">
    <div class="container text-center">
        <h3 class="fw-bold mb-5">Why Choose Us</h3>
        <div class="row g-4">
            <div class="col-md-3 col-sm-6">
                <div class="p-4 bg-white rounded-4 shadow-sm border h-100">
                    <div class="category-card-img-wrapper mb-3" style="width: 60px; height: 60px; display: inline-flex; align-items: center; justify-content: center;">
                        <i class="fa-solid fa-truck-fast text-success" style="font-size: 28px;"></i>
                    </div>
                    <h6 class="fw-bold">Free & Fast Delivery</h6>
                    <p class="text-muted small mb-0">Free shipping on orders over ₹499. Delivered in 30 minutes.</p>
                </div>
            </div>
            <div class="col-md-3 col-sm-6">
                <div class="p-4 bg-white rounded-4 shadow-sm border h-100">
                    <div class="category-card-img-wrapper mb-3" style="width: 60px; height: 60px; display: inline-flex; align-items: center; justify-content: center;">
                        <i class="fa-solid fa-leaf text-success" style="font-size: 28px;"></i>
                    </div>
                    <h6 class="fw-bold">100% Organic & Fresh</h6>
                    <p class="text-muted small mb-0">Sourced directly from local organic farms daily.</p>
                </div>
            </div>
            <div class="col-md-3 col-sm-6">
                <div class="p-4 bg-white rounded-4 shadow-sm border h-100">
                    <div class="category-card-img-wrapper mb-3" style="width: 60px; height: 60px; display: inline-flex; align-items: center; justify-content: center;">
                        <i class="fa-solid fa-circle-check text-success" style="font-size: 28px;"></i>
                    </div>
                    <h6 class="fw-bold">Best Market Prices</h6>
                    <p class="text-muted small mb-0">Guaranteed lowest prices and active discount coupons.</p>
                </div>
            </div>
            <div class="col-md-3 col-sm-6">
                <div class="p-4 bg-white rounded-4 shadow-sm border h-100">
                    <div class="category-card-img-wrapper mb-3" style="width: 60px; height: 60px; display: inline-flex; align-items: center; justify-content: center;">
                        <i class="fa-solid fa-headset text-success" style="font-size: 28px;"></i>
                    </div>
                    <h6 class="fw-bold">24/7 Dedicated Support</h6>
                    <p class="text-muted small mb-0">Got a query? Our support staff is online to assist you instantly.</p>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Customer Reviews Slider (Simulated) -->
<section class="container my-5">
    <div class="text-center mb-5">
        <h3 class="fw-bold">What Our Customers Say</h3>
        <p class="text-muted">Real stories from our grocery shoppers</p>
    </div>
    
    <div class="row g-4">
        <div class="col-md-4">
            <div class="card card-custom p-4 h-100">
                <div class="d-flex align-items-center gap-3 mb-3">
                    <div class="category-card-img-wrapper" style="width: 50px; height: 50px;">
                        <img src="https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=100&q=80" alt="Sarah" class="rounded-circle w-100 h-100" style="object-fit: cover;">
                    </div>
                    <div>
                        <h6 class="fw-bold mb-0">Sarah Jenkins</h6>
                        <span class="text-warning small"><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i></span>
                    </div>
                </div>
                <p class="text-muted small mb-0">
                    "GroceryMart has completely changed my daily routine. The mangoes and apples I ordered were exceptionally fresh, and the delivery took less than 20 minutes! Highly recommended."
                </p>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card card-custom p-4 h-100">
                <div class="d-flex align-items-center gap-3 mb-3">
                    <div class="category-card-img-wrapper" style="width: 50px; height: 50px;">
                        <img src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=100&q=80" alt="Michael" class="rounded-circle w-100 h-100" style="object-fit: cover;">
                    </div>
                    <div>
                        <h6 class="fw-bold mb-0">Michael Chen</h6>
                        <span class="text-warning small"><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i></span>
                    </div>
                </div>
                <p class="text-muted small mb-0">
                    "I applied the WELCOME50 coupon code and saved flat ₹50. The checkout was very smooth, and the dummy card payment simulator worked beautifully. Will buy here again!"
                </p>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card card-custom p-4 h-100">
                <div class="d-flex align-items-center gap-3 mb-3">
                    <div class="category-card-img-wrapper" style="width: 50px; height: 50px;">
                        <img src="https://images.unsplash.com/photo-1508214751196-bcfd4ca60f91?auto=format&fit=crop&w=100&q=80" alt="Aisha" class="rounded-circle w-100 h-100" style="object-fit: cover;">
                    </div>
                    <div>
                        <h6 class="fw-bold mb-0">Aisha Rahaman</h6>
                        <span class="text-warning small"><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i class="fa-solid fa-star-half-stroke"></i></span>
                    </div>
                </div>
                <p class="text-muted small mb-0">
                    "The organic cottage cheese (paneer) is extremely soft and pure. Their inventory management is transparent, showing low stock alerts so I can buy before items run out."
                </p>
            </div>
        </div>
    </div>
</section>

<?php include __DIR__ . '/../includes/footer.php'; ?>
