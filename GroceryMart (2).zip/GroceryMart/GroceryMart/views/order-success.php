<?php
$page_title = "Order Success";
include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/navbar.php';
?>

<div class="container my-5 text-center">
    <div class="row justify-content-center">
        <div class="col-lg-7">
            <!-- success banner -->
            <div class="card card-custom p-4 p-md-5 border-light shadow-lg bg-white mb-4">
                <div class="category-card-img-wrapper mb-4 bg-success-subtle text-success" style="width: 90px; height: 90px; display: inline-flex; align-items: center; justify-content: center; margin: 0 auto;">
                    <i class="fa-solid fa-circle-check" style="font-size: 44px;"></i>
                </div>
                
                <h2 class="fw-bold mb-2">Order Confirmed!</h2>
                <p class="text-muted mb-4">Thank you for shopping at GroceryMart. Your order has been placed and is currently being packed.</p>
                
                <!-- Order specs card -->
                <div class="card p-4 rounded-4 bg-light border-0 text-start mb-4">
                    <div class="row g-3">
                        <div class="col-sm-6">
                            <span class="text-muted small d-block">Order Number:</span>
                            <span class="fw-bold text-dark fs-6">#GM-<?php echo str_pad($order['id'], 6, '0', STR_PAD_LEFT); ?></span>
                        </div>
                        <div class="col-sm-6">
                            <span class="text-muted small d-block">Payment Option:</span>
                            <span class="fw-bold text-dark fs-6"><?php echo $order['payment_method']; ?> (<?php echo $order['payment_status']; ?>)</span>
                        </div>
                        <div class="col-sm-6">
                            <span class="text-muted small d-block">Shipping Address:</span>
                            <span class="text-muted small mt-1 d-block font-monospace">
                                <?php echo htmlspecialchars($order['full_address']); ?>, <br>
                                <?php echo htmlspecialchars($order['city']); ?>, <?php echo htmlspecialchars($order['state']); ?> - <?php echo htmlspecialchars($order['zipcode']); ?>
                            </span>
                        </div>
                        <div class="col-sm-6">
                            <span class="text-muted small d-block">Est. Delivery Time:</span>
                            <span class="fw-bold text-success fs-6"><i class="fa-solid fa-clock text-success me-1"></i> Today (Within 30 mins)</span>
                        </div>
                    </div>
                </div>

                <!-- Items purchase breakdown -->
                <h5 class="fw-bold mb-3 text-start">Items Summary</h5>
                <div class="d-flex flex-column gap-2 mb-4 text-start border rounded-4 p-3 bg-white">
                    <?php 
                    $subtotal = 0;
                    foreach ($orderItems as $item): 
                        $subtotal += ($item['price'] * $item['quantity']);
                    ?>
                        <div class="d-flex justify-content-between align-items-center small py-1">
                            <span class="text-dark fw-medium"><?php echo htmlspecialchars($item['name']); ?> (<?php echo htmlspecialchars($item['weight'] ?? '1 unit'); ?>) <span class="text-muted">x <?php echo $item['quantity']; ?></span></span>
                            <span class="fw-semibold text-dark"><?php echo formatPrice($item['price'] * $item['quantity']); ?></span>
                        </div>
                    <?php endforeach; ?>
                    
                    <hr class="my-2">
                    
                    <div class="d-flex justify-content-between align-items-center small text-muted">
                        <span>Items Subtotal</span>
                        <span><?php echo formatPrice($subtotal); ?></span>
                    </div>
                    <?php if ($order['discount'] > 0): ?>
                        <div class="d-flex justify-content-between align-items-center small text-muted">
                            <span>Coupon Discount</span>
                            <span class="text-danger">- <?php echo formatPrice($order['discount']); ?></span>
                        </div>
                    <?php endif; ?>
                    <div class="d-flex justify-content-between align-items-center fw-bold fs-6 mt-1 border-top pt-2">
                        <span class="text-dark">Grand Total</span>
                        <span class="text-success"><?php echo formatPrice($order['total']); ?></span>
                    </div>
                </div>

                <!-- Control actions -->
                <div class="d-flex flex-column flex-sm-row justify-content-center gap-3">
                    <a href="profile.php?page=orders" class="btn btn-primary-custom px-4 py-2.5 rounded-pill fs-6">
                        <i class="fa-solid fa-box-open me-2"></i> Track My Order
                    </a>
                    <a href="shop.php" class="btn btn-outline-primary-custom px-4 py-2.5 rounded-pill fs-6">
                        Continue Shopping <i class="fa-solid fa-arrow-right ms-2"></i>
                    </a>
                </div>

                <div class="mt-4 pt-3 border-top text-center">
                    <button onclick="window.print()" class="btn btn-link text-success text-decoration-none small fw-semibold">
                        <i class="fa-solid fa-file-invoice-dollar me-1"></i> Download / Print Invoice (PDF)
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Print-only CSS style helper -->
<style>
@media print {
    .navbar-custom, footer, .btn, .btn-link, nav[aria-label="breadcrumb"], .alert {
        display: none !important;
    }
    body {
        background-color: white !important;
        color: black !important;
    }
    .card-custom {
        box-shadow: none !important;
        border: none !important;
        padding: 0 !important;
    }
}
</style>

<?php include __DIR__ . '/../includes/footer.php'; ?>
