<?php
// api/search.php — Live search AJAX endpoint
require_once __DIR__ . '/../config/db.php';

header('Content-Type: application/json');

$query = trim($_GET['q'] ?? '');

if (strlen($query) < 2) {
    echo json_encode([]);
    exit();
}

try {
    $db = getDB();
    $like = '%' . $query . '%';

    $stmt = $db->prepare("
        SELECT 
            p.id,
            p.name,
            p.price,
            p.discount,
            p.image,
            p.brand,
            c.name AS category_name
        FROM products p
        LEFT JOIN categories c ON p.category_id = c.id
        WHERE p.status = 1
          AND (p.name LIKE :s1 OR p.brand LIKE :s2 OR p.description LIKE :s3)
        ORDER BY p.name ASC
        LIMIT 8
    ");
    $stmt->execute([':s1' => $like, ':s2' => $like, ':s3' => $like]);
    $products = $stmt->fetchAll();

    $results = array_map(function($p) {
        $discounted = $p['discount'] > 0
            ? round($p['price'] * (1 - $p['discount'] / 100), 2)
            : $p['price'];

        // Build image URL
        $image = !empty($p['image']) ? '../assets/images/products/' . $p['image'] : null;

        return [
            'id'            => $p['id'],
            'name'          => $p['name'],
            'brand'         => $p['brand'] ?? '',
            'category'      => $p['category_name'] ?? '',
            'price'         => number_format($discounted, 2),
            'original_price'=> number_format($p['price'], 2),
            'discount'      => $p['discount'],
            'image'         => $image,
        ];
    }, $products);

    echo json_encode($results);
} catch (PDOException $e) {
    error_log('Live search error: ' . $e->getMessage());
    echo json_encode([]);
}
