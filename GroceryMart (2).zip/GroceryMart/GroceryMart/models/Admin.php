<?php
require_once __DIR__ . '/../config/db.php';

class Admin {
    private $db;

    public function __construct() {
        $this->db = getDB();
    }

    /**
     * Find an admin by their email
     * @param string $email
     * @return array|false
     */
    public function findByEmail($email) {
        $stmt = $this->db->prepare("SELECT * FROM admins WHERE email = :email");
        $stmt->execute(['email' => $email]);
        return $stmt->fetch();
    }

    /**
     * Find an admin by their ID
     * @param int $id
     * @return array|false
     */
    public function findById($id) {
        $stmt = $this->db->prepare("SELECT * FROM admins WHERE id = :id");
        $stmt->execute(['id' => $id]);
        return $stmt->fetch();
    }

    /**
     * Create a new admin account
     * @param string $name
     * @param string $email
     * @param string $password Raw password
     * @return int|false
     */
    public function create($name, $email, $password) {
        $hashedPassword = password_hash($password, PASSWORD_BCRYPT);
        $stmt = $this->db->prepare("INSERT INTO admins (name, email, password) VALUES (:name, :email, :password)");
        $result = $stmt->execute([
            'name' => htmlspecialchars(strip_tags($name)),
            'email' => filter_var($email, FILTER_SANITIZE_EMAIL),
            'password' => $hashedPassword
        ]);
        return $result ? $this->db->lastInsertId() : false;
    }

    /**
     * Update admin password
     * @param int $id
     * @param string $password Raw password
     * @return bool
     */
    public function updatePassword($id, $password) {
        $hashedPassword = password_hash($password, PASSWORD_BCRYPT);
        $stmt = $this->db->prepare("UPDATE admins SET password = :password WHERE id = :id");
        return $stmt->execute([
            'password' => $hashedPassword,
            'id' => $id
        ]);
    }
}
