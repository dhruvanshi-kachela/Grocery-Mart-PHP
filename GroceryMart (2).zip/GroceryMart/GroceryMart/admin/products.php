<?php
$page_title = "Products & Inventory";
require_once __DIR__ . '/../includes/admin-header.php';
require_once __DIR__ . '/../includes/admin-sidebar.php';
require_once __DIR__ . '/../models/Product.php';
require_once __DIR__ . '/../models/Category.php';

$db         = getDB();
$catModel   = new Category();
$categories = $catModel->getAllCategories();

// ── Handle POST Actions ──────────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    // ADD product
    if ($action === 'add') {
        $name        = trim($_POST['name']        ?? '');
        $category_id = intval($_POST['category_id'] ?? 0);
        $price       = floatval($_POST['price']    ?? 0);
        $discount    = floatval($_POST['discount'] ?? 0);
        $stock       = intval($_POST['stock']      ?? 0);
        $brand       = trim($_POST['brand']        ?? '');
        $unit        = trim($_POST['unit']         ?? 'kg');
        $weight      = trim($_POST['weight']       ?? '');
        $description = trim($_POST['description']  ?? '');

        if (empty($name) || $price <= 0) {
            $_SESSION['error'] = "Product name and price are required.";
        } else {
            // Handle image upload
            $imageName = null;
            if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
                $uploadDir = __DIR__ . '/../assets/uploads/products/';
                if (!is_dir($uploadDir)) mkdir($uploadDir, 0777, true);
                $ext       = pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION);
                $imageName = 'prod_' . time() . '.' . $ext;
                if (!move_uploaded_file($_FILES['image']['tmp_name'], $uploadDir . $imageName)) {
                    $imageName = null;
                }
            }

            $stmt = $db->prepare("
                INSERT INTO products (category_id, name, description, price, discount, stock, brand, unit, weight, image, status)
                VALUES (:category_id, :name, :description, :price, :discount, :stock, :brand, :unit, :weight, :image, 1)
            ");
            $ok = $stmt->execute([
                'category_id' => $category_id ?: null,
                'name'        => $name,
                'description' => $description,
                'price'       => $price,
                'discount'    => $discount,
                'stock'       => $stock,
                'brand'       => $brand,
                'unit'        => $unit,
                'weight'      => $weight,
                'image'       => $imageName,
            ]);
            $_SESSION[$ok ? 'success' : 'error'] = $ok ? "Product '{$name}' added!" : "Failed to add product.";
        }
        header("Location: products.php"); exit();
    }

    // EDIT product
    if ($action === 'edit') {
        $id          = intval($_POST['product_id'] ?? 0);
        $name        = trim($_POST['name']        ?? '');
        $category_id = intval($_POST['category_id'] ?? 0);
        $price       = floatval($_POST['price']    ?? 0);
        $discount    = floatval($_POST['discount'] ?? 0);
        $stock       = intval($_POST['stock']      ?? 0);
        $brand       = trim($_POST['brand']        ?? '');
        $unit        = trim($_POST['unit']         ?? 'kg');
        $weight      = trim($_POST['weight']       ?? '');
        $description = trim($_POST['description']  ?? '');
        $status      = intval($_POST['status']     ?? 1);

        if ($id > 0 && !empty($name) && $price > 0) {
            // Fetch current image
            $cur = $db->prepare("SELECT image FROM products WHERE id = :id");
            $cur->execute(['id' => $id]);
            $currentImage = $cur->fetchColumn();

            $imageName = $currentImage;
            if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
                $uploadDir = __DIR__ . '/../assets/uploads/products/';
                if (!is_dir($uploadDir)) mkdir($uploadDir, 0777, true);
                $ext       = pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION);
                $imageName = 'prod_' . time() . '.' . $ext;
                if (!move_uploaded_file($_FILES['image']['tmp_name'], $uploadDir . $imageName)) {
                    $imageName = $currentImage;
                }
            }

            $stmt = $db->prepare("
                UPDATE products SET category_id=:cat, name=:name, description=:desc,
                price=:price, discount=:discount, stock=:stock, brand=:brand,
                unit=:unit, weight=:weight, image=:image, status=:status WHERE id=:id
            ");
            $ok = $stmt->execute([
                'cat' => $category_id ?: null, 'name' => $name, 'desc' => $description,
                'price' => $price, 'discount' => $discount, 'stock' => $stock,
                'brand' => $brand, 'unit' => $unit, 'weight' => $weight,
                'image' => $imageName, 'status' => $status, 'id' => $id,
            ]);
            $_SESSION[$ok ? 'success' : 'error'] = $ok ? "Product updated successfully!" : "Failed to update product.";
        } else {
            $_SESSION['error'] = "Invalid product data.";
        }
        header("Location: products.php"); exit();
    }
}

// DELETE product
if (isset($_GET['delete_id'])) {
    $id = intval($_GET['delete_id']);
    if ($id > 0) {
        $stmt = $db->prepare("DELETE FROM products WHERE id = :id");
        $ok   = $stmt->execute(['id' => $id]);
        $_SESSION[$ok ? 'success' : 'error'] = $ok ? "Product deleted." : "Failed to delete product.";
    }
    header("Location: products.php"); exit();
}

// Fetch all products with category name
$products = $db->query("
    SELECT p.*, c.name as category_name
    FROM products p
    LEFT JOIN categories c ON p.category_id = c.id
    ORDER BY p.id DESC
")->fetchAll();
?>

<!-- Page Header -->
<div class="d-flex justify-content-between align-items-center mb-4">
    <h5 class="fw-bold mb-0"><i class="fa-solid fa-boxes-packing text-success me-2"></i>Products & Inventory</h5>
    <button class="btn btn-primary-custom btn-sm rounded-pill px-3" data-bs-toggle="collapse" data-bs-target="#addProductForm">
        <i class="fa-solid fa-plus me-1"></i> Add Product
    </button>
</div>

<!-- Add Product Form -->
<div class="collapse mb-4" id="addProductForm">
    <div class="card p-4 rounded-4 border bg-light shadow-sm">
        <h6 class="fw-bold mb-3">Add New Product</h6>
        <form action="products.php" method="POST" enctype="multipart/form-data">
            <input type="hidden" name="action" value="add">
            <div class="row g-3">
                <div class="col-md-6"><label class="form-label small fw-medium">Product Name *</label>
                    <input type="text" class="form-control" name="name" required placeholder="e.g. Fresh Mangoes"></div>
                <div class="col-md-6"><label class="form-label small fw-medium">Category</label>
                    <select class="form-select" name="category_id">
                        <option value="">-- No Category --</option>
                        <?php foreach ($categories as $c): ?>
                            <option value="<?php echo $c['id']; ?>"><?php echo htmlspecialchars($c['name']); ?></option>
                        <?php endforeach; ?>
                    </select></div>
                <div class="col-md-3"><label class="form-label small fw-medium">Price (₹) *</label>
                    <input type="number" class="form-control" name="price" required min="0" step="0.01" placeholder="0.00"></div>
                <div class="col-md-3"><label class="form-label small fw-medium">Discount (%)</label>
                    <input type="number" class="form-control" name="discount" min="0" max="100" step="0.01" value="0"></div>
                <div class="col-md-3"><label class="form-label small fw-medium">Stock Qty *</label>
                    <input type="number" class="form-control" name="stock" required min="0" value="0"></div>
                <div class="col-md-3"><label class="form-label small fw-medium">Unit</label>
                    <input type="text" class="form-control" name="unit" placeholder="kg / pcs / pack" value="kg"></div>
                <div class="col-md-4"><label class="form-label small fw-medium">Brand</label>
                    <input type="text" class="form-control" name="brand" placeholder="e.g. Amul"></div>
                <div class="col-md-4"><label class="form-label small fw-medium">Weight / Size</label>
                    <input type="text" class="form-control" name="weight" placeholder="e.g. 1 kg"></div>
                <div class="col-md-4"><label class="form-label small fw-medium">Product Image</label>
                    <input type="file" class="form-control" name="image" accept="image/*"></div>
                <div class="col-12"><label class="form-label small fw-medium">Description</label>
                    <textarea class="form-control" name="description" rows="2" placeholder="Short product description..."></textarea></div>
            </div>
            <button type="submit" class="btn btn-success rounded-pill px-4 mt-3">Add Product</button>
        </form>
    </div>
</div>

<!-- Products Table -->
<div class="card card-custom p-4 border-0 shadow-sm bg-white">
    <?php if (!empty($products)): ?>
        <div class="table-responsive">
            <table class="table align-middle small mb-0">
                <thead>
                    <tr class="text-muted">
                        <th>Image</th>
                        <th>Name</th>
                        <th>Category</th>
                        <th class="text-center">Price</th>
                        <th class="text-center">Discount</th>
                        <th class="text-center">Stock</th>
                        <th class="text-center">Status</th>
                        <th class="text-end">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($products as $p): ?>
                        <tr>
                            <td>
                                <div class="rounded border p-1" style="width:46px;height:46px;display:flex;align-items:center;justify-content:center;background:#fafafa;">
                                    <img src="<?php echo getProductImage($p['image'], $p['name']); ?>" alt="" style="max-height:100%;max-width:100%;object-fit:contain;">
                                </div>
                            </td>
                            <td class="fw-semibold"><?php echo htmlspecialchars($p['name']); ?><br>
                                <span class="text-muted" style="font-size:11px;"><?php echo htmlspecialchars($p['brand'] ?? ''); ?></span></td>
                            <td><?php echo htmlspecialchars($p['category_name'] ?? '—'); ?></td>
                            <td class="text-center fw-bold text-success"><?php echo formatPrice($p['price']); ?></td>
                            <td class="text-center"><?php echo $p['discount'] > 0 ? '<span class="badge bg-warning-subtle text-warning border border-warning-subtle rounded-pill">' . $p['discount'] . '%</span>' : '<span class="text-muted">—</span>'; ?></td>
                            <td class="text-center">
                                <span class="badge rounded-pill <?php echo $p['stock'] <= 5 ? 'bg-danger-subtle text-danger border border-danger-subtle' : ($p['stock'] <= 15 ? 'bg-warning-subtle text-warning border border-warning-subtle' : 'bg-success-subtle text-success border border-success-subtle'); ?>">
                                    <?php echo $p['stock']; ?>
                                </span>
                            </td>
                            <td class="text-center">
                                <span class="badge rounded-pill <?php echo $p['status'] == 1 ? 'bg-success-subtle text-success border border-success-subtle' : 'bg-secondary-subtle text-secondary border border-secondary-subtle'; ?>">
                                    <?php echo $p['status'] == 1 ? 'Active' : 'Inactive'; ?>
                                </span>
                            </td>
                            <td class="text-end">
                                <div class="d-inline-flex gap-2">
                                    <button class="btn btn-sm btn-outline-success border-0 rounded-circle" data-bs-toggle="collapse" data-bs-target="#editProd_<?php echo $p['id']; ?>" title="Edit">
                                        <i class="fa-regular fa-pen-to-square"></i>
                                    </button>
                                    <a href="products.php?delete_id=<?php echo $p['id']; ?>" onclick="return confirm('Delete this product?')" class="btn btn-sm btn-outline-danger border-0 rounded-circle" title="Delete">
                                        <i class="fa-regular fa-trash-can"></i>
                                    </a>
                                </div>
                                <!-- Inline edit collapse -->
                                <div class="collapse text-start mt-3" id="editProd_<?php echo $p['id']; ?>">
                                    <div class="card p-3 bg-light border rounded-4" style="min-width:340px;">
                                        <form action="products.php" method="POST" enctype="multipart/form-data">
                                            <input type="hidden" name="action" value="edit">
                                            <input type="hidden" name="product_id" value="<?php echo $p['id']; ?>">
                                            <div class="row g-2 mb-2">
                                                <div class="col-8"><label class="form-label small fw-medium">Name</label>
                                                    <input type="text" class="form-control form-control-sm" name="name" required value="<?php echo htmlspecialchars($p['name']); ?>"></div>
                                                <div class="col-4"><label class="form-label small fw-medium">Status</label>
                                                    <select class="form-select form-select-sm" name="status">
                                                        <option value="1" <?php echo $p['status']==1?'selected':''; ?>>Active</option>
                                                        <option value="0" <?php echo $p['status']==0?'selected':''; ?>>Inactive</option>
                                                    </select></div>
                                                <div class="col-4"><label class="form-label small fw-medium">Price (₹)</label>
                                                    <input type="number" class="form-control form-control-sm" name="price" step="0.01" required value="<?php echo $p['price']; ?>"></div>
                                                <div class="col-4"><label class="form-label small fw-medium">Discount %</label>
                                                    <input type="number" class="form-control form-control-sm" name="discount" step="0.01" value="<?php echo $p['discount']; ?>"></div>
                                                <div class="col-4"><label class="form-label small fw-medium">Stock</label>
                                                    <input type="number" class="form-control form-control-sm" name="stock" required value="<?php echo $p['stock']; ?>"></div>
                                                <div class="col-6"><label class="form-label small fw-medium">Brand</label>
                                                    <input type="text" class="form-control form-control-sm" name="brand" value="<?php echo htmlspecialchars($p['brand'] ?? ''); ?>"></div>
                                                <div class="col-6"><label class="form-label small fw-medium">Weight</label>
                                                    <input type="text" class="form-control form-control-sm" name="weight" value="<?php echo htmlspecialchars($p['weight'] ?? ''); ?>"></div>
                                                <div class="col-6"><label class="form-label small fw-medium">Unit</label>
                                                    <input type="text" class="form-control form-control-sm" name="unit" value="<?php echo htmlspecialchars($p['unit'] ?? ''); ?>"></div>
                                                <div class="col-6"><label class="form-label small fw-medium">Category</label>
                                                    <select class="form-select form-select-sm" name="category_id">
                                                        <option value="">— None —</option>
                                                        <?php foreach ($categories as $c): ?>
                                                            <option value="<?php echo $c['id']; ?>" <?php echo $p['category_id']==$c['id']?'selected':''; ?>><?php echo htmlspecialchars($c['name']); ?></option>
                                                        <?php endforeach; ?>
                                                    </select></div>
                                                <div class="col-12"><label class="form-label small fw-medium">New Image (optional)</label>
                                                    <input type="file" class="form-control form-control-sm" name="image" accept="image/*"></div>
                                            </div>
                                            <button type="submit" class="btn btn-success btn-sm rounded-pill px-3">Update</button>
                                        </form>
                                    </div>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php else: ?>
        <p class="text-muted text-center py-5 mb-0">No products found.</p>
    <?php endif; ?>
</div>

<?php require_once __DIR__ . '/../includes/admin-footer.php'; ?>
