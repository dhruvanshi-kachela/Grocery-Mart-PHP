<?php
require_once __DIR__ . '/../config/db.php';

class User {
    private $db;

    public function __construct() {
        $this->db = getDB();
    }

    /**
     * Find a user by their email
     * @param string $email
     * @return array|false
     */
    public function findByEmail($email) {
        $stmt = $this->db->prepare("SELECT * FROM users WHERE email = :email");
        $stmt->execute(['email' => $email]);
        return $stmt->fetch();
    }

    /**
     * Find a user by their ID
     * @param int $id
     * @return array|false
     */
    public function findById($id) {
        $stmt = $this->db->prepare("SELECT * FROM users WHERE id = :id");
        $stmt->execute(['id' => $id]);
        return $stmt->fetch();
    }

    /**
     * Register a new user
     * @param string $name
     * @param string $email
     * @param string $mobile
     * @param string $password Raw password
     * @param string $role Default 'customer'
     * @return int|false The inserted ID or false
     */
    public function create($name, $email, $mobile, $password, $role = 'customer') {
        $hashedPassword = password_hash($password, PASSWORD_BCRYPT);
        $stmt = $this->db->prepare("
            INSERT INTO users (name, email, mobile, password, role) 
            VALUES (:name, :email, :mobile, :password, :role)
        ");
        
        $result = $stmt->execute([
            'name' => htmlspecialchars(strip_tags($name)),
            'email' => filter_var($email, FILTER_SANITIZE_EMAIL),
            'mobile' => htmlspecialchars(strip_tags($mobile)),
            'password' => $hashedPassword,
            'role' => $role
        ]);

        return $result ? $this->db->lastInsertId() : false;
    }

    /**
     * Check if email already exists
     * @param string $email
     * @return bool
     */
    public function emailExists($email) {
        $stmt = $this->db->prepare("SELECT COUNT(*) FROM users WHERE email = :email");
        $stmt->execute(['email' => $email]);
        return $stmt->fetchColumn() > 0;
    }

    /**
     * Update user profile information
     * @param int $id
     * @param string $name
     * @param string $mobile
     * @param string|null $profileImage
     * @return bool
     */
    public function updateProfile($id, $name, $mobile, $profileImage = null) {
        if ($profileImage) {
            $stmt = $this->db->prepare("
                UPDATE users 
                SET name = :name, mobile = :mobile, profile_image = :profile_image 
                WHERE id = :id
            ");
            return $stmt->execute([
                'name' => htmlspecialchars(strip_tags($name)),
                'mobile' => htmlspecialchars(strip_tags($mobile)),
                'profile_image' => $profileImage,
                'id' => $id
            ]);
        } else {
            $stmt = $this->db->prepare("
                UPDATE users 
                SET name = :name, mobile = :mobile 
                WHERE id = :id
            ");
            return $stmt->execute([
                'name' => htmlspecialchars(strip_tags($name)),
                'mobile' => htmlspecialchars(strip_tags($mobile)),
                'id' => $id
            ]);
        }
    }

    /**
     * Update user password
     * @param int $id
     * @param string $password Raw password
     * @return bool
     */
    public function updatePassword($id, $password) {
        $hashedPassword = password_hash($password, PASSWORD_BCRYPT);
        $stmt = $this->db->prepare("UPDATE users SET password = :password WHERE id = :id");
        return $stmt->execute([
            'password' => $hashedPassword,
            'id' => $id
        ]);
    }

    /**
     * Get all customers (for admin panel)
     * @return array
     */
    public function getAllCustomers() {
        $stmt = $this->db->query("SELECT id, name, email, mobile, profile_image, created_at FROM users WHERE role = 'customer' ORDER BY id DESC");
        return $stmt->fetchAll();
    }

    /**
     * Delete a customer (for admin panel)
     * @param int $id
     * @return bool
     */
    public function delete($id) {
        $stmt = $this->db->prepare("DELETE FROM users WHERE id = :id AND role = 'customer'");
        return $stmt->execute(['id' => $id]);
    }
}
