<?php
// Calculate Cart & Wishlist counts
$cart_count     = 0;
$wishlist_count = 0;

if (isset($_SESSION['user_id'])) {
    try {
        $db = getDB();
        $stmt = $db->prepare("SELECT SUM(quantity) FROM cart WHERE user_id = :user_id");
        $stmt->execute(['user_id' => $_SESSION['user_id']]);
        $cart_count = intval($stmt->fetchColumn());

        $stmt = $db->prepare("SELECT COUNT(*) FROM wishlist WHERE user_id = :user_id");
        $stmt->execute(['user_id' => $_SESSION['user_id']]);
        $wishlist_count = intval($stmt->fetchColumn());
    } catch (PDOException $e) {
        error_log("Navbar count fetch error: " . $e->getMessage());
    }
} else {
    if (isset($_SESSION['cart'])) {
        foreach ($_SESSION['cart'] as $qty) $cart_count += intval($qty);
    }
}

// Fetch categories for dropdown
$nav_categories = [];
try {
    $db = getDB();
    $stmt = $db->query("SELECT * FROM categories WHERE status = 1 LIMIT 10");
    $nav_categories = $stmt->fetchAll();
} catch (PDOException $e) {
    error_log("Navbar category fetch error: " . $e->getMessage());
}

$current_page = basename($_SERVER['PHP_SELF']);
$first_name   = isset($_SESSION['user_name']) ? explode(' ', $_SESSION['user_name'])[0] : '';
$user_initial = $first_name ? strtoupper($first_name[0]) : 'U';
?>

<style>
/* ── NAV RESET & BASE ─────────────────────────────────────────────────── */
.gm-nav {
    background: #fff;
    border-bottom: 1px solid #f0f4f0;
    box-shadow: 0 2px 20px rgba(46,125,50,0.06);
    padding: 0;
    position: sticky; top: 0; z-index: 1050;
    font-family: 'Poppins', sans-serif;
}
.gm-nav .container { max-width: 1280px; }
.gm-nav-inner {
    display: flex; align-items: center; gap: 0;
    height: 68px;
}

/* ── LOGO ─────────────────────────────────────────────────────────────── */
.gm-logo {
    display: flex; align-items: center; gap: 10px;
    text-decoration: none; flex-shrink: 0; margin-right: 28px;
}
.gm-logo-icon {
    width: 40px; height: 40px;
    background: linear-gradient(135deg, #2E7D32, #4CAF50);
    border-radius: 12px;
    display: flex; align-items: center; justify-content: center;
    color: #fff; font-size: 18px;
    box-shadow: 0 4px 12px rgba(76,175,80,0.35);
    transition: transform 0.2s, box-shadow 0.2s;
}
.gm-logo:hover .gm-logo-icon { transform: rotate(-8deg) scale(1.08); box-shadow: 0 6px 18px rgba(76,175,80,0.45); }
.gm-logo-text { font-size: 20px; font-weight: 800; color: #1B5E20; letter-spacing: -0.4px; line-height: 1; }
.gm-logo-text span { color: #4CAF50; }

/* ── NAV LINKS ────────────────────────────────────────────────────────── */
.gm-links {
    display: flex; align-items: center; gap: 2px;
    list-style: none; margin: 0; padding: 0;
}
.gm-links .gm-link {
    position: relative; padding: 8px 14px;
    font-size: 14px; font-weight: 500; color: #444;
    text-decoration: none; border-radius: 10px;
    transition: color 0.2s, background 0.2s;
    white-space: nowrap;
}
.gm-links .gm-link:hover,
.gm-links .gm-link.active {
    color: #2E7D32;
    background: #f0faf3;
}
.gm-links .gm-link.active::after {
    content: '';
    position: absolute; bottom: 4px; left: 50%; transform: translateX(-50%);
    width: 18px; height: 3px; border-radius: 2px;
    background: linear-gradient(90deg, #2E7D32, #4CAF50);
}
/* Category dropdown */
.gm-dropdown { position: relative; }
.gm-dropdown-toggle { cursor: pointer; display: flex; align-items: center; gap: 5px; }
.gm-dropdown-toggle i.chevron { font-size: 10px; transition: transform 0.25s; }
.gm-dropdown.show .chevron,
.gm-dropdown:hover .chevron { transform: rotate(180deg); }
.gm-dropdown-menu {
    display: none; position: absolute;
    top: calc(100% + 8px); left: 0;
    background: #fff; border-radius: 18px;
    min-width: 220px;
    box-shadow: 0 16px 48px rgba(0,0,0,0.12);
    border: 1px solid #f0f4f0;
    padding: 8px; z-index: 2000;
}
.gm-dropdown-menu::before {
    content: ''; position: absolute; top: -14px; left: 0; right: 0; height: 14px;
}
.gm-dropdown.show .gm-dropdown-menu,
.gm-dropdown:hover .gm-dropdown-menu { display: block; animation: dropFade 0.2s ease; }
@keyframes dropFade { from { opacity:0; transform: translateY(-8px); } to { opacity:1; transform: translateY(0); } }
.gm-dropdown-item {
    display: flex; align-items: center; gap: 10px;
    padding: 10px 14px; border-radius: 12px;
    font-size: 13px; font-weight: 500; color: #333;
    text-decoration: none; transition: all 0.15s;
}
.gm-dropdown-item:hover { background: #f0faf3; color: #2E7D32; }
.gm-dropdown-item .cat-dot {
    width: 8px; height: 8px; border-radius: 50%;
    background: linear-gradient(135deg, #4CAF50, #00C853); flex-shrink: 0;
}
.gm-dropdown-divider { height: 1px; background: #f5f5f5; margin: 6px 8px; }
.gm-view-all {
    display: block; text-align: center; padding: 10px 14px;
    font-size: 12px; font-weight: 700; color: #2E7D32;
    background: #f0faf3; border-radius: 12px; text-decoration: none;
    margin-top: 4px; letter-spacing: 0.3px; transition: background 0.2s;
}
.gm-view-all:hover { background: #e0f5e4; }

/* ── SEARCH BAR ───────────────────────────────────────────────────────── */
.gm-search-wrap {
    flex: 1; margin: 0 24px;
    max-width: 420px; position: relative;
}
.gm-search-inner {
    display: flex; align-items: center;
    background: #f5f8f5; border: 2px solid transparent;
    border-radius: 50px; overflow: hidden;
    transition: border-color 0.25s, box-shadow 0.25s, background 0.25s;
}
.gm-search-inner:focus-within {
    background: #fff;
    border-color: #4CAF50;
    box-shadow: 0 0 0 4px rgba(76,175,80,0.1);
}
.gm-search-icon {
    width: 46px; display: flex; align-items: center; justify-content: center;
    color: #aaa; font-size: 14px; flex-shrink: 0;
    transition: color 0.2s;
}
.gm-search-inner:focus-within .gm-search-icon { color: #2E7D32; }
.gm-search-input {
    flex: 1; border: none; background: transparent; outline: none;
    font-size: 13.5px; font-family: 'Poppins', sans-serif;
    color: #333; padding: 11px 4px 11px 0;
}
.gm-search-input::placeholder { color: #bbb; }
.gm-search-btn {
    margin: 5px; width: 38px; height: 38px; flex-shrink: 0;
    background: linear-gradient(135deg, #2E7D32, #4CAF50);
    border: none; border-radius: 50px; color: #fff;
    font-size: 14px; cursor: pointer; display: flex;
    align-items: center; justify-content: center;
    transition: transform 0.2s, box-shadow 0.2s;
    box-shadow: 0 3px 10px rgba(76,175,80,0.3);
}
.gm-search-btn:hover { transform: scale(1.08); box-shadow: 0 5px 14px rgba(76,175,80,0.4); }

/* Live search dropdown */
.gm-live-drop {
    display: none; position: absolute;
    top: calc(100% + 8px); left: 0; right: 0;
    background: #fff; border-radius: 18px;
    box-shadow: 0 12px 40px rgba(0,0,0,0.12);
    border: 1px solid #f0f4f0;
    overflow: hidden; max-height: 420px; overflow-y: auto;
    z-index: 3000;
}
.ls-item {
    display: flex; align-items: center; gap: 12px;
    padding: 10px 16px; cursor: pointer;
    text-decoration: none; color: inherit; transition: background 0.15s;
    border-bottom: 1px solid #f8f8f8;
}
.ls-item:last-child { border-bottom: none; }
.ls-item:hover, .ls-item.ls-active { background: #f0faf3; }
.ls-img { width: 44px; height: 44px; object-fit: contain; border-radius: 10px; background: #f5f5f5; flex-shrink: 0; }
.ls-img-ph { width: 44px; height: 44px; border-radius: 10px; background: #f0faf3; display: flex; align-items: center; justify-content: center; flex-shrink: 0; color: #4CAF50; font-size: 18px; }
.ls-name  { font-size: 13px; font-weight: 600; color: #222; line-height: 1.3; }
.ls-meta  { font-size: 11px; color: #aaa; margin-top: 2px; }
.ls-price { font-size: 14px; font-weight: 700; color: #2E7D32; white-space: nowrap; margin-left: auto; text-align: right; }
.ls-orig  { font-size: 11px; color: #ccc; text-decoration: line-through; }
.ls-badge { font-size: 10px; background: #e8f5e9; color: #2E7D32; border-radius: 6px; padding: 1px 6px; margin-left: 6px; }
.ls-footer { display: block; text-align: center; padding: 11px; font-size: 13px; color: #2E7D32; font-weight: 600; background: #f7fdf8; text-decoration: none; transition: background 0.15s; }
.ls-footer:hover { background: #ebf8ed; }
.ls-empty, .ls-loading { padding: 22px; text-align: center; color: #bbb; font-size: 13px; }

/* ── RIGHT ACTIONS ────────────────────────────────────────────────────── */
.gm-actions { display: flex; align-items: center; gap: 4px; flex-shrink: 0; }

/* Icon buttons (wishlist / cart) */
.gm-icon-btn {
    position: relative; width: 42px; height: 42px;
    border-radius: 12px; display: flex; align-items: center; justify-content: center;
    color: #555; font-size: 18px; text-decoration: none;
    transition: background 0.2s, color 0.2s, transform 0.2s;
    border: none; background: transparent; cursor: pointer;
}
.gm-icon-btn:hover { background: #f0faf3; color: #2E7D32; transform: translateY(-1px); }
.gm-icon-btn .gm-badge {
    position: absolute; top: 4px; right: 4px;
    width: 18px; height: 18px; border-radius: 50%;
    background: linear-gradient(135deg, #FF6F00, #FFA000);
    color: #fff; font-size: 10px; font-weight: 700;
    display: flex; align-items: center; justify-content: center;
    border: 2px solid #fff;
    box-shadow: 0 2px 6px rgba(255,111,0,0.4);
    animation: popBadge 0.3s cubic-bezier(0.34,1.56,0.64,1);
}
@keyframes popBadge { from{transform:scale(0)} to{transform:scale(1)} }

/* Divider */
.gm-divider { width: 1px; height: 28px; background: #e8e8e8; margin: 0 8px; }

/* Sign In / Register buttons */
.gm-btn-signin {
    padding: 9px 20px; border-radius: 50px; font-size: 13px; font-weight: 600;
    border: 2px solid #2E7D32; color: #2E7D32; background: transparent;
    text-decoration: none; transition: all 0.2s; white-space: nowrap;
}
.gm-btn-signin:hover { background: #f0faf3; color: #2E7D32; }
.gm-btn-register {
    padding: 9px 20px; border-radius: 50px; font-size: 13px; font-weight: 700;
    background: linear-gradient(135deg, #2E7D32, #4CAF50);
    color: #fff !important; border: none; text-decoration: none;
    box-shadow: 0 4px 14px rgba(76,175,80,0.35);
    transition: all 0.2s; white-space: nowrap;
}
.gm-btn-register:hover { transform: translateY(-2px); box-shadow: 0 7px 20px rgba(76,175,80,0.45); }

/* User Avatar & Dropdown */
.gm-user-btn {
    display: flex; align-items: center; gap: 9px;
    padding: 6px 14px 6px 6px;
    background: #f5f8f5; border: 2px solid #e0ece0;
    border-radius: 50px; cursor: pointer; text-decoration: none;
    transition: all 0.2s; position: relative;
}
.gm-user-btn:hover { background: #ebf5eb; border-color: #4CAF50; box-shadow: 0 4px 14px rgba(76,175,80,0.15); }
.gm-avatar {
    width: 32px; height: 32px; border-radius: 50%;
    background: linear-gradient(135deg, #2E7D32, #66BB6A);
    color: #fff; font-size: 13px; font-weight: 800;
    display: flex; align-items: center; justify-content: center;
    flex-shrink: 0;
}
.gm-user-name { font-size: 13px; font-weight: 600; color: #2E7D32; }
.gm-user-btn .fa-chevron-down { font-size: 10px; color: #88b888; transition: transform 0.25s; }
.gm-user-drop { position: relative; }
.gm-user-drop.show .fa-chevron-down,
.gm-user-drop:hover .fa-chevron-down { transform: rotate(180deg); }

/* User dropdown panel */
.gm-user-menu {
    display: none; position: absolute;
    top: calc(100% + 8px); right: 0;
    background: #fff; border-radius: 18px;
    min-width: 220px;
    box-shadow: 0 16px 48px rgba(0,0,0,0.13);
    border: 1px solid #f0f4f0;
    padding: 8px; z-index: 2000;
}
.gm-user-menu::before {
    content: ''; position: absolute; top: -14px; left: 0; right: 0; height: 14px;
}
.gm-user-drop.show .gm-user-menu,
.gm-user-drop:hover .gm-user-menu { display: block; animation: dropFade 0.2s ease; }
/* Header strip in user menu */
.gm-user-header {
    display: flex; align-items: center; gap: 10px;
    padding: 12px 14px 10px; border-bottom: 1px solid #f5f5f5; margin-bottom: 6px;
}
.gm-user-header .av-lg {
    width: 40px; height: 40px; border-radius: 50%;
    background: linear-gradient(135deg, #2E7D32, #66BB6A);
    color: #fff; font-size: 17px; font-weight: 800;
    display: flex; align-items: center; justify-content: center; flex-shrink: 0;
}
.gm-user-header .uh-name  { font-size: 14px; font-weight: 700; color: #1a1a1a; line-height: 1.2; }
.gm-user-header .uh-email { font-size: 11px; color: #aaa; }
.gm-menu-item {
    display: flex; align-items: center; gap: 10px;
    padding: 10px 14px; border-radius: 12px;
    font-size: 13px; font-weight: 500; color: #333;
    text-decoration: none; transition: all 0.15s;
}
.gm-menu-item:hover { background: #f0faf3; color: #2E7D32; }
.gm-menu-item .mi-icon {
    width: 30px; height: 30px; border-radius: 8px;
    background: #f5f8f5; display: flex; align-items: center; justify-content: center;
    font-size: 13px; color: #666; flex-shrink: 0;
}
.gm-menu-item:hover .mi-icon { background: #e0f0e0; color: #2E7D32; }
.gm-menu-item.danger { color: #d32f2f; }
.gm-menu-item.danger .mi-icon { background: #fde8e8; color: #d32f2f; }
.gm-menu-item.danger:hover { background: #fdf0f0; }
.gm-menu-divider { height: 1px; background: #f5f5f5; margin: 6px 8px; }
.gm-admin-badge {
    display: flex; align-items: center; gap: 10px;
    padding: 10px 14px; border-radius: 12px;
    font-size: 13px; font-weight: 600; color: #1565C0;
    text-decoration: none; background: #EEF3FB; transition: background 0.15s;
}
.gm-admin-badge:hover { background: #E1ECFF; }
.gm-admin-badge .mi-icon { background: #dde8f8; color: #1565C0; }

/* ── MOBILE TOGGLE ────────────────────────────────────────────────────── */
.gm-toggler {
    display: none; width: 40px; height: 40px; border-radius: 10px;
    background: #f5f8f5; border: none; cursor: pointer;
    flex-direction: column; align-items: center; justify-content: center; gap: 5px;
    transition: background 0.2s;
}
.gm-toggler:hover { background: #e0ece0; }
.gm-toggler span { display: block; width: 22px; height: 2px; background: #2E7D32; border-radius: 2px; transition: all 0.3s; }
.gm-toggler.open span:nth-child(1) { transform: translateY(7px) rotate(45deg); }
.gm-toggler.open span:nth-child(2) { opacity: 0; }
.gm-toggler.open span:nth-child(3) { transform: translateY(-7px) rotate(-45deg); }

/* ── MOBILE MENU ──────────────────────────────────────────────────────── */
.gm-mobile-menu {
    display: none; background: #fff; border-top: 1px solid #f0f4f0;
    padding: 16px; animation: slideDown 0.25s ease;
}
.gm-mobile-menu.open { display: block; }
@keyframes slideDown { from{opacity:0;transform:translateY(-8px)} to{opacity:1;transform:translateY(0)} }
.gm-mobile-link {
    display: block; padding: 11px 16px; border-radius: 12px;
    font-size: 14px; font-weight: 500; color: #333; text-decoration: none;
    transition: all 0.15s; margin-bottom: 2px;
}
.gm-mobile-link:hover, .gm-mobile-link.active { background: #f0faf3; color: #2E7D32; }
.gm-mobile-search {
    display: flex; align-items: center;
    background: #f5f8f5; border: 2px solid transparent;
    border-radius: 50px; overflow: hidden; margin-bottom: 14px;
    transition: border-color 0.2s;
}
.gm-mobile-search:focus-within { border-color: #4CAF50; background: #fff; }
.gm-mobile-search input { flex:1; border:none; background:transparent; outline:none; padding:10px 12px; font-size:14px; font-family:'Poppins',sans-serif; }
.gm-mobile-search button { width:40px; height:36px; border:none; background:linear-gradient(135deg,#2E7D32,#4CAF50); color:#fff; border-radius:50px; margin:3px; cursor:pointer; }
.gm-mobile-actions { display:flex; gap:8px; margin-top:14px; }
.gm-mobile-actions a { flex:1; text-align:center; padding:10px; border-radius:12px; font-size:13px; font-weight:600; text-decoration:none; transition:all 0.2s; }
.gm-mobile-signin { border:2px solid #2E7D32; color:#2E7D32; }
.gm-mobile-signin:hover { background:#f0faf3; }
.gm-mobile-register { background:linear-gradient(135deg,#2E7D32,#4CAF50); color:#fff !important; }

@media (max-width: 991px) {
    .gm-nav-inner .gm-links, .gm-search-wrap, .gm-actions { display: none !important; }
    .gm-toggler { display: flex; }
}
</style>

<nav class="gm-nav">
    <div class="container">
        <div class="gm-nav-inner">

            <!-- Logo -->
            <a href="index.php" class="gm-logo">
                <div class="gm-logo-icon"><i class="fa-solid fa-basket-shopping"></i></div>
                <span class="gm-logo-text">Grocery<span>Mart</span></span>
            </a>

            <!-- Nav Links -->
            <ul class="gm-links">
                <li>
                    <a href="index.php" class="gm-link <?php echo $current_page === 'index.php' ? 'active' : ''; ?>">Home</a>
                </li>
                <li class="gm-dropdown">
                    <span class="gm-link gm-dropdown-toggle">
                        Categories <i class="fa-solid fa-chevron-down chevron"></i>
                    </span>
                    <div class="gm-dropdown-menu">
                        <a href="shop.php" class="gm-dropdown-item" style="font-weight:700;color:#2E7D32;">
                            <i class="fa-solid fa-th-large" style="color:#4CAF50;font-size:13px;"></i> All Categories
                        </a>
                        <div class="gm-dropdown-divider"></div>
                        <?php foreach ($nav_categories as $cat): ?>
                            <a href="shop.php?category=<?php echo $cat['id']; ?>" class="gm-dropdown-item">
                                <span class="cat-dot"></span>
                                <?php echo htmlspecialchars($cat['name']); ?>
                            </a>
                        <?php endforeach; ?>
                        <a href="shop.php" class="gm-view-all mt-1">
                            <i class="fa-solid fa-arrow-right me-1"></i> Browse All
                        </a>
                    </div>
                </li>
                <li>
                    <a href="shop.php" class="gm-link <?php echo $current_page === 'shop.php' ? 'active' : ''; ?>">Shop</a>
                </li>
                <li>
                    <a href="contact.php" class="gm-link <?php echo $current_page === 'contact.php' ? 'active' : ''; ?>">Contact</a>
                </li>
            </ul>

            <!-- Search Bar -->
            <div class="gm-search-wrap">
                <form action="shop.php" method="GET" id="navSearchForm" autocomplete="off">
                    <div class="gm-search-inner">
                        <div class="gm-search-icon"><i class="fa-solid fa-magnifying-glass"></i></div>
                        <input
                            class="gm-search-input"
                            type="search"
                            id="liveSearchInput"
                            name="search"
                            placeholder="Search fruits, milk, rice…"
                            value="<?php echo htmlspecialchars($_GET['search'] ?? ''); ?>"
                            autocomplete="off"
                        >
                        <button class="gm-search-btn" type="submit" aria-label="Search">
                            <i class="fa-solid fa-magnifying-glass"></i>
                        </button>
                    </div>
                </form>
                <!-- Live search results -->
                <div id="liveSearchDropdown" class="gm-live-drop">
                    <div id="liveSearchResults"></div>
                </div>
            </div>

            <!-- Right Actions -->
            <div class="gm-actions">
                <!-- Wishlist -->
                <a href="wishlist.php" class="gm-icon-btn" title="Wishlist">
                    <i class="fa-regular fa-heart"></i>
                    <?php if ($wishlist_count > 0): ?>
                        <span class="gm-badge"><?php echo $wishlist_count; ?></span>
                    <?php endif; ?>
                </a>

                <!-- Cart -->
                <a href="cart.php" class="gm-icon-btn" title="Cart">
                    <i class="fa-solid fa-bag-shopping"></i>
                    <span class="gm-badge" id="cart-badge-count" <?php echo $cart_count > 0 ? '' : 'style="display:none"'; ?>>
                        <?php echo $cart_count; ?>
                    </span>
                </a>

                <div class="gm-divider"></div>

                <!-- Auth section -->
                <?php if (isset($_SESSION['user_id'])): ?>
                    <div class="gm-user-drop">
                        <a class="gm-user-btn" href="#" role="button">
                            <div class="gm-avatar"><?php echo $user_initial; ?></div>
                            <span class="gm-user-name d-none d-xl-inline"><?php echo htmlspecialchars($first_name); ?></span>
                            <i class="fa-solid fa-chevron-down"></i>
                        </a>
                        <div class="gm-user-menu">
                            <!-- User header -->
                            <div class="gm-user-header">
                                <div class="av-lg"><?php echo $user_initial; ?></div>
                                <div>
                                    <div class="uh-name"><?php echo htmlspecialchars($_SESSION['user_name']); ?></div>
                                    <div class="uh-email"><?php echo htmlspecialchars($_SESSION['user_email'] ?? ''); ?></div>
                                </div>
                            </div>
                            <a href="profile.php" class="gm-menu-item">
                                <div class="mi-icon"><i class="fa-solid fa-gauge-high"></i></div> My Dashboard
                            </a>
                            <a href="profile.php?page=orders" class="gm-menu-item">
                                <div class="mi-icon"><i class="fa-solid fa-box-open"></i></div> My Orders
                            </a>
                            <a href="wishlist.php" class="gm-menu-item">
                                <div class="mi-icon"><i class="fa-regular fa-heart"></i></div> Wishlist
                            </a>
                            <a href="profile.php?page=addresses" class="gm-menu-item">
                                <div class="mi-icon"><i class="fa-solid fa-location-dot"></i></div> Saved Addresses
                            </a>
                            <?php if (isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'admin'): ?>
                                <div class="gm-menu-divider"></div>
                                <a href="admin/dashboard.php" class="gm-admin-badge">
                                    <div class="mi-icon" style="background:#dde8f8;color:#1565C0;width:30px;height:30px;border-radius:8px;display:flex;align-items:center;justify-content:center;">
                                        <i class="fa-solid fa-shield-halved"></i>
                                    </div> Admin Panel
                                </a>
                            <?php endif; ?>
                            <div class="gm-menu-divider"></div>
                            <a href="login.php?logout=1" class="gm-menu-item danger">
                                <div class="mi-icon"><i class="fa-solid fa-right-from-bracket"></i></div> Sign Out
                            </a>
                        </div>
                    </div>

                <?php elseif (isset($_SESSION['admin_id'])): ?>
                    <div class="gm-user-drop">
                        <a class="gm-user-btn" href="#" role="button">
                            <div class="gm-avatar" style="background:linear-gradient(135deg,#1565C0,#2196F3);">A</div>
                            <span class="gm-user-name d-none d-xl-inline">Admin</span>
                            <i class="fa-solid fa-chevron-down"></i>
                        </a>
                        <div class="gm-user-menu">
                            <a href="admin/dashboard.php" class="gm-admin-badge">
                                <div class="mi-icon" style="background:#dde8f8;color:#1565C0;width:30px;height:30px;border-radius:8px;display:flex;align-items:center;justify-content:center;flex-shrink:0;">
                                    <i class="fa-solid fa-gauge"></i>
                                </div> Admin Dashboard
                            </a>
                            <div class="gm-menu-divider"></div>
                            <a href="admin/login.php?logout=1" class="gm-menu-item danger">
                                <div class="mi-icon"><i class="fa-solid fa-right-from-bracket"></i></div> Sign Out
                            </a>
                        </div>
                    </div>

                <?php else: ?>
                    <a href="login.php" class="gm-btn-signin">Sign In</a>
                    <a href="register.php" class="gm-btn-register">Get Started</a>
                <?php endif; ?>
            </div>

            <!-- Mobile Hamburger -->
            <button class="gm-toggler" id="gmToggler" aria-label="Menu">
                <span></span><span></span><span></span>
            </button>
        </div>
    </div>

    <!-- Mobile Menu -->
    <div class="gm-mobile-menu" id="gmMobileMenu">
        <div class="container">
            <!-- Mobile search -->
            <form class="gm-mobile-search" action="shop.php" method="GET">
                <input type="search" name="search" placeholder="Search for groceries…" value="<?php echo htmlspecialchars($_GET['search'] ?? ''); ?>">
                <button type="submit"><i class="fa-solid fa-magnifying-glass"></i></button>
            </form>
            <!-- Links -->
            <a href="index.php" class="gm-mobile-link <?php echo $current_page === 'index.php' ? 'active' : ''; ?>">
                <i class="fa-solid fa-house me-2"></i>Home
            </a>
            <a href="shop.php" class="gm-mobile-link <?php echo $current_page === 'shop.php' ? 'active' : ''; ?>">
                <i class="fa-solid fa-store me-2"></i>Shop
            </a>
            <?php foreach ($nav_categories as $cat): ?>
                <a href="shop.php?category=<?php echo $cat['id']; ?>" class="gm-mobile-link" style="padding-left:32px;font-size:13px;color:#666;">
                    · <?php echo htmlspecialchars($cat['name']); ?>
                </a>
            <?php endforeach; ?>
            <a href="contact.php" class="gm-mobile-link <?php echo $current_page === 'contact.php' ? 'active' : ''; ?>">
                <i class="fa-solid fa-envelope me-2"></i>Contact
            </a>
            <!-- Mobile auth -->
            <?php if (isset($_SESSION['user_id'])): ?>
                <div class="gm-mobile-link" style="background:#f0faf3;border-radius:12px;margin-top:8px;">
                    <strong><?php echo htmlspecialchars($_SESSION['user_name']); ?></strong>
                    <span style="color:#aaa;font-size:12px;display:block;"><?php echo htmlspecialchars($_SESSION['user_email'] ?? ''); ?></span>
                </div>
                <a href="profile.php" class="gm-mobile-link"><i class="fa-solid fa-gauge-high me-2"></i>Dashboard</a>
                <a href="cart.php" class="gm-mobile-link"><i class="fa-solid fa-bag-shopping me-2"></i>Cart <?php echo $cart_count > 0 ? "($cart_count)" : ''; ?></a>
                <a href="wishlist.php" class="gm-mobile-link"><i class="fa-regular fa-heart me-2"></i>Wishlist</a>
                <a href="login.php?logout=1" class="gm-mobile-link" style="color:#d32f2f;"><i class="fa-solid fa-right-from-bracket me-2"></i>Sign Out</a>
            <?php else: ?>
                <div class="gm-mobile-actions">
                    <a href="login.php" class="gm-mobile-signin">Sign In</a>
                    <a href="register.php" class="gm-mobile-register">Get Started</a>
                </div>
            <?php endif; ?>
        </div>
    </div>
</nav>

<!-- Flash alerts -->
<?php if (isset($_SESSION['success']) || isset($_SESSION['error'])): ?>
<div class="container mt-3">
    <?php if (isset($_SESSION['success'])): ?>
        <div class="alert alert-success alert-dismissible fade show rounded-4 border-0 shadow-sm" role="alert" style="background:#e8f5e9;color:#1b5e20;">
            <i class="fa-solid fa-circle-check me-2"></i>
            <?php echo htmlspecialchars($_SESSION['success']); unset($_SESSION['success']); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>
    <?php if (isset($_SESSION['error'])): ?>
        <div class="alert alert-danger alert-dismissible fade show rounded-4 border-0 shadow-sm" role="alert">
            <i class="fa-solid fa-circle-exclamation me-2"></i>
            <?php echo htmlspecialchars($_SESSION['error']); unset($_SESSION['error']); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>
</div>
<?php endif; ?>

<!-- Live Search + Mobile Toggle Scripts -->
<script>
// Mobile menu toggle
(function() {
    const btn  = document.getElementById('gmToggler');
    const menu = document.getElementById('gmMobileMenu');
    if (!btn) return;
    btn.addEventListener('click', function() {
        this.classList.toggle('open');
        menu.classList.toggle('open');
    });
})();

// Live search
(function() {
    const input      = document.getElementById('liveSearchInput');
    const dropdown   = document.getElementById('liveSearchDropdown');
    const resultsBox = document.getElementById('liveSearchResults');
    if (!input) return;

    const BASE = '/GroceryMart/GroceryMart/api/search.php';
    let timer = null, activeIdx = -1;

    function show() { dropdown.style.display = 'block'; }
    function hide() { dropdown.style.display = 'none'; activeIdx = -1; }

    function setActive(i) {
        const items = resultsBox.querySelectorAll('.ls-item');
        items.forEach((el, j) => el.classList.toggle('ls-active', j === i));
        activeIdx = i;
    }

    function escH(s) {
        return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
    }

    function render(products, q) {
        if (!products.length) {
            resultsBox.innerHTML = `<div class="ls-empty"><i class="fa-solid fa-face-meh me-2"></i>No results for "<b>${escH(q)}</b>"</div>`;
            show(); return;
        }
        let html = '';
        products.forEach((p, i) => {
            const img = p.image
                ? `<img class="ls-img" src="${escH(p.image)}" alt="" onerror="this.style.display='none';this.nextSibling.style.display='flex'">`
                  + `<div class="ls-img-ph" style="display:none"><i class="fa-solid fa-leaf"></i></div>`
                : `<div class="ls-img-ph"><i class="fa-solid fa-leaf"></i></div>`;
            const badge = p.discount > 0 ? `<span class="ls-badge">${p.discount}% OFF</span>` : '';
            const orig  = p.discount > 0 ? `<div class="ls-orig">₹${p.original_price}</div>` : '';
            html += `<a class="ls-item" href="product.php?id=${p.id}">${img}
                <div style="flex:1;min-width:0">
                    <div class="ls-name">${escH(p.name)}${badge}</div>
                    <div class="ls-meta">${escH(p.brand || p.category)}</div>
                </div>
                <div style="text-align:right"><div class="ls-price">₹${p.price}</div>${orig}</div>
            </a>`;
        });
        html += `<a class="ls-footer" href="shop.php?search=${encodeURIComponent(q)}"><i class="fa-solid fa-magnifying-glass me-1"></i>See all results for "${escH(q)}"</a>`;
        resultsBox.innerHTML = html;
        show(); activeIdx = -1;
    }

    function search(q) {
        if (q.length < 2) { hide(); return; }
        resultsBox.innerHTML = '<div class="ls-loading"><i class="fa-solid fa-circle-notch fa-spin me-2"></i>Searching…</div>';
        show();
        fetch(BASE + '?q=' + encodeURIComponent(q))
            .then(r => r.json()).then(d => render(d, q)).catch(hide);
    }

    input.addEventListener('input', function() {
        clearTimeout(timer);
        const q = this.value.trim();
        if (q.length < 2) { hide(); return; }
        timer = setTimeout(() => search(q), 260);
    });
    input.addEventListener('keydown', function(e) {
        const items = resultsBox.querySelectorAll('.ls-item');
        if (!items.length) return;
        if (e.key === 'ArrowDown') { e.preventDefault(); setActive(Math.min(activeIdx+1, items.length-1)); }
        else if (e.key === 'ArrowUp')  { e.preventDefault(); setActive(Math.max(activeIdx-1, 0)); }
        else if (e.key === 'Enter' && activeIdx >= 0) { e.preventDefault(); items[activeIdx].click(); }
        else if (e.key === 'Escape') hide();
    });
    input.addEventListener('focus', function() { if (this.value.trim().length >= 2) search(this.value.trim()); });
    document.addEventListener('click', e => { if (!dropdown.contains(e.target) && e.target !== input) hide(); });
})();

// Avatar and Dropdown Click-Toggle Handler
(function() {
    document.querySelectorAll('.gm-user-btn, .gm-dropdown-toggle').forEach(btn => {
        btn.addEventListener('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            const parent = this.closest('.gm-user-drop, .gm-dropdown');
            if (!parent) return;

            const isAlreadyOpen = parent.classList.contains('show');
            // Close any open dropdowns first
            document.querySelectorAll('.gm-user-drop, .gm-dropdown').forEach(d => d.classList.remove('show'));

            if (!isAlreadyOpen) {
                parent.classList.add('show');
            }
        });
    });

    // Close on click outside
    document.addEventListener('click', function(e) {
        if (!e.target.closest('.gm-user-drop, .gm-dropdown')) {
            document.querySelectorAll('.gm-user-drop, .gm-dropdown').forEach(d => d.classList.remove('show'));
        }
    });
})();
</script>

