<?php
$current_page = basename($_SERVER['PHP_SELF']);
?>
<div class="col-lg-3">
    <div class="dashboard-sidebar p-3 shadow-sm bg-white" style="position: sticky; top: 20px;">
        <h6 class="text-muted fw-bold small px-3 mb-3 text-uppercase">Admin Controls</h6>
        <div class="text-start">
            <a href="dashboard.php" class="dashboard-menu-link <?php echo $current_page == 'dashboard.php' ? 'active' : ''; ?>">
                <i class="fa-solid fa-chart-line text-muted"></i> Dashboard Overview
            </a>
            <a href="categories.php" class="dashboard-menu-link <?php echo $current_page == 'categories.php' ? 'active' : ''; ?>">
                <i class="fa-solid fa-list-check text-muted"></i> Categories Manager
            </a>
            <a href="products.php" class="dashboard-menu-link <?php echo $current_page == 'products.php' ? 'active' : ''; ?>">
                <i class="fa-solid fa-boxes-packing text-muted"></i> Products & Inventory
            </a>
            <a href="orders.php" class="dashboard-menu-link <?php echo $current_page == 'orders.php' ? 'active' : ''; ?>">
                <i class="fa-solid fa-clipboard-list text-muted"></i> Orders Fulfilment
            </a>
            <a href="coupons.php" class="dashboard-menu-link <?php echo $current_page == 'coupons.php' ? 'active' : ''; ?>">
                <i class="fa-solid fa-tags text-muted"></i> Coupons Manager
            </a>
            <a href="queries.php" class="dashboard-menu-link <?php echo $current_page == 'queries.php' ? 'active' : ''; ?>">
                <i class="fa-solid fa-envelope-open-text text-muted"></i> Contact Queries
            </a>
            
            <hr class="my-3">
            
            <a href="../index.php" class="dashboard-menu-link text-success fw-bold">
                <i class="fa-solid fa-arrow-up-right-from-square"></i> Visit Public Site
            </a>
        </div>
    </div>
</div>

<div class="col-lg-9">
    <!-- Success/Error alert alerts (Global Admin) -->
    <?php if (isset($_SESSION['success'])): ?>
        <div class="alert alert-success alert-dismissible fade show alert-custom mb-4" role="alert">
            <i class="fa-solid fa-circle-check me-2"></i> <?php echo $_SESSION['success']; unset($_SESSION['success']); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <?php if (isset($_SESSION['error'])): ?>
        <div class="alert alert-danger alert-dismissible fade show alert-custom mb-4" role="alert">
            <i class="fa-solid fa-circle-exclamation me-2"></i> <?php echo $_SESSION['error']; unset($_SESSION['error']); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>
