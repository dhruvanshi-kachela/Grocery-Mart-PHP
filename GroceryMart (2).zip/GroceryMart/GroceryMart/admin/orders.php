<?php
$page_title = "Orders Fulfilment";
require_once __DIR__ . '/../includes/admin-header.php';
require_once __DIR__ . '/../includes/admin-sidebar.php';
require_once __DIR__ . '/../models/Order.php';
require_once __DIR__ . '/../includes/utils.php';

$db         = getDB();
$orderModel = new Order();

// ── Handle Status Update ──────────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'update_status') {
    $orderId = intval($_POST['order_id']     ?? 0);
    $status  = trim($_POST['order_status']   ?? '');
    $payStatus = trim($_POST['payment_status'] ?? '');
    $allowedStatuses = ['Placed','Packed','Shipped','Out for Delivery','Delivered','Cancelled'];

    if ($orderId > 0 && in_array($status, $allowedStatuses)) {
        $orderModel->updateStatus($orderId, $status);
        if (!empty($payStatus)) {
            $orderModel->updatePaymentStatus($orderId, $payStatus);
        }
        $_SESSION['success'] = "Order #GM-" . str_pad($orderId, 6, '0', STR_PAD_LEFT) . " status updated!";
    } else {
        $_SESSION['error'] = "Invalid status update.";
    }
    header("Location: orders.php"); exit();
}

// ── Fetch Orders ──────────────────────────────────────────────────────────────
$filter_status = trim($_GET['status'] ?? '');
$search_id     = intval($_GET['search_id'] ?? 0);

$where  = "WHERE 1=1";
$params = [];
if (!empty($filter_status)) {
    $where .= " AND o.order_status = :status";
    $params['status'] = $filter_status;
}
if ($search_id > 0) {
    $where .= " AND o.id = :oid";
    $params['oid'] = $search_id;
}

$stmt = $db->prepare("
    SELECT o.*, u.name as user_name, u.email as user_email,
           a.full_address, a.city, a.state, a.zipcode
    FROM orders o
    JOIN users u ON o.user_id = u.id
    LEFT JOIN addresses a ON o.address_id = a.id
    $where
    ORDER BY o.id DESC
");
$stmt->execute($params);
$orders = $stmt->fetchAll();

$statuses = ['Placed','Packed','Shipped','Out for Delivery','Delivered','Cancelled'];
$statusColors = [
    'Placed'           => 'bg-primary-subtle text-primary border-primary-subtle',
    'Packed'           => 'bg-warning-subtle text-warning border-warning-subtle',
    'Shipped'          => 'bg-info-subtle text-info border-info-subtle',
    'Out for Delivery' => 'bg-warning-subtle text-warning border-warning-subtle',
    'Delivered'        => 'bg-success-subtle text-success border-success-subtle',
    'Cancelled'        => 'bg-danger-subtle text-danger border-danger-subtle',
];
?>

<!-- Header + Filter Bar -->
<div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-3">
    <h5 class="fw-bold mb-0"><i class="fa-solid fa-cart-flatbed-suitcases text-success me-2"></i>Orders Fulfilment</h5>
    <form class="d-flex gap-2 flex-wrap" method="GET" action="orders.php">
        <input type="number" class="form-control form-control-sm rounded-pill px-3" name="search_id" placeholder="Order ID..." value="<?php echo $search_id ?: ''; ?>" style="width:130px;">
        <select class="form-select form-select-sm rounded-pill px-3" name="status" style="width:180px;">
            <option value="">All Statuses</option>
            <?php foreach ($statuses as $s): ?>
                <option value="<?php echo $s; ?>" <?php echo $filter_status===$s?'selected':''; ?>><?php echo $s; ?></option>
            <?php endforeach; ?>
        </select>
        <button class="btn btn-primary-custom btn-sm rounded-pill px-3" type="submit"><i class="fa-solid fa-filter me-1"></i>Filter</button>
        <a href="orders.php" class="btn btn-outline-secondary btn-sm rounded-pill px-3">Reset</a>
    </form>
</div>

<div class="card card-custom p-4 border-0 shadow-sm bg-white">
    <?php if (!empty($orders)): ?>
        <div class="table-responsive">
            <table class="table align-middle small mb-0">
                <thead>
                    <tr class="text-muted">
                        <th>Order ID</th>
                        <th>Customer</th>
                        <th>Shipping Address</th>
                        <th class="text-center">Total</th>
                        <th class="text-center">Payment</th>
                        <th class="text-center">Status</th>
                        <th>Date</th>
                        <th class="text-end">Update</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($orders as $o): ?>
                        <tr>
                            <td class="fw-bold">#GM-<?php echo str_pad($o['id'], 6, '0', STR_PAD_LEFT); ?></td>
                            <td>
                                <span class="fw-semibold d-block"><?php echo htmlspecialchars($o['user_name']); ?></span>
                                <span class="text-muted" style="font-size:11px;"><?php echo htmlspecialchars($o['user_email']); ?></span>
                            </td>
                            <td class="text-muted small">
                                <?php echo $o['full_address'] ? htmlspecialchars($o['city'] . ', ' . $o['state'] . ' ' . $o['zipcode']) : '—'; ?>
                            </td>
                            <td class="text-center fw-bold text-success"><?php echo formatPrice($o['total']); ?></td>
                            <td class="text-center">
                                <span class="d-block fw-semibold"><?php echo htmlspecialchars($o['payment_method']); ?></span>
                                <span class="badge rounded-pill <?php echo $o['payment_status']==='Paid' ? 'bg-success-subtle text-success border border-success-subtle' : 'bg-warning-subtle text-warning border border-warning-subtle'; ?> border" style="font-size:10px;">
                                    <?php echo htmlspecialchars($o['payment_status']); ?>
                                </span>
                            </td>
                            <td class="text-center">
                                <span class="badge rounded-pill border <?php echo $statusColors[$o['order_status']] ?? 'bg-secondary-subtle text-secondary border-secondary-subtle'; ?>">
                                    <?php echo htmlspecialchars($o['order_status']); ?>
                                </span>
                            </td>
                            <td class="text-muted" style="font-size:11px;"><?php echo date('d M Y', strtotime($o['created_at'])); ?></td>
                            <td class="text-end">
                                <button class="btn btn-sm btn-outline-success border-0 rounded-circle" data-bs-toggle="collapse" data-bs-target="#updateOrder_<?php echo $o['id']; ?>" title="Update Status">
                                    <i class="fa-regular fa-pen-to-square"></i>
                                </button>
                                <div class="collapse text-start mt-3" id="updateOrder_<?php echo $o['id']; ?>">
                                    <div class="card p-3 bg-light border rounded-4" style="min-width:260px;">
                                        <form action="orders.php" method="POST">
                                            <input type="hidden" name="action"   value="update_status">
                                            <input type="hidden" name="order_id" value="<?php echo $o['id']; ?>">
                                            <div class="mb-2">
                                                <label class="form-label small fw-medium">Order Status</label>
                                                <select class="form-select form-select-sm" name="order_status">
                                                    <?php foreach ($statuses as $s): ?>
                                                        <option value="<?php echo $s; ?>" <?php echo $o['order_status']===$s?'selected':''; ?>><?php echo $s; ?></option>
                                                    <?php endforeach; ?>
                                                </select>
                                            </div>
                                            <div class="mb-2">
                                                <label class="form-label small fw-medium">Payment Status</label>
                                                <select class="form-select form-select-sm" name="payment_status">
                                                    <option value="Pending"  <?php echo $o['payment_status']==='Pending'?'selected':''; ?>>Pending</option>
                                                    <option value="Paid"     <?php echo $o['payment_status']==='Paid'?'selected':''; ?>>Paid</option>
                                                    <option value="Refunded" <?php echo $o['payment_status']==='Refunded'?'selected':''; ?>>Refunded</option>
                                                </select>
                                            </div>
                                            <button type="submit" class="btn btn-success btn-sm rounded-pill px-3">Update</button>
                                        </form>
                                    </div>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <p class="text-muted small mt-3 mb-0">Showing <?php echo count($orders); ?> order(s)</p>
    <?php else: ?>
        <div class="text-center py-5 text-muted">
            <i class="fa-solid fa-box-open fs-1 mb-3 d-block opacity-25"></i>
            <p class="mb-0">No orders found<?php echo $filter_status ? " with status \"$filter_status\"" : ''; ?>.</p>
        </div>
    <?php endif; ?>
</div>

<?php require_once __DIR__ . '/../includes/admin-footer.php'; ?>
