<?php
require_once __DIR__ . '/../models/Product.php';
require_once __DIR__ . '/../models/Category.php';

class ProductController {
    private $productModel;
    private $categoryModel;

    public function __construct() {
        $this->productModel = new Product();
        $this->categoryModel = new Category();
    }

    /**
     * Display Shop Catalog page with filters, sorting, and pagination
     */
    public function shop() {
        // Collect filters from GET request
        $search = trim($_GET['search'] ?? '');
        $category = trim($_GET['category'] ?? '');
        $min_price = isset($_GET['min_price']) && $_GET['min_price'] !== '' ? floatval($_GET['min_price']) : 0;
        $max_price = isset($_GET['max_price']) && $_GET['max_price'] !== '' ? floatval($_GET['max_price']) : 1000;
        $sort = $_GET['sort'] ?? 'newest';
        $page = isset($_GET['page']) ? intval($_GET['page']) : 1;
        if ($page < 1) $page = 1;

        $limit = 9; // 9 products per page
        $offset = ($page - 1) * $limit;

        $filters = [
            'search' => $search,
            'category' => $category,
            'min_price' => $min_price,
            'max_price' => $max_price,
            'sort' => $sort
        ];

        // Fetch products and categories
        $products = $this->productModel->searchAndFilter($filters, $limit, $offset);
        $totalProducts = $this->productModel->getFilteredCount($filters);
        
        $categories = $this->categoryModel->getActiveCategories();
        $totalPages = ceil($totalProducts / $limit);

        // Load view file
        include __DIR__ . '/../views/shop.php';
    }

    /**
     * Display Single Product Details page
     */
    public function details() {
        $productId = isset($_GET['id']) ? intval($_GET['id']) : 0;
        if ($productId <= 0) {
            $_SESSION['error'] = "Product not found.";
            header("Location: shop.php");
            exit();
        }

        $product = $this->productModel->findById($productId);
        if (!$product) {
            $_SESSION['error'] = "Product not found.";
            header("Location: shop.php");
            exit();
        }

        // Fetch related products
        $relatedProducts = [];
        if ($product['category_id']) {
            $relatedProducts = $this->productModel->getRelatedProducts($product['category_id'], $productId, 4);
        }

        // Fetch reviews for this product
        $reviews = [];
        $averageRating = 0;
        try {
            $db = getDB();
            
            // Get reviews list
            $stmt = $db->prepare("
                SELECT r.*, u.name as user_name 
                FROM reviews r 
                JOIN users u ON r.user_id = u.id 
                WHERE r.product_id = :pid 
                ORDER BY r.created_at DESC
            ");
            $stmt->execute(['pid' => $productId]);
            $reviews = $stmt->fetchAll();

            // Calculate average rating
            $stmt_avg = $db->prepare("SELECT AVG(rating) FROM reviews WHERE product_id = :pid");
            $stmt_avg->execute(['pid' => $productId]);
            $averageRating = round(floatval($stmt_avg->fetchColumn()), 1);
        } catch (PDOException $e) {
            error_log("Error fetching product reviews: " . $e->getMessage());
        }

        // Load view file
        include __DIR__ . '/../views/product-details.php';
    }
}
