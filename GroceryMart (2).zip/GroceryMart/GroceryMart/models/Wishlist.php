<?php
require_once __DIR__ . '/../config/db.php';

class Wishlist {
    private $db;

    public function __construct() {
        $this->db = getDB();
    }

    /**
     * Get all wishlist items for a user
     * @param int $userId
     * @return array
     */
    public function getItems($userId) {
        $stmt = $this->db->prepare("
            SELECT w.id as wishlist_id, w.product_id, 
                   p.name, p.price, p.discount, p.stock, p.weight, p.unit, p.image, p.brand
            FROM wishlist w
            JOIN products p ON w.product_id = p.id
            WHERE w.user_id = :user_id
            ORDER BY w.id DESC
        ");
        $stmt->execute(['user_id' => $userId]);
        return $stmt->fetchAll();
    }

    /**
     * Toggle product in wishlist (Add if not exists, remove if exists)
     * @param int $userId
     * @param int $productId
     * @return string 'added' | 'removed'
     */
    public function toggle($userId, $productId) {
        // Check if exists
        $stmt = $this->db->prepare("SELECT id FROM wishlist WHERE user_id = :user_id AND product_id = :product_id");
        $stmt->execute(['user_id' => $userId, 'product_id' => $productId]);
        $existing = $stmt->fetchColumn();

        if ($existing) {
            // Delete
            $delete = $this->db->prepare("DELETE FROM wishlist WHERE id = :id");
            $delete->execute(['id' => $existing]);
            return 'removed';
        } else {
            // Insert
            $insert = $this->db->prepare("INSERT INTO wishlist (user_id, product_id) VALUES (:user_id, :product_id)");
            $insert->execute([
                'user_id' => $userId,
                'product_id' => $productId
            ]);
            return 'added';
        }
    }

    /**
     * Delete item from wishlist
     * @param int $userId
     * @param int $productId
     * @return bool
     */
    public function delete($userId, $productId) {
        $stmt = $this->db->prepare("DELETE FROM wishlist WHERE user_id = :user_id AND product_id = :product_id");
        return $stmt->execute([
            'user_id' => $userId,
            'product_id' => $productId
        ]);
    }
}
