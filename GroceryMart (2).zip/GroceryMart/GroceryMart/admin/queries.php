<?php
$page_title = "Contact Queries";
require_once __DIR__ . '/../includes/admin-header.php';
require_once __DIR__ . '/../includes/admin-sidebar.php';

$db = getDB();

// DELETE a message
if (isset($_GET['delete_id'])) {
    $id = intval($_GET['delete_id']);
    if ($id > 0) {
        $stmt = $db->prepare("DELETE FROM contact_messages WHERE id = :id");
        $ok   = $stmt->execute(['id' => $id]);
        $_SESSION[$ok ? 'success' : 'error'] = $ok ? "Message deleted." : "Failed to delete message.";
    }
    header("Location: queries.php"); exit();
}

// Fetch all contact messages
try {
    $messages = $db->query("SELECT * FROM contact_messages ORDER BY id DESC")->fetchAll();
} catch (PDOException $e) {
    // Table might not have subject column — handle gracefully
    $messages = [];
    $_SESSION['error'] = "Could not load messages: " . $e->getMessage();
}
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h5 class="fw-bold mb-0"><i class="fa-solid fa-envelope-open-text text-success me-2"></i>Contact Queries</h5>
    <span class="badge bg-success-subtle text-success border border-success-subtle rounded-pill px-3 py-2">
        <?php echo count($messages); ?> message(s)
    </span>
</div>

<div class="card card-custom p-4 border-0 shadow-sm bg-white">
    <?php if (!empty($messages)): ?>
        <div class="d-flex flex-column gap-3">
            <?php foreach ($messages as $m): ?>
                <div class="card border rounded-4 p-4 bg-light position-relative">
                    <div class="d-flex justify-content-between align-items-start flex-wrap gap-2 mb-2">
                        <div>
                            <span class="fw-bold text-dark"><?php echo htmlspecialchars($m['name']); ?></span>
                            <a href="mailto:<?php echo htmlspecialchars($m['email']); ?>" class="text-success small ms-2 text-decoration-none">
                                <i class="fa-solid fa-envelope me-1"></i><?php echo htmlspecialchars($m['email']); ?>
                            </a>
                        </div>
                        <div class="d-flex align-items-center gap-2">
                            <span class="text-muted small"><?php echo isset($m['created_at']) ? date('d M Y, h:i A', strtotime($m['created_at'])) : ''; ?></span>
                            <a href="queries.php?delete_id=<?php echo $m['id']; ?>" onclick="return confirm('Delete this message?')" class="btn btn-sm btn-outline-danger border-0 rounded-circle" title="Delete">
                                <i class="fa-regular fa-trash-can"></i>
                            </a>
                        </div>
                    </div>
                    <?php if (!empty($m['subject'] ?? '')): ?>
                        <p class="fw-semibold small mb-1 text-dark">
                            <i class="fa-solid fa-tag me-1 text-success"></i><?php echo htmlspecialchars($m['subject']); ?>
                        </p>
                    <?php endif; ?>
                    <p class="text-muted small mb-0"><?php echo nl2br(htmlspecialchars($m['message'])); ?></p>
                    <a href="mailto:<?php echo htmlspecialchars($m['email']); ?>?subject=Re: <?php echo urlencode($m['subject'] ?? 'Your query'); ?>" class="btn btn-sm btn-outline-success rounded-pill px-3 mt-3">
                        <i class="fa-solid fa-reply me-1"></i> Reply via Email
                    </a>
                </div>
            <?php endforeach; ?>
        </div>
    <?php else: ?>
        <div class="text-center py-5 text-muted">
            <i class="fa-solid fa-inbox fs-1 mb-3 d-block opacity-25"></i>
            <p class="mb-0">No contact messages yet.</p>
        </div>
    <?php endif; ?>
</div>

<?php require_once __DIR__ . '/../includes/admin-footer.php'; ?>
