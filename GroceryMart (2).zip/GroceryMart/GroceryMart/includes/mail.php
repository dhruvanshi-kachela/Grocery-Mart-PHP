<?php
// Mail helper for Grocery Mart
// Simple email sending using PHP mail() function. In production, replace with a robust library like PHPMailer.

if (!function_exists('sendOrderConfirmationEmail')) {
    /**
     * Send order confirmation email to the user.
     * @param int $orderId
     * @param int $userId
     * @return bool Success status
     */
    function sendOrderConfirmationEmail($orderId, $userId) {
        // Load necessary models
        require_once __DIR__ . '/../models/Order.php';
        require_once __DIR__ . '/../models/User.php';
        $orderModel = new Order();
        $userModel = new User();
        $order = $orderModel->findById($orderId);
        $user = $userModel->findById($userId);
        if (!$order || !$user) {
            return false;
        }
        $to = $user['email'];
        $subject = "Your GroceryMart Order #{$order['id']} Confirmation";
        $message = "Hello {$user['name']},\n\n" .
            "Thank you for your purchase! Your order has been placed successfully.\n" .
            "Order ID: {$order['id']}\n" .
            "Total: ₹" . number_format($order['total'], 2) . "\n" .
            "Payment Method: {$order['payment_method']} ({$order['payment_status']})\n\n" .
            "You can view your order details in your account dashboard.\n\n" .
            "Regards,\nGroceryMart Team";
        $headers = "From: no-reply@grocerymart.com\r\n" .
            "Reply-To: support@grocerymart.com\r\n" .
            "X-Mailer: PHP/" . phpversion();
        // Using mail() – returns true on success
        return mail($to, $subject, $message, $headers);
    }
}
?>
