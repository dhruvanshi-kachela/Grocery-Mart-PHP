<?php
$page_title = "Shop Catalog";
include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/navbar.php';
?>

<div class="container my-5">
    <!-- Breadcrumb -->
    <nav aria-label="breadcrumb" class="mb-4">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="index.php" class="text-success text-decoration-none">Home</a></li>
            <li class="breadcrumb-item active" aria-current="page">Shop Catalog</li>
        </ol>
    </nav>

    <div class="row g-4">
        <!-- Sidebar Filters -->
        <div class="col-lg-3">
            <div class="card card-custom p-4">
                <h5 class="fw-bold mb-4"><i class="fa-solid fa-filter text-success me-2"></i>Filters</h5>
                
                <form action="shop.php" method="GET" id="filterForm">
                    <!-- Search Input (Synchronized) -->
                    <div class="mb-4">
                        <label class="form-label small fw-medium text-muted">Keyword Search</label>
                        <input type="text" class="form-control bg-light border-0" placeholder="Product name or brand..." name="search" value="<?php echo htmlspecialchars($search); ?>">
                    </div>

                    <!-- Category filter -->
                    <div class="mb-4">
                        <label class="form-label small fw-medium text-muted mb-2">Category</label>
                        <div class="d-flex flex-column gap-2" style="max-height: 240px; overflow-y: auto; padding-right: 5px;">
                            <a href="shop.php?search=<?php echo urlencode($search); ?>&sort=<?php echo $sort; ?>&min_price=<?php echo $min_price; ?>&max_price=<?php echo $max_price; ?>" class="small text-decoration-none py-1 <?php echo $category === '' ? 'text-success fw-bold' : 'text-dark'; ?>">
                                All Categories
                            </a>
                            <?php foreach ($categories as $cat): ?>
                                <a href="shop.php?category=<?php echo $cat['id']; ?>&search=<?php echo urlencode($search); ?>&sort=<?php echo $sort; ?>&min_price=<?php echo $min_price; ?>&max_price=<?php echo $max_price; ?>" class="small text-decoration-none py-1 <?php echo $category == $cat['id'] ? 'text-success fw-bold' : 'text-dark'; ?>">
                                    <?php echo htmlspecialchars($cat['name']); ?>
                                </a>
                            <?php endforeach; ?>
                            <!-- Preserving category ID in hidden field if form is submitted -->
                            <input type="hidden" name="category" value="<?php echo htmlspecialchars($category); ?>">
                        </div>
                    </div>

                    <!-- Price range -->
                    <div class="mb-4">
                        <label class="form-label small fw-medium text-muted">Price Range (₹)</label>
                        <div class="row g-2">
                            <div class="col-6">
                                <input type="number" class="form-control form-control-sm bg-light border-0" placeholder="Min" name="min_price" value="<?php echo htmlspecialchars($min_price); ?>" min="0">
                            </div>
                            <div class="col-6">
                                <input type="number" class="form-control form-control-sm bg-light border-0" placeholder="Max" name="max_price" value="<?php echo htmlspecialchars($max_price); ?>" min="0">
                            </div>
                        </div>
                    </div>

                    <!-- Sorting -->
                    <div class="mb-4">
                        <label class="form-label small fw-medium text-muted">Sort By</label>
                        <select class="form-select bg-light border-0" name="sort">
                            <option value="newest" <?php echo $sort === 'newest' ? 'selected' : ''; ?>>Newest Arrivals</option>
                            <option value="popularity" <?php echo $sort === 'popularity' ? 'selected' : ''; ?>>Popularity</option>
                            <option value="price_low_high" <?php echo $sort === 'price_low_high' ? 'selected' : ''; ?>>Price: Low to High</option>
                            <option value="price_high_low" <?php echo $sort === 'price_high_low' ? 'selected' : ''; ?>>Price: High to Low</option>
                            <option value="rating" <?php echo $sort === 'rating' ? 'selected' : ''; ?>>Customer Rating</option>
                        </select>
                    </div>

                    <!-- Filter action buttons -->
                    <div class="d-grid gap-2 mt-4">
                        <button type="submit" class="btn btn-primary-custom rounded-pill">Apply Filters</button>
                        <a href="shop.php" class="btn btn-outline-secondary btn-sm rounded-pill text-muted text-decoration-none text-center">Reset All</a>
                    </div>
                </form>
            </div>
        </div>

        <!-- Products Area -->
        <div class="col-lg-9">
            <!-- Results Header -->
            <div class="d-flex justify-content-between align-items-center mb-4 bg-white p-3 rounded-4 shadow-sm border border-light">
                <p class="mb-0 text-muted small">
                    Showing <span class="fw-semibold text-dark"><?php echo count($products); ?></span> of <span class="fw-semibold text-dark"><?php echo $totalProducts; ?></span> products found
                </p>
                <div class="d-flex align-items-center gap-2">
                    <span class="small text-muted d-none d-sm-inline">Sort:</span>
                    <select class="form-select form-select-sm border-0 bg-light rounded-pill px-3" style="width: auto;" onchange="window.location.href = 'shop.php?category=<?php echo $category; ?>&search=<?php echo urlencode($search); ?>&min_price=<?php echo $min_price; ?>&max_price=<?php echo $max_price; ?>&sort=' + this.value">
                        <option value="newest" <?php echo $sort === 'newest' ? 'selected' : ''; ?>>Newest Arrivals</option>
                        <option value="popularity" <?php echo $sort === 'popularity' ? 'selected' : ''; ?>>Popularity</option>
                        <option value="price_low_high" <?php echo $sort === 'price_low_high' ? 'selected' : ''; ?>>Price: Low to High</option>
                        <option value="price_high_low" <?php echo $sort === 'price_high_low' ? 'selected' : ''; ?>>Price: High to Low</option>
                        <option value="rating" <?php echo $sort === 'rating' ? 'selected' : ''; ?>>Customer Rating</option>
                    </select>
                </div>
            </div>

            <!-- Products Grid -->
            <?php if (!empty($products)): ?>
                <div class="row g-4 mb-5">
                    <?php foreach ($products as $prod): ?>
                        <div class="col-sm-6 col-md-4">
                            <div class="card card-custom h-100">
                                <!-- Discount Badge -->
                                <?php if ($prod['discount'] > 0): ?>
                                    <span class="discount-badge"><?php echo round($prod['discount']); ?>% OFF</span>
                                <?php endif; ?>
                                
                                <!-- Wishlist Btn -->
                                <?php 
                                    $in_wishlist = false; 
                                    if (isset($_SESSION['user_id'])) {
                                        $wish_stmt = getDB()->prepare("SELECT COUNT(*) FROM wishlist WHERE user_id = :uid AND product_id = :pid");
                                        $wish_stmt->execute(['uid' => $_SESSION['user_id'], 'pid' => $prod['id']]);
                                        $in_wishlist = $wish_stmt->fetchColumn() > 0;
                                    }
                                ?>
                                <button class="wishlist-btn <?php echo $in_wishlist ? 'active' : ''; ?>" onclick="toggleWishlist(<?php echo $prod['id']; ?>, this)" title="Add to Wishlist">
                                    <i class="<?php echo $in_wishlist ? 'fa-solid' : 'fa-regular'; ?> fa-heart"></i>
                                </button>

                                <!-- Image -->
                                <div class="product-img-wrapper">
                                    <a href="product.php?id=<?php echo $prod['id']; ?>">
                                        <img src="<?php echo getProductImage($prod['image'], $prod['name']); ?>" alt="<?php echo htmlspecialchars($prod['name']); ?>" class="product-img">
                                    </a>
                                </div>
                                
                                <!-- Card Body -->
                                <div class="card-body d-flex flex-column p-3">
                                    <span class="text-muted small mb-1"><?php echo htmlspecialchars($prod['brand'] ?? 'GroceryMart'); ?></span>
                                    <h6 class="card-title mb-2">
                                        <a href="product.php?id=<?php echo $prod['id']; ?>" class="text-dark text-decoration-none fw-semibold">
                                            <?php echo htmlspecialchars($prod['name']); ?>
                                        </a>
                                    </h6>
                                    <div class="small text-muted mb-2">
                                        Unit: <?php echo htmlspecialchars($prod['weight'] ?? '1 unit'); ?>
                                    </div>
                                    
                                    <!-- Ratings -->
                                    <div class="mb-3 text-warning small">
                                        <?php
                                            $rating_val = round($prod['avg_rating'] > 0 ? $prod['avg_rating'] : 4.5);
                                            for ($i = 1; $i <= 5; $i++) {
                                                echo $i <= $rating_val ? '<i class="fa-solid fa-star"></i>' : '<i class="fa-regular fa-star"></i>';
                                            }
                                        ?>
                                        <span class="text-muted ms-1">(<?php echo $prod['avg_rating'] > 0 ? number_format($prod['avg_rating'], 1) : '4.5'; ?>)</span>
                                    </div>

                                    <!-- Price & Add Cart -->
                                    <div class="mt-auto d-flex justify-content-between align-items-center pt-2 border-top">
                                        <div>
                                            <span class="fw-bold text-success fs-5">
                                                <?php echo formatPrice(getDiscountedPrice($prod['price'], $prod['discount'])); ?>
                                            </span>
                                            <?php if ($prod['discount'] > 0): ?>
                                                <br>
                                                <span class="text-muted text-decoration-line-through small">
                                                    <?php echo formatPrice($prod['price']); ?>
                                                </span>
                                            <?php endif; ?>
                                        </div>
                                        <?php if ($prod['stock'] > 0): ?>
                                            <button onclick="addToCart(<?php echo $prod['id']; ?>, 1)" class="btn btn-primary-custom px-3 py-2 rounded-pill small">
                                                <i class="fa-solid fa-plus me-1"></i> Add
                                            </button>
                                        <?php else: ?>
                                            <span class="badge bg-danger rounded-pill px-2 py-1">Out of Stock</span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>

                <!-- Pagination -->
                <?php if ($totalPages > 1): ?>
                    <nav aria-label="Page navigation" class="d-flex justify-content-center">
                        <ul class="pagination">
                            <!-- Previous page -->
                            <li class="page-item <?php echo $page <= 1 ? 'disabled' : ''; ?>">
                                <a class="page-link" href="shop.php?page=<?php echo $page - 1; ?>&category=<?php echo $category; ?>&search=<?php echo urlencode($search); ?>&min_price=<?php echo $min_price; ?>&max_price=<?php echo $max_price; ?>&sort=<?php echo $sort; ?>" aria-label="Previous">
                                    <span aria-hidden="true">&laquo;</span>
                                </a>
                            </li>

                            <!-- Number links -->
                            <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                                <li class="page-item <?php echo $page == $i ? 'active' : ''; ?>">
                                    <a class="page-link <?php echo $page == $i ? 'bg-success border-success text-white' : 'text-success'; ?>" href="shop.php?page=<?php echo $i; ?>&category=<?php echo $category; ?>&search=<?php echo urlencode($search); ?>&min_price=<?php echo $min_price; ?>&max_price=<?php echo $max_price; ?>&sort=<?php echo $sort; ?>">
                                        <?php echo $i; ?>
                                    </a>
                                </li>
                            <?php endfor; ?>

                            <!-- Next page -->
                            <li class="page-item <?php echo $page >= $totalPages ? 'disabled' : ''; ?>">
                                <a class="page-link" href="shop.php?page=<?php echo $page + 1; ?>&category=<?php echo $category; ?>&search=<?php echo urlencode($search); ?>&min_price=<?php echo $min_price; ?>&max_price=<?php echo $max_price; ?>&sort=<?php echo $sort; ?>" aria-label="Next">
                                    <span aria-hidden="true">&raquo;</span>
                                </a>
                            </li>
                        </ul>
                    </nav>
                <?php endif; ?>

            <?php else: ?>
                <!-- Empty Search State -->
                <div class="text-center py-5 bg-white rounded-4 border p-5">
                    <div class="category-card-img-wrapper mb-4" style="width: 80px; height: 80px; display: inline-flex; align-items: center; justify-content: center;">
                        <i class="fa-solid fa-face-frown text-success" style="font-size: 36px;"></i>
                    </div>
                    <h4>No products found</h4>
                    <p class="text-muted small">Try adjusting your filters, price limits, or search terms.</p>
                    <a href="shop.php" class="btn btn-primary-custom rounded-pill mt-3">Reset All Filters</a>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>
