<?php
$page_title = "Categories Manager";
require_once __DIR__ . '/../includes/admin-header.php';
require_once __DIR__ . '/../includes/admin-sidebar.php';
require_once __DIR__ . '/../models/Category.php';

$catModel = new Category();

// Handle Category CRUD Actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // 1. Add Category
    if (isset($_POST['action']) && $_POST['action'] === 'add') {
        $name = trim($_POST['name'] ?? '');
        
        if (empty($name)) {
            $_SESSION['error'] = "Category name cannot be empty.";
        } else {
            // Handle file upload
            $imageName = null;
            if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
                $uploadDir = __DIR__ . '/../assets/uploads/categories/';
                if (!is_dir($uploadDir)) {
                    mkdir($uploadDir, 0777, true);
                }
                
                $fileExtension = pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION);
                $imageName = 'cat_' . time() . '.' . $fileExtension;
                
                if (!move_uploaded_file($_FILES['image']['tmp_name'], $uploadDir . $imageName)) {
                    $imageName = null;
                }
            }

            $result = $catModel->create($name, $imageName);
            if ($result) {
                $_SESSION['success'] = "Category '{$name}' created successfully!";
            } else {
                $_SESSION['error'] = "Failed to create category.";
            }
        }
        header("Location: categories.php");
        exit();
    }

    // 2. Edit Category
    if (isset($_POST['action']) && $_POST['action'] === 'edit') {
        $id = intval($_POST['category_id'] ?? 0);
        $name = trim($_POST['name'] ?? '');
        $status = intval($_POST['status'] ?? 1);

        if ($id > 0 && !empty($name)) {
            // Handle image update if uploaded
            $imageName = null;
            if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
                $uploadDir = __DIR__ . '/../assets/uploads/categories/';
                if (!is_dir($uploadDir)) {
                    mkdir($uploadDir, 0777, true);
                }
                $fileExtension = pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION);
                $imageName = 'cat_' . time() . '.' . $fileExtension;
                
                if (!move_uploaded_file($_FILES['image']['tmp_name'], $uploadDir . $imageName)) {
                    $imageName = null;
                }
            }

            $result = $catModel->update($id, $name, $imageName, $status);
            if ($result) {
                $_SESSION['success'] = "Category updated successfully!";
            } else {
                $_SESSION['error'] = "Failed to update category.";
            }
        } else {
            $_SESSION['error'] = "Invalid category details.";
        }
        header("Location: categories.php");
        exit();
    }
}

// Handle GET Actions (Delete, Status Toggle)
if (isset($_GET['delete_id'])) {
    $id = intval($_GET['delete_id']);
    if ($id > 0) {
        $result = $catModel->delete($id);
        if ($result) {
            $_SESSION['success'] = "Category deleted successfully!";
        } else {
            $_SESSION['error'] = "Failed to delete category. Verify it has no active products linked.";
        }
    }
    header("Location: categories.php");
    exit();
}

$categories = $catModel->getAllCategories();
?>

<div class="card card-custom p-4 border-light shadow-sm bg-white mb-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h5 class="fw-bold mb-0">Product Categories Management</h5>
        <button id="addCategoryBtn" class="btn btn-primary-custom btn-sm rounded-pill px-3" type="button" data-bs-toggle="collapse" data-bs-target="#addCategoryForm"> <i class="fa-solid fa-plus me-1"></i> Add Category</button>


    </div>

    <!-- Collapse form to Add Category -->
    <div class="collapse mb-4" id="addCategoryForm">
        <div class="card p-4 rounded-4 border border-light bg-light">
            <h6 class="fw-bold mb-3">Add Category</h6>
            <form action="categories.php" method="POST" enctype="multipart/form-data" class="needs-validation" novalidate>
                <input type="hidden" name="action" value="add">
                <div class="row g-3">
                    <div class="col-md-6">
                        <label for="cat_name" class="form-label small fw-medium">Category Name</label>
                        <input type="text" class="form-control bg-white" id="cat_name" name="name" required placeholder="e.g. Organic Greens">
                        <div class="invalid-feedback">Name is required.</div>
                    </div>
                    <div class="col-md-6">
                        <label for="cat_image" class="form-label small fw-medium">Category Image Banner (Optional)</label>
                        <input type="file" class="form-control bg-white" id="cat_image" name="image" accept="image/*">
                    </div>
                </div>
                <button type="submit" class="btn btn-success rounded-pill px-4 mt-3">Create Category</button>
            </form>
        </div>
    </div>

    <!-- Category table -->
    <?php if (!empty($categories)): ?>
        <div class="table-responsive">
            <table class="table align-middle small mb-0">
                <thead>
                    <tr class="text-muted">
                        <th>Image</th>
                        <th>Category Name</th>
                        <th class="text-center">Status</th>
                        <th class="text-center">Products Linked</th>
                        <th class="text-end">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($categories as $cat): 
                        // Query linked products count
                        $db = getDB();
                        $count_stmt = $db->prepare("SELECT COUNT(*) FROM products WHERE category_id = :cid");
                        $count_stmt->execute(['cid' => $cat['id']]);
                        $p_count = intval($count_stmt->fetchColumn());
                    ?>
                        <tr>
                            <td>
                                <div class="rounded border p-1" style="width: 50px; height: 50px; display: flex; align-items: center; justify-content: center; background-color: #fafafa;">
                                    <img src="<?php echo getCategoryImage($cat['image'], $cat['name']); ?>" alt="" style="max-height: 100%; max-width: 100%; object-fit: contain;">
                                </div>
                            </td>
                            <td class="fw-bold"><?php echo htmlspecialchars($cat['name']); ?></td>
                            <td class="text-center">
                                <span class="badge rounded-pill px-2.5 py-1 <?php echo $cat['status'] == 1 ? 'bg-success-subtle text-success border border-success-subtle' : 'bg-secondary-subtle text-secondary border border-secondary-subtle'; ?>">
                                    <?php echo $cat['status'] == 1 ? 'Active' : 'Inactive'; ?>
                                </span>
                            </td>
                            <td class="text-center fw-semibold text-muted"><?php echo $p_count; ?> products</td>
                            <td class="text-end">
                                <div class="d-inline-flex gap-2">
                                    <button class="btn btn-sm btn-outline-success border-0 rounded-circle" type="button" data-bs-toggle="collapse" data-bs-target="#editCollapse_<?php echo $cat['id']; ?>"><i class="fa-regular fa-pen-to-square"></i></button>
                                    <a href="categories.php?delete_id=<?php echo $cat['id']; ?>" onclick="return confirm('Delete this category? This will sever links for <?php echo $p_count; ?> products.')" class="btn btn-sm btn-outline-danger border-0 rounded-circle"><i class="fa-regular fa-trash-can"></i></a>
                                </div>
                                
                                <!-- Edit Form Collapse inside table row -->
                                <div class="collapse text-start mt-3" id="editCollapse_<?php echo $cat['id']; ?>">
                                    <div class="card p-3 bg-light border rounded-4" style="max-width: 400px; margin-left: auto;">
                                        <form action="categories.php" method="POST" enctype="multipart/form-data" class="needs-validation" novalidate>
                                            <input type="hidden" name="action" value="edit">
                                            <input type="hidden" name="category_id" value="<?php echo $cat['id']; ?>">
                                            <div class="mb-2">
                                                <label class="form-label small fw-medium">Category Name</label>
                                                <input type="text" class="form-control form-control-sm bg-white" name="name" required value="<?php echo htmlspecialchars($cat['name']); ?>">
                                            </div>
                                            <div class="mb-2">
                                                <label class="form-label small fw-medium">Status</label>
                                                <select class="form-select form-select-sm bg-white" name="status">
                                                    <option value="1" <?php echo $cat['status'] == 1 ? 'selected' : ''; ?>>Active</option>
                                                    <option value="0" <?php echo $cat['status'] == 0 ? 'selected' : ''; ?>>Inactive</option>
                                                </select>
                                            </div>
                                            <div class="mb-2">
                                                <label class="form-label small fw-medium">Replace Image (Optional)</label>
                                                <input type="file" class="form-control form-control-sm bg-white" name="image" accept="image/*">
                                            </div>
                                            <button type="submit" class="btn btn-success btn-xs px-3 rounded-pill mt-2">Update</button>
                                        </form>
                                    </div>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php else: ?>
        <p class="text-muted text-center py-4 small mb-0">No categories found in store database.</p>
    <?php endif; ?>
</div>

<?php 
require_once __DIR__ . '/../includes/admin-footer.php'; 
?>
