<?php
require_once __DIR__ . '/../config/db.php';

class Product {
    private $db;

    public function __construct() {
        $this->db = getDB();
    }

    /**
     * Fetch products for the homepage popular section
     * @param int $limit
     * @return array
     */
    public function getPopularProducts($limit = 8) {
        $stmt = $this->db->prepare("
            SELECT p.*, c.name as category_name 
            FROM products p
            LEFT JOIN categories c ON p.category_id = c.id
            WHERE p.status = 1
            ORDER BY p.id DESC
            LIMIT :limit
        ");
        $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    /**
     * Fetch products with discounts
     * @param int $limit
     * @return array
     */
    public function getDiscountedProducts($limit = 8) {
        $stmt = $this->db->prepare("
            SELECT p.*, c.name as category_name 
            FROM products p
            LEFT JOIN categories c ON p.category_id = c.id
            WHERE p.status = 1 AND p.discount > 0
            ORDER BY p.discount DESC
            LIMIT :limit
        ");
        $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    /**
     * Find a single product by ID (including category details)
     * @param int $id
     * @return array|false
     */
    public function findById($id) {
        $stmt = $this->db->prepare("
            SELECT p.*, c.name as category_name 
            FROM products p
            LEFT JOIN categories c ON p.category_id = c.id
            WHERE p.id = :id
        ");
        $stmt->execute(['id' => $id]);
        return $stmt->fetch();
    }

    /**
     * Fetch related products in the same category
     * @param int $categoryId
     * @param int $excludeId
     * @param int $limit
     * @return array
     */
    public function getRelatedProducts($categoryId, $excludeId, $limit = 4) {
        $stmt = $this->db->prepare("
            SELECT p.*, c.name as category_name 
            FROM products p
            LEFT JOIN categories c ON p.category_id = c.id
            WHERE p.status = 1 AND p.category_id = :category_id AND p.id != :exclude_id
            ORDER BY RAND()
            LIMIT :limit
        ");
        $stmt->bindValue(':category_id', $categoryId, PDO::PARAM_INT);
        $stmt->bindValue(':exclude_id', $excludeId, PDO::PARAM_INT);
        $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    /**
     * Search, Filter and Sort products (Shop page query)
     * @param array $filters
     * @param int $limit
     * @param int $offset
     * @return array
     */
    public function searchAndFilter($filters = [], $limit = 9, $offset = 0) {
        $sql = "
            SELECT p.*, c.name as category_name, COALESCE(AVG(r.rating), 0) as avg_rating 
            FROM products p
            LEFT JOIN categories c ON p.category_id = c.id
            LEFT JOIN reviews r ON p.id = r.product_id
            WHERE p.status = 1
        ";
        
        $params = [];

        // Keyword search
        if (!empty($filters['search'])) {
            $sql .= " AND (p.name LIKE :search1 OR p.description LIKE :search2 OR p.brand LIKE :search3)";
            $params['search1'] = '%' . $filters['search'] . '%';
            $params['search2'] = '%' . $filters['search'] . '%';
            $params['search3'] = '%' . $filters['search'] . '%';
        }

        // Category filter
        if (!empty($filters['category'])) {
            $sql .= " AND p.category_id = :category";
            $params['category'] = intval($filters['category']);
        }

        // Price range
        if (isset($filters['min_price'])) {
            $sql .= " AND (p.price * (1 - p.discount/100)) >= :min_price";
            $params['min_price'] = floatval($filters['min_price']);
        }
        if (isset($filters['max_price'])) {
            $sql .= " AND (p.price * (1 - p.discount/100)) <= :max_price";
            $params['max_price'] = floatval($filters['max_price']);
        }

        $sql .= " GROUP BY p.id";

        // Sorting
        $sort = $filters['sort'] ?? 'newest';
        switch ($sort) {
            case 'price_low_high':
                $sql .= " ORDER BY (p.price * (1 - p.discount/100)) ASC";
                break;
            case 'price_high_low':
                $sql .= " ORDER BY (p.price * (1 - p.discount/100)) DESC";
                break;
            case 'popularity':
                // Simulated popularity (ordered by ID desc)
                $sql .= " ORDER BY p.id DESC";
                break;
            case 'rating':
                $sql .= " ORDER BY avg_rating DESC";
                break;
            case 'newest':
            default:
                $sql .= " ORDER BY p.created_at DESC";
                break;
        }

        $sql .= " LIMIT :limit OFFSET :offset";

        $stmt = $this->db->prepare($sql);

        // Bind filter params
        foreach ($params as $key => $val) {
            $stmt->bindValue(':' . $key, $val);
        }
        $stmt->bindValue(':limit', intval($limit), PDO::PARAM_INT);
        $stmt->bindValue(':offset', intval($offset), PDO::PARAM_INT);
        
        $stmt->execute();
        return $stmt->fetchAll();
    }

    /**
     * Count products matching filters (for pagination)
     * @param array $filters
     * @return int
     */
    public function getFilteredCount($filters = []) {
        $sql = "
            SELECT COUNT(DISTINCT p.id) 
            FROM products p
            WHERE p.status = 1
        ";
        
        $params = [];

        // Keyword search
        if (!empty($filters['search'])) {
            $sql .= " AND (p.name LIKE :search1 OR p.description LIKE :search2 OR p.brand LIKE :search3)";
            $params['search1'] = '%' . $filters['search'] . '%';
            $params['search2'] = '%' . $filters['search'] . '%';
            $params['search3'] = '%' . $filters['search'] . '%';
        }

        // Category filter
        if (!empty($filters['category'])) {
            $sql .= " AND p.category_id = :category";
            $params['category'] = intval($filters['category']);
        }

        // Price range
        if (isset($filters['min_price'])) {
            $sql .= " AND (p.price * (1 - p.discount/100)) >= :min_price";
            $params['min_price'] = floatval($filters['min_price']);
        }
        if (isset($filters['max_price'])) {
            $sql .= " AND (p.price * (1 - p.discount/100)) <= :max_price";
            $params['max_price'] = floatval($filters['max_price']);
        }

        $stmt = $this->db->prepare($sql);
        foreach ($params as $key => $val) {
            $stmt->bindValue(':' . $key, $val);
        }
        $stmt->execute();
        return intval($stmt->fetchColumn());
    }

    /**
     * Get all products (admin control view)
     * @return array
     */
    public function getAllProducts() {
        $stmt = $this->db->query("
            SELECT p.*, c.name as category_name 
            FROM products p
            LEFT JOIN categories c ON p.category_id = c.id
            ORDER BY p.id DESC
        ");
        return $stmt->fetchAll();
    }

    /**
     * Get products with low stock alerts (admin dashboard indicator)
     * @param int $threshold
     * @return array
     */
    public function getLowStockProducts($threshold = 10) {
        $stmt = $this->db->prepare("
            SELECT id, name, stock, unit 
            FROM products 
            WHERE stock <= :threshold AND status = 1 
            ORDER BY stock ASC
        ");
        $stmt->bindValue(':threshold', $threshold, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    /**
     * Check stock level before checking out
     * @param int $productId
     * @return int Stock level
     */
    public function getStock($productId) {
        $stmt = $this->db->prepare("SELECT stock FROM products WHERE id = :id");
        $stmt->execute(['id' => $productId]);
        return intval($stmt->fetchColumn());
    }

    /**
     * Update product stock (used during order placement or inventory management)
     * @param int $productId
     * @param int $quantity Change in stock (can be negative during orders, positive during restock)
     * @return bool
     */
    public function updateStock($productId, $quantity) {
        $stmt = $this->db->prepare("UPDATE products SET stock = stock + :qty WHERE id = :id");
        return $stmt->execute([
            'qty' => $quantity,
            'id' => $productId
        ]);
    }

    /**
     * Create product (admin CRUD)
     */
    public function create($categoryId, $name, $description, $price, $discount, $stock, $brand, $unit, $weight, $image) {
        $stmt = $this->db->prepare("
            INSERT INTO products (category_id, name, description, price, discount, stock, brand, unit, weight, image, status) 
            VALUES (:category_id, :name, :description, :price, :discount, :stock, :brand, :unit, :weight, :image, 1)
        ");
        $result = $stmt->execute([
            'category_id' => $categoryId ? intval($categoryId) : null,
            'name' => htmlspecialchars(strip_tags($name)),
            'description' => htmlspecialchars($description),
            'price' => floatval($price),
            'discount' => floatval($discount),
            'stock' => intval($stock),
            'brand' => htmlspecialchars(strip_tags($brand)),
            'unit' => htmlspecialchars(strip_tags($unit)),
            'weight' => htmlspecialchars(strip_tags($weight)),
            'image' => $image
        ]);
        return $result ? $this->db->lastInsertId() : false;
    }

    /**
     * Update product (admin CRUD)
     */
    public function update($id, $categoryId, $name, $description, $price, $discount, $stock, $brand, $unit, $weight, $image = null, $status = 1) {
        $params = [
            'category_id' => $categoryId ? intval($categoryId) : null,
            'name' => htmlspecialchars(strip_tags($name)),
            'description' => htmlspecialchars($description),
            'price' => floatval($price),
            'discount' => floatval($discount),
            'stock' => intval($stock),
            'brand' => htmlspecialchars(strip_tags($brand)),
            'unit' => htmlspecialchars(strip_tags($unit)),
            'weight' => htmlspecialchars(strip_tags($weight)),
            'status' => intval($status),
            'id' => $id
        ];

        if ($image) {
            $sql = "
                UPDATE products 
                SET category_id = :category_id, name = :name, description = :description, 
                    price = :price, discount = :discount, stock = :stock, brand = :brand, 
                    unit = :unit, weight = :weight, image = :image, status = :status
                WHERE id = :id
            ";
            $params['image'] = $image;
        } else {
            $sql = "
                UPDATE products 
                SET category_id = :category_id, name = :name, description = :description, 
                    price = :price, discount = :discount, stock = :stock, brand = :brand, 
                    unit = :unit, weight = :weight, status = :status
                WHERE id = :id
            ";
        }

        $stmt = $this->db->prepare($sql);
        return $stmt->execute($params);
    }

    /**
     * Delete product (admin CRUD)
     * @param int $id
     * @return bool
     */
    public function delete($id) {
        $stmt = $this->db->prepare("DELETE FROM products WHERE id = :id");
        return $stmt->execute(['id' => $id]);
    }
}
