<?php
$page_title = "Contact Us";
include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/navbar.php';
?>

<!-- Hero Section -->
<section class="hero-section py-5 text-center">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-7">
                <div class="mb-3">
                    <span style="display:inline-flex;align-items:center;justify-content:center;width:72px;height:72px;border-radius:50%;background:rgba(40,167,69,0.12);">
                        <i class="fa-solid fa-headset text-success" style="font-size:32px;"></i>
                    </span>
                </div>
                <h1 class="fw-bold mb-3">Get In <span>Touch</span></h1>
                <p class="lead text-muted mb-0">
                    Have a question, feedback, or need help with your order? Our support team is here for you — 7 days a week.
                </p>
            </div>
        </div>
    </div>
</section>

<div class="container pb-5">

    <!-- Info Cards Row -->
    <div class="row g-4 mb-5">
        <div class="col-md-4">
            <div class="card card-custom h-100 text-center p-4 border-0" style="background:linear-gradient(135deg,#f0faf3,#e8f5e9);">
                <div style="width:56px;height:56px;border-radius:50%;background:#fff;display:inline-flex;align-items:center;justify-content:center;margin:0 auto 16px;box-shadow:0 2px 12px rgba(40,167,69,0.15);">
                    <i class="fa-solid fa-phone text-success" style="font-size:22px;"></i>
                </div>
                <h6 class="fw-bold mb-1">Call Us</h6>
                <p class="text-muted small mb-2">Mon – Sun, 8 AM to 10 PM</p>
                <a href="tel:+12345678900" class="text-success fw-semibold text-decoration-none">+1 (234) 567-8900</a>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card card-custom h-100 text-center p-4 border-0" style="background:linear-gradient(135deg,#fff8e1,#fff3cd);">
                <div style="width:56px;height:56px;border-radius:50%;background:#fff;display:inline-flex;align-items:center;justify-content:center;margin:0 auto 16px;box-shadow:0 2px 12px rgba(255,193,7,0.2);">
                    <i class="fa-solid fa-envelope text-warning" style="font-size:22px;"></i>
                </div>
                <h6 class="fw-bold mb-1">Email Us</h6>
                <p class="text-muted small mb-2">We reply within 24 hours</p>
                <a href="mailto:support@grocerymart.com" class="text-warning fw-semibold text-decoration-none">support@grocerymart.com</a>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card card-custom h-100 text-center p-4 border-0" style="background:linear-gradient(135deg,#e8f4fd,#dbeafe);">
                <div style="width:56px;height:56px;border-radius:50%;background:#fff;display:inline-flex;align-items:center;justify-content:center;margin:0 auto 16px;box-shadow:0 2px 12px rgba(13,110,253,0.12);">
                    <i class="fa-solid fa-location-dot" style="font-size:22px;color:#0d6efd;"></i>
                </div>
                <h6 class="fw-bold mb-1">Visit Us</h6>
                <p class="text-muted small mb-2">Our store & head office</p>
                <span class="fw-semibold" style="color:#0d6efd;">CCSIT COLLEGE,JUNAGADH</span>
            </div>
        </div>
    </div>

    <!-- Contact Form + Map -->
    <div class="row g-5 align-items-start">

        <!-- Contact Form -->
        <div class="col-lg-7">
            <div class="card card-custom p-4 p-md-5 border-0">
                <h4 class="fw-bold mb-1">Send Us a Message</h4>
                <p class="text-muted small mb-4">Fill in the form below and we'll get back to you as soon as possible.</p>

                <?php if (isset($_GET['sent']) && isset($_SESSION['contact_success'])): unset($_SESSION['contact_success']); ?>
                    <div class="alert border-0 rounded-4 mb-4 d-flex align-items-center gap-3" style="background:#e8f5e9;color:#1b5e20;">
                        <i class="fa-solid fa-circle-check fa-lg"></i>
                        <div>
                            <strong>Message sent successfully!</strong><br>
                            <span class="small">Thank you for contacting us. We'll reply within 24 hours.</span>
                        </div>
                    </div>
                <?php elseif (!empty($error)): ?>
                    <div class="alert border-0 rounded-4 mb-4 d-flex align-items-center gap-3" style="background:#fdecea;color:#b71c1c;">
                        <i class="fa-solid fa-circle-exclamation fa-lg"></i>
                        <div><?php echo htmlspecialchars($error); ?></div>
                    </div>
                <?php endif; ?>

                <form action="contact.php" method="POST" id="contactForm" novalidate>
                    <div class="row g-3 mb-3">
                        <div class="col-sm-6">
                            <label class="form-label fw-medium small">Full Name <span class="text-danger">*</span></label>
                            <input
                                type="text"
                                name="name"
                                class="form-control bg-light border-0 rounded-3 py-2"
                                placeholder="John Doe"
                                value="<?php echo htmlspecialchars($_POST['name'] ?? ''); ?>"
                                required
                            >
                        </div>
                        <div class="col-sm-6">
                            <label class="form-label fw-medium small">Email Address <span class="text-danger">*</span></label>
                            <input
                                type="email"
                                name="email"
                                class="form-control bg-light border-0 rounded-3 py-2"
                                placeholder="john@example.com"
                                value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>"
                                required
                            >
                        </div>
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-medium small">Subject <span class="text-danger">*</span></label>
                        <select name="subject" class="form-select bg-light border-0 rounded-3 py-2" required>
                            <option value="" disabled <?php echo empty($_POST['subject']) ? 'selected' : ''; ?>>Select a subject...</option>
                            <option value="Order Issue"        <?php echo ($_POST['subject'] ?? '') === 'Order Issue'        ? 'selected' : ''; ?>>Order Issue</option>
                            <option value="Payment Problem"    <?php echo ($_POST['subject'] ?? '') === 'Payment Problem'    ? 'selected' : ''; ?>>Payment Problem</option>
                            <option value="Delivery Enquiry"   <?php echo ($_POST['subject'] ?? '') === 'Delivery Enquiry'   ? 'selected' : ''; ?>>Delivery Enquiry</option>
                            <option value="Product Feedback"   <?php echo ($_POST['subject'] ?? '') === 'Product Feedback'   ? 'selected' : ''; ?>>Product Feedback</option>
                            <option value="Account Help"       <?php echo ($_POST['subject'] ?? '') === 'Account Help'       ? 'selected' : ''; ?>>Account Help</option>
                            <option value="General Enquiry"    <?php echo ($_POST['subject'] ?? '') === 'General Enquiry'    ? 'selected' : ''; ?>>General Enquiry</option>
                            <option value="Other"              <?php echo ($_POST['subject'] ?? '') === 'Other'              ? 'selected' : ''; ?>>Other</option>
                        </select>
                    </div>

                    <div class="mb-4">
                        <label class="form-label fw-medium small">Message <span class="text-danger">*</span></label>
                        <textarea
                            name="message"
                            rows="6"
                            class="form-control bg-light border-0 rounded-3 py-2"
                            placeholder="Write your message here..."
                            required
                        ><?php echo htmlspecialchars($_POST['message'] ?? ''); ?></textarea>
                    </div>

                    <button type="submit" class="btn btn-primary-custom rounded-pill px-5 py-2 fw-semibold" id="submitBtn">
                        <i class="fa-solid fa-paper-plane me-2"></i> Send Message
                    </button>
                </form>
            </div>
        </div>

        <!-- Sidebar: Map + FAQ -->
        <div class="col-lg-5">

            <!-- Map Embed -->
            <div class="card card-custom border-0 overflow-hidden mb-4" style="border-radius:20px;">
                <iframe
                    src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3153.086484578787!2d-122.41941548468196!3d37.77492977975983!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x80858085a3a79869%3A0x4d59e8e4d4cc83db!2sSan%20Francisco%2C%20CA%2094102%2C%20USA!5e0!3m2!1sen!2sin!4v1694000000000!5m2!1sen!2sin"
                    width="100%"
                    height="250"
                    style="border:0;display:block;"
                    allowfullscreen=""
                    loading="lazy"
                    referrerpolicy="no-referrer-when-downgrade"
                    title="GroceryMart Location"
                ></iframe>
            </div>

            <!-- Business Hours -->
            <div class="card card-custom p-4 border-0 mb-4">
                <h6 class="fw-bold mb-3"><i class="fa-solid fa-clock text-success me-2"></i>Business Hours</h6>
                <ul class="list-unstyled mb-0 small">
                    <li class="d-flex justify-content-between py-2 border-bottom">
                        <span class="text-muted">Monday – Friday</span>
                        <span class="fw-semibold">8:00 AM – 10:00 PM</span>
                    </li>
                    <li class="d-flex justify-content-between py-2 border-bottom">
                        <span class="text-muted">Saturday</span>
                        <span class="fw-semibold">9:00 AM – 9:00 PM</span>
                    </li>
                    <li class="d-flex justify-content-between py-2">
                        <span class="text-muted">Sunday</span>
                        <span class="fw-semibold">10:00 AM – 7:00 PM</span>
                    </li>
                </ul>
            </div>

            <!-- Social Links -->
            <div class="card card-custom p-4 border-0">
                <h6 class="fw-bold mb-3"><i class="fa-solid fa-share-nodes text-success me-2"></i>Follow Us</h6>
                <div class="d-flex gap-2 flex-wrap">
                    <a href="#" class="btn btn-sm rounded-pill px-3" style="background:#1877f2;color:#fff;">
                        <i class="fa-brands fa-facebook-f me-1"></i> Facebook
                    </a>
                    <a href="#" class="btn btn-sm rounded-pill px-3" style="background:linear-gradient(135deg,#f58529,#dd2a7b,#8134af);color:#fff;">
                        <i class="fa-brands fa-instagram me-1"></i> Instagram
                    </a>
                    <a href="#" class="btn btn-sm rounded-pill px-3" style="background:#1da1f2;color:#fff;">
                        <i class="fa-brands fa-twitter me-1"></i> Twitter
                    </a>
                </div>
            </div>
        </div>
    </div>

    <!-- FAQ Section -->
    <div class="mt-5 pt-3">
        <div class="text-center mb-4">
            <h4 class="fw-bold">Frequently Asked Questions</h4>
            <p class="text-muted small">Quick answers before you reach out</p>
        </div>
        <div class="accordion rounded-4 overflow-hidden shadow-sm" id="faqAccordion">
            <?php
            $faqs = [
                ['q' => 'How long does delivery take?',               'a' => 'Standard delivery takes 1–3 business days. Express same-day delivery is available in select areas for orders placed before 12 PM.'],
                ['q' => 'Can I change or cancel my order?',           'a' => 'You can modify or cancel your order within 1 hour of placing it by visiting My Orders in your dashboard. After that, the order is handed to our packing team.'],
                ['q' => 'What payment methods do you accept?',        'a' => 'We accept all major credit/debit cards, UPI, net banking, and cash on delivery for eligible areas.'],
                ['q' => 'How do I track my order?',                   'a' => 'Once your order ships, you will receive a tracking link via email. You can also check real-time status in My Orders on your profile.'],
                ['q' => 'What is your return & refund policy?',       'a' => 'We offer a 100% satisfaction guarantee. If any item is damaged or incorrect, contact us within 24 hours of delivery and we will arrange a replacement or full refund.'],
            ];
            foreach ($faqs as $i => $faq):
            ?>
            <div class="accordion-item border-0 border-bottom">
                <h2 class="accordion-header" id="faqHead<?php echo $i; ?>">
                    <button class="accordion-button <?php echo $i !== 0 ? 'collapsed' : ''; ?> fw-medium bg-white" type="button"
                        data-bs-toggle="collapse"
                        data-bs-target="#faqBody<?php echo $i; ?>"
                        aria-expanded="<?php echo $i === 0 ? 'true' : 'false'; ?>"
                        aria-controls="faqBody<?php echo $i; ?>">
                        <?php echo htmlspecialchars($faq['q']); ?>
                    </button>
                </h2>
                <div id="faqBody<?php echo $i; ?>" class="accordion-collapse collapse <?php echo $i === 0 ? 'show' : ''; ?>"
                    aria-labelledby="faqHead<?php echo $i; ?>"
                    data-bs-parent="#faqAccordion">
                    <div class="accordion-body text-muted small">
                        <?php echo htmlspecialchars($faq['a']); ?>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>

</div>

<script>
// Simple submit animation
document.getElementById('contactForm').addEventListener('submit', function() {
    const btn = document.getElementById('submitBtn');
    btn.innerHTML = '<i class="fa-solid fa-circle-notch fa-spin me-2"></i> Sending...';
    btn.disabled = true;
});
</script>

<?php include __DIR__ . '/../includes/footer.php'; ?>
