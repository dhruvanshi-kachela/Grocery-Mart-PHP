<?php
require_once __DIR__ . '/../models/Address.php';
require_once __DIR__ . '/../controllers/AuthController.php';

class AddressController {
    private $addressModel;
    public function __construct() {
        $this->addressModel = new Address();
    }

    // List addresses for logged-in user
    public function list() {
        AuthController::checkAuth();
        $userId = $_SESSION['user_id'];
        return $this->addressModel->getByUser($userId);
    }

    // Add new address
    public function add($data) {
        AuthController::checkAuth();
        $userId = $_SESSION['user_id'];
        $required = ['full_address', 'city', 'state', 'zipcode', 'country'];
        foreach ($required as $field) {
            if (empty($data[$field] ?? '')) {
                $_SESSION['error'] = "All address fields are required.";
                return false;
            }
        }
        $result = $this->addressModel->add(
            $userId,
            $data['full_address'],
            $data['city'],
            $data['state'],
            $data['zipcode'],
            $data['country'] ?? 'India'
        );
        if ($result) {
            $_SESSION['success'] = "Address added successfully.";
        } else {
            $_SESSION['error'] = "Failed to add address.";
        }
        return $result;
    }

    // Update existing address
    public function update($id, $data) {
        AuthController::checkAuth();
        $userId = $_SESSION['user_id'];
        $result = $this->addressModel->update(
            $id,
            $userId,
            $data['full_address'],
            $data['city'],
            $data['state'],
            $data['zipcode'],
            $data['country'] ?? 'India'
        );
        if ($result) {
            $_SESSION['success'] = "Address updated successfully.";
        } else {
            $_SESSION['error'] = "Failed to update address.";
        }
        return $result;
    }

    // Delete address
    public function delete($id) {
        AuthController::checkAuth();
        $userId = $_SESSION['user_id'];
        $result = $this->addressModel->delete($id, $userId);
        if ($result) {
            $_SESSION['success'] = "Address deleted successfully.";
        } else {
            $_SESSION['error'] = "Failed to delete address.";
        }
        return $result;
    }
}
?>
