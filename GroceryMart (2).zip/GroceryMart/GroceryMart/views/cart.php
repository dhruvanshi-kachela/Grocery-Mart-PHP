<?php
$page_title = "My Shopping Cart";
include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/navbar.php';
?>

<div class="container my-5">
    <!-- Breadcrumb -->
    <nav aria-label="breadcrumb" class="mb-4">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="index.php" class="text-success text-decoration-none">Home</a></li>
            <li class="breadcrumb-item active" aria-current="page">Shopping Cart</li>
        </ol>
    </nav>

    <h3 class="fw-bold mb-4">My Shopping Cart</h3>

    <?php if (!empty($cart_items)): ?>
        <div class="row g-4">
            <!-- Cart Items Grid -->
            <div class="col-lg-8">
                <div class="card card-custom p-3 border-light shadow-sm mb-4">
                    <div class="table-responsive">
                        <table class="table align-middle mb-0">
                            <thead class="text-muted small">
                                <tr>
                                    <th scope="col" class="border-0">Product</th>
                                    <th scope="col" class="border-0 text-center">Price</th>
                                    <th scope="col" class="border-0 text-center">Quantity</th>
                                    <th scope="col" class="border-0 text-end">Total</th>
                                    <th scope="col" class="border-0 text-center">Remove</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($cart_items as $item): 
                                    $item_price = getDiscountedPrice($item['price'], $item['discount']);
                                    $item_total = $item_price * $item['quantity'];
                                ?>
                                    <tr id="cart-row-<?php echo $item['product_id']; ?>">
                                        <!-- Product Info -->
                                        <td>
                                            <div class="d-flex align-items-center gap-3">
                                                <div class="product-img-wrapper rounded-3 border bg-light" style="width: 70px; height: 70px; padding: 5px;">
                                                    <img src="<?php echo getProductImage($item['image'], $item['name']); ?>" alt="<?php echo htmlspecialchars($item['name']); ?>" style="max-height: 100%; max-width: 100%; object-fit: contain;">
                                                </div>
                                                <div>
                                                    <h6 class="fw-semibold mb-1 small">
                                                        <a href="product.php?id=<?php echo $item['product_id']; ?>" class="text-dark text-decoration-none">
                                                            <?php echo htmlspecialchars($item['name']); ?>
                                                        </a>
                                                    </h6>
                                                    <span class="text-muted small d-block"><?php echo htmlspecialchars($item['brand'] ?? 'GroceryMart'); ?> - <?php echo htmlspecialchars($item['weight'] ?? '1 unit'); ?></span>
                                                </div>
                                            </div>
                                        </td>
                                        <!-- Price -->
                                        <td class="text-center">
                                            <span class="fw-semibold text-dark small"><?php echo formatPrice($item_price); ?></span>
                                            <?php if ($item['discount'] > 0): ?>
                                                <br>
                                                <span class="text-muted text-decoration-line-through small" style="font-size: 11px;"><?php echo formatPrice($item['price']); ?></span>
                                            <?php endif; ?>
                                        </td>
                                        <!-- Quantity -->
                                        <td class="text-center">
                                            <div class="d-inline-flex align-items-center border rounded-pill bg-light" style="padding: 2px 8px;">
                                                <button class="btn btn-sm btn-light border-0 rounded-circle py-0 px-2" onclick="modifyQty(<?php echo $item['product_id']; ?>, -1, <?php echo $item['stock']; ?>)">
                                                    <i class="fa-solid fa-minus text-muted" style="font-size: 10px;"></i>
                                                </button>
                                                <input type="number" class="form-control form-control-sm text-center border-0 bg-transparent py-0 fw-bold item-qty-input" id="qty-input-<?php echo $item['product_id']; ?>" value="<?php echo $item['quantity']; ?>" readonly style="width: 45px; font-size: 13px;">
                                                <button class="btn btn-sm btn-light border-0 rounded-circle py-0 px-2" onclick="modifyQty(<?php echo $item['product_id']; ?>, 1, <?php echo $item['stock']; ?>)">
                                                    <i class="fa-solid fa-plus text-muted" style="font-size: 10px;"></i>
                                                </button>
                                            </div>
                                        </td>
                                        <!-- Subtotal -->
                                        <td class="text-end">
                                            <span class="fw-bold text-success small" id="row-total-<?php echo $item['product_id']; ?>"><?php echo formatPrice($item_total); ?></span>
                                        </td>
                                        <!-- Delete btn -->
                                        <td class="text-center">
                                            <button class="btn btn-sm btn-outline-danger border-0 rounded-circle" onclick="deleteCartItem(<?php echo $item['product_id']; ?>)">
                                                <i class="fa-regular fa-trash-can"></i>
                                            </button>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>

                <!-- Continue Shopping link -->
                <div class="text-start">
                    <a href="shop.php" class="text-success text-decoration-none small fw-medium">
                        <i class="fa-solid fa-arrow-left me-1"></i> Continue Shopping
                    </a>
                </div>
            </div>

            <!-- Cart Summary Panel -->
            <div class="col-lg-4">
                <!-- Summary Card -->
                <div class="card card-custom p-4 border-light shadow-sm mb-4">
                    <h5 class="fw-bold mb-4">Order Summary</h5>
                    
                    <div class="d-flex justify-content-between mb-2 small text-muted">
                        <span>Subtotal</span>
                        <span class="text-dark fw-medium" id="summary-subtotal"><?php echo formatPrice($subtotal); ?></span>
                    </div>

                    <!-- Coupon Discount details -->
                    <?php if ($coupon_discount > 0): ?>
                        <div class="d-flex justify-content-between mb-2 small text-muted">
                            <span>Coupon Discount (<?php echo htmlspecialchars($coupon_code); ?>)</span>
                            <span class="text-danger fw-medium">- <?php echo formatPrice($coupon_discount); ?></span>
                        </div>
                    <?php endif; ?>

                    <div class="d-flex justify-content-between mb-3 small text-muted">
                        <span>Shipping Charges</span>
                        <span class="text-dark fw-medium" id="summary-shipping">
                            <?php echo $shipping == 0 ? '<span class="text-success fw-bold">FREE</span>' : formatPrice($shipping); ?>
                        </span>
                    </div>
                    
                    <?php if ($shipping > 0): ?>
                        <div class="alert alert-warning py-2 px-3 alert-custom mb-3" style="font-size: 11px;">
                            <i class="fa-solid fa-circle-info me-1"></i> Add <strong><?php echo formatPrice(499.00 - $subtotal); ?></strong> more to unlock <strong>FREE shipping</strong>!
                        </div>
                    <?php else: ?>
                        <div class="alert alert-success py-2 px-3 alert-custom mb-3" style="font-size: 11px;">
                            <i class="fa-solid fa-truck-fast me-1 text-success"></i> Congratulations! You unlocked <strong>FREE shipping</strong>!
                        </div>
                    <?php endif; ?>

                    <hr class="my-3">

                    <div class="d-flex justify-content-between mb-4">
                        <span class="fw-bold">Total Amount</span>
                        <span class="fw-bold text-success fs-5" id="summary-total"><?php echo formatPrice($total); ?></span>
                    </div>

                    <!-- Checkout button -->
                    <div class="d-grid">
                        <a href="checkout.php" class="btn btn-primary-custom py-2.5 rounded-pill fs-6">
                            Proceed to Checkout <i class="fa-solid fa-arrow-right ms-1"></i>
                        </a>
                    </div>
                </div>

                <!-- Coupon Box Card -->
                <div class="card card-custom p-4 border-light shadow-sm">
                    <h6 class="fw-bold mb-3">Apply Coupon Code</h6>
                    
                    <?php if (empty($coupon_code)): ?>
                        <form action="cart.php" method="POST" class="needs-validation" novalidate>
                            <input type="hidden" name="action" value="apply_coupon">
                            <div class="input-group">
                                <input type="text" class="form-control bg-light border-0 rounded-start-pill text-uppercase fw-semibold" placeholder="Enter Code (e.g. WELCOME50)" name="coupon_code" required>
                                <button class="btn btn-primary-custom rounded-end-pill px-3" type="submit">Apply</button>
                            </div>
                            <div class="invalid-feedback">Please enter a coupon code.</div>
                        </form>
                        <div class="mt-3 bg-light p-3 rounded-4" style="font-size: 11px;">
                            <span class="text-muted fw-bold d-block mb-1">Available Coupons:</span>
                            <span class="d-block mb-1"><code>WELCOME50</code> - ₹50 off on minimum purchase of ₹299</span>
                            <span class="d-block mb-1"><code>SAVEMORE100</code> - ₹100 off on minimum purchase of ₹599</span>
                            <span class="d-block"><code>FESTIVE200</code> - ₹200 off on minimum purchase of ₹999</span>
                        </div>
                    <?php else: ?>
                        <div class="bg-success-subtle border border-success-subtle p-3 rounded-4 d-flex justify-content-between align-items-center">
                            <div>
                                <span class="d-block small text-success fw-bold">Active Coupon:</span>
                                <h6 class="fw-bold mb-0 text-success-emphasis"><?php echo htmlspecialchars($coupon_code); ?> (Saved ₹<?php echo $coupon_discount; ?>)</h6>
                            </div>
                            <a href="cart.php?remove_coupon=1" class="btn btn-sm btn-outline-danger border-0 rounded-circle"><i class="fa-solid fa-xmark fs-5"></i></a>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    <?php else: ?>
        <!-- Empty Cart Display state -->
        <div class="text-center py-5 bg-white rounded-4 border p-5">
            <div class="category-card-img-wrapper mb-4" style="width: 90px; height: 90px; display: inline-flex; align-items: center; justify-content: center; background-color: var(--primary-light);">
                <i class="fa-solid fa-basket-shopping text-success" style="font-size: 40px;"></i>
            </div>
            <h4>Your Shopping Cart is Empty</h4>
            <p class="text-muted small">Looks like you haven't added any fresh groceries to your cart yet.</p>
            <a href="shop.php" class="btn btn-primary-custom rounded-pill mt-3 px-4 py-2">Start Shopping</a>
        </div>
    <?php endif; ?>
</div>

<script>
// AJAX handles quantity updates
function modifyQty(productId, change, maxStock) {
    const input = $(`#qty-input-${productId}`);
    let newQty = parseInt(input.val()) + change;
    
    if (newQty < 1) {
        // Confirm removal
        if (confirm("Remove this item from your cart?")) {
            deleteCartItem(productId);
        }
        return;
    }
    
    if (newQty > maxStock) {
        showToast(`Only ${maxStock} items available in stock.`, 'danger');
        return;
    }
    
    // Disable inputs
    input.val(newQty);
    
    $.ajax({
        url: 'cart.php',
        method: 'POST',
        data: {
            action: 'update',
            product_id: productId,
            quantity: newQty
        },
        dataType: 'json',
        success: function(response) {
            if (response.success) {
                // Reload page to re-compute coupons and shipping subtotals cleanly
                window.location.reload();
            } else {
                showToast(response.message || 'Error updating cart', 'danger');
                // Revert
                input.val(newQty - change);
            }
        },
        error: function() {
            showToast('Network error, please try again.', 'danger');
            input.val(newQty - change);
        }
    });
}

// AJAX handles deletions
function deleteCartItem(productId) {
    $.ajax({
        url: 'cart.php',
        method: 'POST',
        data: {
            action: 'delete',
            product_id: productId
        },
        dataType: 'json',
        success: function(response) {
            if (response.success) {
                showToast(response.message, 'success');
                $(`#cart-row-${productId}`).fadeOut(500, function() {
                    $(this).remove();
                    window.location.reload(); // Refresh to recalculate
                });
            } else {
                showToast(response.message || 'Error removing item', 'danger');
            }
        },
        error: function() {
            showToast('Network error, please try again.', 'danger');
        }
    });
}
</script>

<?php include __DIR__ . '/../includes/footer.php'; ?>
