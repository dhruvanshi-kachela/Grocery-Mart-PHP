-- Grocery Mart Database Schema & Seed Data

CREATE DATABASE IF NOT EXISTS grocery_mart;
USE grocery_mart;

SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS contact_messages;
DROP TABLE IF EXISTS reviews;
DROP TABLE IF EXISTS order_items;
DROP TABLE IF EXISTS orders;
DROP TABLE IF EXISTS coupons;
DROP TABLE IF EXISTS addresses;
DROP TABLE IF EXISTS wishlist;
DROP TABLE IF EXISTS cart;
DROP TABLE IF EXISTS product_images;
DROP TABLE IF EXISTS products;
DROP TABLE IF EXISTS categories;
DROP TABLE IF EXISTS admins;
DROP TABLE IF EXISTS users;
SET FOREIGN_KEY_CHECKS = 1;

-- 1. Users Table
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    mobile VARCHAR(15) NOT NULL,
    password VARCHAR(255) NOT NULL,
    role VARCHAR(20) DEFAULT 'customer',
    profile_image VARCHAR(255) DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 2. Admins Table
CREATE TABLE admins (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 3. Categories Table
CREATE TABLE categories (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    image VARCHAR(255) DEFAULT NULL,
    status TINYINT(1) DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 4. Products Table
CREATE TABLE products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    category_id INT,
    name VARCHAR(200) NOT NULL,
    description TEXT,
    price DECIMAL(10,2) NOT NULL,
    discount DECIMAL(5,2) DEFAULT 0.00,
    stock INT DEFAULT 0,
    brand VARCHAR(100) DEFAULT NULL,
    unit VARCHAR(20) DEFAULT 'kg',
    weight VARCHAR(50) DEFAULT NULL,
    image VARCHAR(255) DEFAULT NULL,
    status TINYINT(1) DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE SET NULL
);

-- 5. Product Images Table
CREATE TABLE product_images (
    id INT AUTO_INCREMENT PRIMARY KEY,
    product_id INT NOT NULL,
    image VARCHAR(255) NOT NULL,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
);

-- 6. Cart Table
CREATE TABLE cart (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    product_id INT NOT NULL,
    quantity INT DEFAULT 1,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
);

-- 7. Wishlist Table
CREATE TABLE wishlist (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    product_id INT NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
);

-- 8. Addresses Table
CREATE TABLE addresses (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    full_address VARCHAR(255) NOT NULL,
    city VARCHAR(100) NOT NULL,
    state VARCHAR(100) NOT NULL,
    country VARCHAR(100) DEFAULT 'India',
    zipcode VARCHAR(10) NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- 9. Coupons Table
CREATE TABLE coupons (
    id INT AUTO_INCREMENT PRIMARY KEY,
    code VARCHAR(50) NOT NULL UNIQUE,
    discount DECIMAL(10,2) NOT NULL,
    minimum_amount DECIMAL(10,2) DEFAULT 0.00,
    expiry_date DATE NOT NULL,
    status TINYINT(1) DEFAULT 1
);

-- 10. Orders Table
CREATE TABLE orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    address_id INT,
    total DECIMAL(10,2) NOT NULL,
    discount DECIMAL(10,2) DEFAULT 0.00,
    payment_method VARCHAR(50) DEFAULT 'COD',
    payment_status VARCHAR(50) DEFAULT 'Pending',
    order_status VARCHAR(50) DEFAULT 'Placed',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (address_id) REFERENCES addresses(id) ON DELETE SET NULL
);

-- 11. Order Items Table
CREATE TABLE order_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT NOT NULL,
    product_id INT NOT NULL,
    quantity INT NOT NULL,
    price DECIMAL(10,2) NOT NULL,
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
);

-- 12. Reviews Table
CREATE TABLE reviews (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    product_id INT NOT NULL,
    rating INT CHECK(rating BETWEEN 1 AND 5),
    review TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
);

-- 13. Contact Messages Table
CREATE TABLE contact_messages (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL,
    message TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ==========================================
-- SEED DATA
-- ==========================================

-- Seed Admins
INSERT INTO admins (name, email, password) VALUES 
('System Admin', 'admin@grocerymart.com', '$2y$10$QPA3fmhkFs6OAmvpBtscteiqvx4ij.w5Q0ZKJAXUZZod09ftrQY7m');

-- Seed Users
INSERT INTO users (name, email, mobile, password, role) VALUES
('John Doe', 'user@grocerymart.com', '9876543210', '$2y$10$bDrSk/8SGwXfcsGC1HiTfeWJkOlWEpG08RH1kPPXgNZY9NlsTLTJy', 'customer'),
('Jane Smith', 'jane@example.com', '9123456789', '$2y$10$bDrSk/8SGwXfcsGC1HiTfeWJkOlWEpG08RH1kPPXgNZY9NlsTLTJy', 'customer');

-- Seed Categories
INSERT INTO categories (id, name, image, status) VALUES
(1, 'Fresh Fruits', 'fruits.png', 1),
(2, 'Fresh Vegetables', 'vegetables.png', 1),
(3, 'Dairy & Eggs', 'dairy.png', 1),
(4, 'Bakery & Bread', 'bakery.png', 1),
(5, 'Beverages', 'beverages.png', 1),
(6, 'Snacks & Munchies', 'snacks.png', 1),
(7, 'Staples & Spices', 'staples.png', 1),
(8, 'Household & Cleaning', 'cleaning.png', 1);

-- Seed Products
INSERT INTO products (category_id, name, description, price, discount, stock, brand, unit, weight, image, status) VALUES
-- Fruits
(1, 'Organic Red Apples', 'Crisp and sweet organic Washington apples, perfect for snacking or pies.', 150.00, 10.00, 50, 'FreshFarm', 'kg', '1 kg', 'apple.png', 1),
(1, 'Fresh Banana (Robusta)', 'High-energy sweet bananas. Perfect daily dose of potassium.', 60.00, 0.00, 120, 'Local', 'dozen', '12 units', 'banana.png', 1),
(1, 'Alphonso Mangoes', 'Sweet, juicy and rich mangoes directly sourced from Ratnagiri.', 450.00, 15.00, 20, 'KingFruits', 'box', '6 units', 'mango.png', 1),

-- Vegetables
(2, 'Fresh Potatoes', 'Starchy utility potatoes, ideal for roasting, boiling, and frying.', 40.00, 0.00, 200, 'Local', 'kg', '1 kg', 'potato.png', 1),
(2, 'Organic Red Tomatoes', 'Juicy red tomatoes sourced from organic farms.', 50.00, 5.00, 150, 'OrganicFarm', 'kg', '1 kg', 'tomato.png', 1),
(2, 'Fresh Onions', 'Essential kitchen staple, crisp and pungent pink onions.', 45.00, 0.00, 180, 'Local', 'kg', '1 kg', 'onion.png', 1),

-- Dairy
(3, 'Fresh Cow Milk (Pasteurized)', 'Full cream pasteurized cow milk, rich in nutrients.', 70.00, 0.00, 60, 'DairyPure', 'packet', '1 Litre', 'milk.png', 1),
(3, 'Organic Butter', 'Salted creamery butter made from grass-fed cow milk.', 120.00, 8.00, 45, 'Amul', 'pack', '200g', 'butter.png', 1),
(3, 'Paneer (Cottage Cheese)', 'Soft and fresh block of cottage cheese.', 90.00, 5.00, 30, 'MotherDairy', 'pack', '200g', 'paneer.png', 1),

-- Bakery
(4, 'Whole Wheat Sliced Bread', 'Healthy and soft whole wheat bread, baked daily.', 45.00, 0.00, 40, 'HarvestGold', 'pack', '400g', 'bread.png', 1),
(4, 'Chocolate Chip Cookies', 'Freshly baked buttery cookies loaded with chocolate chips.', 80.00, 10.00, 25, 'BakeryFresh', 'pack', '150g', 'cookies.png', 1),

-- Beverages
(5, 'Pure Orange Juice', '100% pure squeezed orange juice with no added sugar.', 110.00, 15.00, 35, 'Real', 'pack', '1 Litre', 'orange_juice.png', 1),
(5, 'Premium Assam Tea', 'Rich and aromatic CTC black tea from the gardens of Assam.', 180.00, 5.00, 60, 'TataTea', 'box', '500g', 'tea.png', 1),

-- Snacks
(6, 'Salted Potato Chips', 'Crisp and crunchy classic salted potato chips.', 30.00, 0.00, 100, 'Lays', 'pack', '90g', 'chips.png', 1),
(6, 'Roasted Salted Cashews', 'Premium handpicked roasted cashews lightly salted.', 250.00, 12.00, 40, 'Nutty', 'pack', '200g', 'cashews.png', 1),

-- Staples
(7, 'Basmati Rice (Premium Long Grain)', 'Aromatic and extra-long grain basmati rice.', 140.00, 10.00, 80, 'IndiaGate', 'bag', '1 kg', 'rice.png', 1),
(7, 'Cold Pressed Mustard Oil', '100% pure cold pressed mustard oil for traditional cooking.', 190.00, 5.00, 50, 'Fortune', 'bottle', '1 Litre', 'oil.png', 1),

-- Household
(8, 'Dishwashing Liquid Gel', 'Tough on grease, gentle on hands lemon dishwash gel.', 115.00, 10.00, 40, 'Vim', 'bottle', '500ml', 'dishwash.png', 1),
(8, 'Multi-purpose Floor Cleaner', 'Kills 99.9% germs, leaves a refreshing citrus fragrance.', 160.00, 8.00, 30, 'Lizol', 'bottle', '1 Litre', 'floor_cleaner.png', 1);

-- Seed Coupons
INSERT INTO coupons (code, discount, minimum_amount, expiry_date, status) VALUES
('WELCOME50', 50.00, 299.00, '2027-12-31', 1),
('SAVEMORE100', 100.00, 599.00, '2027-12-31', 1),
('FESTIVE200', 200.00, 999.00, '2027-12-31', 1);

-- Seed Addresses
INSERT INTO addresses (user_id, full_address, city, state, country, zipcode) VALUES
(1, 'Apt 4B, Green Glen Layout', 'Bangalore', 'Karnataka', 'India', '560103'),
(1, 'House 12, Park Street', 'Kolkata', 'West Bengal', 'India', '700016'),
(2, 'Flat 102, Sunrise Towers, Sector 62', 'Noida', 'Uttar Pradesh', 'India', '201301');

-- Seed Reviews
INSERT INTO reviews (user_id, product_id, rating, review) VALUES
(1, 1, 5, 'Absolutely delicious! Fresh and sweet.'),
(2, 1, 4, 'Good quality apples, though slightly expensive.'),
(1, 4, 5, 'Very soft and stays fresh for 3 days.'),
(2, 7, 5, 'Best milk package in town. High fat creaminess.');
