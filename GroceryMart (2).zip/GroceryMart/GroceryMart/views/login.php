<?php
$page_title = "Sign In";
include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/navbar.php';
?>

<style>
.auth-page-bg {
    min-height: calc(100vh - 68px);
    background: linear-gradient(135deg, #f0faf3 0%, #e8f5e9 40%, #f9fdf9 100%);
    display: flex; align-items: center; padding: 48px 0;
    position: relative; overflow: hidden;
}
.auth-page-bg::before {
    content: '';
    position: absolute; top: -80px; right: -80px;
    width: 400px; height: 400px; border-radius: 50%;
    background: radial-gradient(circle, rgba(76,175,80,0.12) 0%, transparent 70%);
    pointer-events: none;
}
.auth-page-bg::after {
    content: '';
    position: absolute; bottom: -60px; left: -60px;
    width: 300px; height: 300px; border-radius: 50%;
    background: radial-gradient(circle, rgba(46,125,50,0.09) 0%, transparent 70%);
    pointer-events: none;
}
.auth-card {
    background: #fff;
    border-radius: 28px;
    box-shadow: 0 20px 60px rgba(0,0,0,0.08), 0 4px 16px rgba(46,125,50,0.06);
    padding: 48px 44px;
    position: relative; z-index: 2;
    width: 100%; max-width: 460px; margin: 0 auto;
}
.auth-logo-wrap {
    width: 68px; height: 68px; border-radius: 20px;
    background: linear-gradient(135deg, #2E7D32, #4CAF50);
    display: flex; align-items: center; justify-content: center;
    font-size: 28px; color: #fff; margin: 0 auto 20px;
    box-shadow: 0 8px 24px rgba(76,175,80,0.35);
}
.auth-title { font-size: 26px; font-weight: 800; color: #1a1a1a; letter-spacing: -0.5px; margin-bottom: 6px; }
.auth-sub { color: #999; font-size: 14px; margin-bottom: 32px; }
.auth-label {
    font-size: 12px; font-weight: 700; color: #555;
    text-transform: uppercase; letter-spacing: 0.6px;
    margin-bottom: 8px; display: block;
}
.auth-field {
    display: flex; align-items: center;
    background: #f7f9f7; border: 2px solid transparent;
    border-radius: 14px; overflow: hidden;
    transition: border-color 0.2s, box-shadow 0.2s, background 0.2s;
    margin-bottom: 20px;
}
.auth-field:focus-within {
    background: #fff;
    border-color: #4CAF50;
    box-shadow: 0 0 0 4px rgba(76,175,80,0.1);
}
.auth-field .af-icon {
    width: 46px; display: flex; align-items: center; justify-content: center;
    color: #bbb; font-size: 14px; flex-shrink: 0; transition: color 0.2s;
}
.auth-field:focus-within .af-icon { color: #2E7D32; }
.auth-field input {
    flex: 1; border: none; background: transparent; outline: none;
    font-size: 14px; font-family: 'Poppins', sans-serif;
    color: #333; padding: 13px 12px 13px 0;
}
.auth-field input::placeholder { color: #ccc; }
.auth-field .toggle-pw {
    width: 44px; display: flex; align-items: center; justify-content: center;
    border: none; background: transparent; color: #ccc; cursor: pointer;
    font-size: 14px; transition: color 0.2s;
}
.auth-field .toggle-pw:hover { color: #2E7D32; }
.auth-forgot { font-size: 12px; color: #2E7D32; font-weight: 600; text-decoration: none; float: right; margin-top: -16px; margin-bottom: 20px; display: block; }
.auth-forgot:hover { text-decoration: underline; color: #2E7D32; }
.auth-remember { display: flex; align-items: center; gap: 10px; margin-bottom: 28px; }
.auth-remember input[type=checkbox] { width: 18px; height: 18px; accent-color: #2E7D32; cursor: pointer; }
.auth-remember label { font-size: 13px; color: #777; cursor: pointer; }
.btn-auth {
    width: 100%; padding: 15px;
    background: linear-gradient(135deg, #2E7D32, #4CAF50);
    border: none; border-radius: 14px; color: #fff;
    font-size: 15px; font-weight: 700; font-family: 'Poppins', sans-serif;
    cursor: pointer; letter-spacing: 0.3px;
    box-shadow: 0 6px 20px rgba(76,175,80,0.35);
    transition: all 0.25s;
}
.btn-auth:hover { transform: translateY(-2px); box-shadow: 0 10px 28px rgba(76,175,80,0.45); }
.btn-auth:active { transform: translateY(0); }
.auth-divider {
    display: flex; align-items: center; gap: 14px; margin: 28px 0;
    color: #ddd; font-size: 12px; font-weight: 600;
}
.auth-divider::before, .auth-divider::after { content:''; flex:1; height:1px; background:#eee; }
.auth-switch { text-align: center; font-size: 13px; color: #999; margin-top: 24px; }
.auth-switch a { color: #2E7D32; font-weight: 700; text-decoration: none; }
.auth-switch a:hover { text-decoration: underline; }
.demo-box {
    background: linear-gradient(135deg, #f0faf3, #e8f5e9);
    border: 1px solid #c8e6c9; border-radius: 14px;
    padding: 16px 20px; margin-top: 28px;
}
.demo-box .demo-title { font-size: 11px; font-weight: 800; color: #2E7D32; letter-spacing: 0.8px; text-transform: uppercase; margin-bottom: 10px; }
.demo-box .demo-row { display: flex; justify-content: space-between; align-items: center; margin-bottom: 6px; }
.demo-box .demo-row:last-child { margin-bottom: 0; }
.demo-box .demo-role { font-size: 12px; color: #666; font-weight: 600; }
.demo-box code { font-size: 11px; background: #fff; border: 1px solid #dcedc8; border-radius: 6px; padding: 2px 8px; color: #2E7D32; cursor: pointer; user-select: all; }

/* Side panel */
.auth-side {
    background: linear-gradient(160deg, #1B5E20 0%, #2E7D32 50%, #388E3C 100%);
    border-radius: 28px; padding: 48px 40px;
    height: 100%; min-height: 500px;
    display: flex; flex-direction: column; justify-content: center;
    position: relative; overflow: hidden;
}
.auth-side::before {
    content: '';
    position: absolute; top: -60px; right: -60px;
    width: 250px; height: 250px; border-radius: 50%;
    background: rgba(255,255,255,0.06);
}
.auth-side::after {
    content: '';
    position: absolute; bottom: -40px; left: -40px;
    width: 200px; height: 200px; border-radius: 50%;
    background: rgba(255,255,255,0.04);
}
.auth-side-content { position: relative; z-index: 2; }
.side-emoji { font-size: 56px; margin-bottom: 24px; line-height: 1; }
.side-title { font-size: 28px; font-weight: 800; color: #fff; letter-spacing: -0.5px; line-height: 1.2; margin-bottom: 16px; }
.side-sub { color: rgba(255,255,255,0.6); font-size: 14px; line-height: 1.7; margin-bottom: 36px; }
.side-feature { display: flex; align-items: center; gap: 12px; margin-bottom: 16px; }
.side-feature .sf-icon { width: 36px; height: 36px; border-radius: 10px; background: rgba(255,255,255,0.1); display: flex; align-items: center; justify-content: center; color: #A5D6A7; font-size: 15px; flex-shrink: 0; }
.side-feature .sf-text { font-size: 13px; color: rgba(255,255,255,0.8); font-weight: 500; }
@media (max-width: 991px) {
    .auth-card { padding: 36px 28px; }
    .auth-side { display: none; }
}
</style>

<div class="auth-page-bg">
    <div class="container">
        <div class="row align-items-center g-4 justify-content-center">

            <!-- Left side panel (desktop only) -->
            <div class="col-lg-5 d-none d-lg-block">
                <div class="auth-side">
                    <div class="auth-side-content">
                        <div class="side-emoji">🛒</div>
                        <h2 class="side-title">Welcome Back to GroceryMart!</h2>
                        <p class="side-sub">Sign in to access your orders, wishlist, and exclusive deals on fresh groceries.</p>
                        <div class="side-feature"><div class="sf-icon"><i class="fa-solid fa-truck-fast"></i></div><div class="sf-text">Free delivery on orders above ₹499</div></div>
                        <div class="side-feature"><div class="sf-icon"><i class="fa-solid fa-leaf"></i></div><div class="sf-text">100% organic & farm-fresh produce</div></div>
                        <div class="side-feature"><div class="sf-icon"><i class="fa-solid fa-tags"></i></div><div class="sf-text">Exclusive coupons for members</div></div>
                    </div>
                </div>
            </div>

            <!-- Login form -->
            <div class="col-lg-5 col-md-8">
                <div class="auth-card">
                    <div class="text-center">
                        <div class="auth-logo-wrap"><i class="fa-solid fa-basket-shopping"></i></div>
                        <h2 class="auth-title">Sign In</h2>
                        <p class="auth-sub">Access your profile, orders & cart</p>
                    </div>

                    <!-- Error/success from server -->
                    <?php if (isset($_SESSION['error'])): ?>
                        <div style="background:#fde8e8;border:1px solid #f5c6c6;border-radius:12px;padding:12px 16px;display:flex;align-items:center;gap:10px;margin-bottom:20px;font-size:13px;color:#c62828;">
                            <i class="fa-solid fa-circle-exclamation"></i>
                            <?php echo htmlspecialchars($_SESSION['error']); unset($_SESSION['error']); ?>
                        </div>
                    <?php endif; ?>
                    <?php if (isset($_SESSION['success'])): ?>
                        <div style="background:#e8f5e9;border:1px solid #c8e6c9;border-radius:12px;padding:12px 16px;display:flex;align-items:center;gap:10px;margin-bottom:20px;font-size:13px;color:#2E7D32;">
                            <i class="fa-solid fa-circle-check"></i>
                            <?php echo htmlspecialchars($_SESSION['success']); unset($_SESSION['success']); ?>
                        </div>
                    <?php endif; ?>

                    <form action="login.php" method="POST" id="loginForm" novalidate>
                        <!-- Email -->
                        <label class="auth-label">Email Address</label>
                        <div class="auth-field">
                            <div class="af-icon"><i class="fa-regular fa-envelope"></i></div>
                            <input type="email" name="email" id="loginEmail" placeholder="you@example.com" autocomplete="email" required
                                value="<?php echo htmlspecialchars($_COOKIE['remember_user_email'] ?? ''); ?>">
                        </div>

                        <!-- Password -->
                        <div class="d-flex justify-content-between align-items-center mb-2">
                            <label class="auth-label mb-0">Password</label>
                            <a href="#" class="auth-forgot" onclick="alert('Demo: use user@grocerymart.com / user123')">Forgot password?</a>
                        </div>
                        <div class="auth-field">
                            <div class="af-icon"><i class="fa-solid fa-lock"></i></div>
                            <input type="password" name="password" id="loginPassword" placeholder="Enter your password" autocomplete="current-password" required>
                            <button type="button" class="toggle-pw" onclick="togglePw('loginPassword',this)">
                                <i class="fa-regular fa-eye"></i>
                            </button>
                        </div>

                        <!-- Remember me -->
                        <div class="auth-remember">
                            <input type="checkbox" id="remember" name="remember" <?php echo isset($_COOKIE['remember_user_email']) ? 'checked' : ''; ?>>
                            <label for="remember">Remember me on this device</label>
                        </div>

                        <button type="submit" class="btn-auth" id="loginBtn">
                            <i class="fa-solid fa-right-to-bracket me-2"></i> Sign In
                        </button>
                    </form>

                    <div class="auth-divider">OR</div>

                    <div class="auth-switch">
                        Don't have an account? <a href="register.php">Create one free →</a>
                    </div>

                    <!-- Demo credentials -->
                    <div class="demo-box">
                        <div class="demo-title"><i class="fa-solid fa-circle-info me-1"></i> Demo Credentials</div>
                        <div class="demo-row">
                            <span class="demo-role">👤 Customer</span>
                            <div style="display:flex;gap:6px;flex-wrap:wrap;justify-content:flex-end;">
                                <code>user@grocerymart.com</code>
                                <code>user123</code>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
function togglePw(id, btn) {
    const input = document.getElementById(id);
    const icon  = btn.querySelector('i');
    if (input.type === 'password') { input.type = 'text'; icon.classList.replace('fa-eye','fa-eye-slash'); }
    else { input.type = 'password'; icon.classList.replace('fa-eye-slash','fa-eye'); }
}
document.getElementById('loginForm').addEventListener('submit', function(e) {
    const em = document.getElementById('loginEmail').value.trim();
    const pw = document.getElementById('loginPassword').value.trim();
    if (!em || !pw) { e.preventDefault(); return; }
    const btn = document.getElementById('loginBtn');
    btn.innerHTML = '<i class="fa-solid fa-circle-notch fa-spin me-2"></i> Signing in…';
    btn.disabled = true;
});
</script>

<?php include __DIR__ . '/../includes/footer.php'; ?>
