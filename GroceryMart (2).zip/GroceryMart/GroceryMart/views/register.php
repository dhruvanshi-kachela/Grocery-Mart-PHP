<?php
$page_title = "Create Account";
include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/navbar.php';
?>

<style>
.auth-page-bg {
    min-height: calc(100vh - 68px);
    background: linear-gradient(135deg, #f0faf3 0%, #e8f5e9 40%, #f9fdf9 100%);
    display: flex; align-items: center; padding: 48px 0;
    position: relative; overflow: hidden;
}
.auth-page-bg::before {
    content: '';
    position: absolute; top: -80px; right: -80px;
    width: 400px; height: 400px; border-radius: 50%;
    background: radial-gradient(circle, rgba(76,175,80,0.12) 0%, transparent 70%);
    pointer-events: none;
}
.auth-page-bg::after {
    content: '';
    position: absolute; bottom: -60px; left: -60px;
    width: 300px; height: 300px; border-radius: 50%;
    background: radial-gradient(circle, rgba(46,125,50,0.09) 0%, transparent 70%);
    pointer-events: none;
}
.auth-card {
    background: #fff;
    border-radius: 28px;
    box-shadow: 0 20px 60px rgba(0,0,0,0.08), 0 4px 16px rgba(46,125,50,0.06);
    padding: 44px 40px;
    position: relative; z-index: 2;
    width: 100%; max-width: 500px; margin: 0 auto;
}
.auth-logo-wrap {
    width: 64px; height: 64px; border-radius: 20px;
    background: linear-gradient(135deg, #2E7D32, #4CAF50);
    display: flex; align-items: center; justify-content: center;
    font-size: 26px; color: #fff; margin: 0 auto 18px;
    box-shadow: 0 8px 24px rgba(76,175,80,0.35);
}
.auth-title { font-size: 26px; font-weight: 800; color: #1a1a1a; letter-spacing: -0.5px; margin-bottom: 6px; }
.auth-sub { color: #888; font-size: 14px; margin-bottom: 28px; }
.auth-label {
    font-size: 12px; font-weight: 700; color: #555;
    text-transform: uppercase; letter-spacing: 0.6px;
    margin-bottom: 6px; display: block;
}
.auth-field {
    display: flex; align-items: center;
    background: #f7f9f7; border: 2px solid transparent;
    border-radius: 14px; overflow: hidden;
    transition: border-color 0.2s, box-shadow 0.2s, background 0.2s;
    margin-bottom: 18px;
}
.auth-field:focus-within {
    background: #fff;
    border-color: #4CAF50;
    box-shadow: 0 0 0 4px rgba(76,175,80,0.1);
}
.auth-field .af-icon {
    width: 44px; display: flex; align-items: center; justify-content: center;
    color: #bbb; font-size: 14px; flex-shrink: 0; transition: color 0.2s;
}
.auth-field:focus-within .af-icon { color: #2E7D32; }
.auth-field input {
    flex: 1; border: none; background: transparent; outline: none;
    font-size: 14px; font-family: 'Poppins', sans-serif;
    color: #333; padding: 12px 12px 12px 0;
}
.auth-field input::placeholder { color: #ccc; }
.auth-field .toggle-pw {
    width: 44px; display: flex; align-items: center; justify-content: center;
    border: none; background: transparent; color: #ccc; cursor: pointer;
    font-size: 14px; transition: color 0.2s;
}
.auth-field .toggle-pw:hover { color: #2E7D32; }
.btn-auth {
    width: 100%; padding: 14px;
    background: linear-gradient(135deg, #2E7D32, #4CAF50);
    border: none; border-radius: 14px; color: #fff;
    font-size: 15px; font-weight: 700; font-family: 'Poppins', sans-serif;
    cursor: pointer; letter-spacing: 0.3px;
    box-shadow: 0 6px 20px rgba(76,175,80,0.35);
    transition: all 0.25s; margin-top: 10px;
}
.btn-auth:hover { transform: translateY(-2px); box-shadow: 0 10px 28px rgba(76,175,80,0.45); }
.btn-auth:active { transform: translateY(0); }
.auth-divider {
    display: flex; align-items: center; gap: 14px; margin: 24px 0;
    color: #ddd; font-size: 12px; font-weight: 600;
}
.auth-divider::before, .auth-divider::after { content:''; flex:1; height:1px; background:#eee; }
.auth-switch { text-align: center; font-size: 13px; color: #999; margin-top: 20px; }
.auth-switch a { color: #2E7D32; font-weight: 700; text-decoration: none; }
.auth-switch a:hover { text-decoration: underline; }

/* Side panel */
.auth-side {
    background: linear-gradient(160deg, #1B5E20 0%, #2E7D32 50%, #388E3C 100%);
    border-radius: 28px; padding: 48px 40px;
    height: 100%; min-height: 520px;
    display: flex; flex-direction: column; justify-content: center;
    position: relative; overflow: hidden;
}
.auth-side::before {
    content: '';
    position: absolute; top: -60px; right: -60px;
    width: 250px; height: 250px; border-radius: 50%;
    background: rgba(255,255,255,0.06);
}
.auth-side::after {
    content: '';
    position: absolute; bottom: -40px; left: -40px;
    width: 200px; height: 200px; border-radius: 50%;
    background: rgba(255,255,255,0.04);
}
.auth-side-content { position: relative; z-index: 2; }
.side-emoji { font-size: 56px; margin-bottom: 24px; line-height: 1; }
.side-title { font-size: 28px; font-weight: 800; color: #fff; letter-spacing: -0.5px; line-height: 1.2; margin-bottom: 16px; }
.side-sub { color: rgba(255,255,255,0.7); font-size: 14px; line-height: 1.7; margin-bottom: 36px; }
.side-feature { display: flex; align-items: center; gap: 14px; margin-bottom: 18px; }
.side-feature .sf-icon { width: 38px; height: 38px; border-radius: 12px; background: rgba(255,255,255,0.12); display: flex; align-items: center; justify-content: center; color: #A5D6A7; font-size: 16px; flex-shrink: 0; }
.side-feature .sf-text { font-size: 14px; color: rgba(255,255,255,0.9); font-weight: 500; }
@media (max-width: 991px) {
    .auth-card { padding: 36px 24px; }
    .auth-side { display: none; }
}
</style>

<div class="auth-page-bg">
    <div class="container">
        <div class="row align-items-center g-4 justify-content-center">

            <!-- Left side panel (desktop only) -->
            <div class="col-lg-5 d-none d-lg-block">
                <div class="auth-side">
                    <div class="auth-side-content">
                        <div class="side-emoji">🥗</div>
                        <h2 class="side-title">Join the GroceryMart Family!</h2>
                        <p class="side-sub">Create your free account to enjoy fast delivery, exclusive discounts, and farm-fresh organic products.</p>
                        <div class="side-feature"><div class="sf-icon"><i class="fa-solid fa-gift"></i></div><div class="sf-text">Get ₹50 Off your first order with code WELCOME50</div></div>
                        <div class="side-feature"><div class="sf-icon"><i class="fa-solid fa-clock-rotate-left"></i></div><div class="sf-text">Order tracking & quick re-ordering</div></div>
                        <div class="side-feature"><div class="sf-icon"><i class="fa-solid fa-shield-halved"></i></div><div class="sf-text">Safe & secure online payment options</div></div>
                    </div>
                </div>
            </div>

            <!-- Register Form Card -->
            <div class="col-lg-6 col-md-9">
                <div class="auth-card">
                    <div class="text-center">
                        <div class="auth-logo-wrap"><i class="fa-solid fa-user-plus"></i></div>
                        <h2 class="auth-title">Create Account</h2>
                        <p class="auth-sub">Sign up in seconds to start shopping</p>
                    </div>

                    <!-- Server Alert Notifications -->
                    <?php if (isset($_SESSION['error'])): ?>
                        <div style="background:#fde8e8;border:1px solid #f5c6c6;border-radius:12px;padding:12px 16px;display:flex;align-items:center;gap:10px;margin-bottom:20px;font-size:13px;color:#c62828;">
                            <i class="fa-solid fa-circle-exclamation"></i>
                            <?php echo htmlspecialchars($_SESSION['error']); unset($_SESSION['error']); ?>
                        </div>
                    <?php endif; ?>
                    <?php if (isset($_SESSION['success'])): ?>
                        <div style="background:#e8f5e9;border:1px solid #c8e6c9;border-radius:12px;padding:12px 16px;display:flex;align-items:center;gap:10px;margin-bottom:20px;font-size:13px;color:#2E7D32;">
                            <i class="fa-solid fa-circle-check"></i>
                            <?php echo htmlspecialchars($_SESSION['success']); unset($_SESSION['success']); ?>
                        </div>
                    <?php endif; ?>

                    <form action="register.php" method="POST" id="regForm" onsubmit="return validateRegForm(event)">
                        
                        <div class="row g-2">
                            <!-- Full Name -->
                            <div class="col-12">
                                <label class="auth-label">Full Name</label>
                                <div class="auth-field">
                                    <div class="af-icon"><i class="fa-regular fa-user"></i></div>
                                    <input type="text" name="name" id="regName" placeholder="e.g. John Doe" required>
                                </div>
                            </div>

                            <!-- Email -->
                            <div class="col-md-6">
                                <label class="auth-label">Email Address</label>
                                <div class="auth-field">
                                    <div class="af-icon"><i class="fa-regular fa-envelope"></i></div>
                                    <input type="email" name="email" id="regEmail" placeholder="you@example.com" required>
                                </div>
                            </div>

                            <!-- Mobile -->
                            <div class="col-md-6">
                                <label class="auth-label">Mobile Number</label>
                                <div class="auth-field">
                                    <div class="af-icon"><i class="fa-solid fa-mobile-screen-button"></i></div>
                                    <input type="tel" name="mobile" id="regMobile" placeholder="10-digit number" pattern="[0-9]{10}" maxlength="10" required>
                                </div>
                            </div>

                            <!-- Password -->
                            <div class="col-md-6">
                                <label class="auth-label">Password</label>
                                <div class="auth-field">
                                    <div class="af-icon"><i class="fa-solid fa-lock"></i></div>
                                    <input type="password" name="password" id="regPw" placeholder="Min. 8 characters" required minlength="8">
                                    <button type="button" class="toggle-pw" onclick="togglePw('regPw', this)">
                                        <i class="fa-regular fa-eye"></i>
                                    </button>
                                </div>
                            </div>

                            <!-- Confirm Password -->
                            <div class="col-md-6">
                                <label class="auth-label">Confirm Password</label>
                                <div class="auth-field">
                                    <div class="af-icon"><i class="fa-solid fa-shield-halved"></i></div>
                                    <input type="password" name="confirm_password" id="regCpw" placeholder="Re-enter password" required>
                                    <button type="button" class="toggle-pw" onclick="togglePw('regCpw', this)">
                                        <i class="fa-regular fa-eye"></i>
                                    </button>
                                </div>
                            </div>
                        </div>

                        <!-- Submit button -->
                        <button type="submit" class="btn-auth" id="regBtn">
                            <i class="fa-solid fa-user-check me-2"></i> Register Account
                        </button>
                    </form>

                    <div class="auth-divider">OR</div>

                    <div class="auth-switch">
                        Already have an account? <a href="login.php">Sign In here →</a>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>

<script>
function togglePw(id, btn) {
    const input = document.getElementById(id);
    const icon  = btn.querySelector('i');
    if (input.type === 'password') { 
        input.type = 'text'; 
        icon.classList.replace('fa-eye', 'fa-eye-slash'); 
    } else { 
        input.type = 'password'; 
        icon.classList.replace('fa-eye-slash', 'fa-eye'); 
    }
}

function validateRegForm(e) {
    const name = document.getElementById('regName').value.trim();
    const email = document.getElementById('regEmail').value.trim();
    const mobile = document.getElementById('regMobile').value.trim();
    const pw = document.getElementById('regPw').value;
    const cpw = document.getElementById('regCpw').value;

    if (!name || !email || !mobile || !pw || !cpw) {
        alert("Please fill in all required fields.");
        return false;
    }
    if (!/^[0-9]{10}$/.test(mobile)) {
        alert("Mobile number must be exactly 10 digits.");
        return false;
    }
    if (pw.length < 8) {
        alert("Password must be at least 8 characters long.");
        return false;
    }
    if (pw !== cpw) {
        alert("Passwords do not match.");
        return false;
    }

    const btn = document.getElementById('regBtn');
    btn.innerHTML = '<i class="fa-solid fa-circle-notch fa-spin me-2"></i> Creating account…';
    btn.disabled = true;
    return true;
}
</script>

<?php include __DIR__ . '/../includes/footer.php'; ?>

