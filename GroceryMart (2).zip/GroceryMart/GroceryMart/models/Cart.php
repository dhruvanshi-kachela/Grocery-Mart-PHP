<?php
require_once __DIR__ . '/../config/db.php';

class Cart {
    private $db;

    public function __construct() {
        $this->db = getDB();
    }

    /**
     * Get all cart items for a user including product details
     * @param int $userId
     * @return array
     */
    public function getItems($userId) {
        $stmt = $this->db->prepare("
            SELECT c.id as cart_id, c.product_id, c.quantity, 
                   p.name, p.price, p.discount, p.stock, p.weight, p.unit, p.image, p.brand
            FROM cart c
            JOIN products p ON c.product_id = p.id
            WHERE c.user_id = :user_id
            ORDER BY c.id ASC
        ");
        $stmt->execute(['user_id' => $userId]);
        return $stmt->fetchAll();
    }

    /**
     * Add product to cart (or update quantity if already exists)
     * @param int $userId
     * @param int $productId
     * @param int $quantity
     * @return bool
     */
    public function add($userId, $productId, $quantity = 1) {
        // Check if product already exists in cart
        $stmt = $this->db->prepare("SELECT id, quantity FROM cart WHERE user_id = :user_id AND product_id = :product_id");
        $stmt->execute(['user_id' => $userId, 'product_id' => $productId]);
        $existing = $stmt->fetch();

        if ($existing) {
            // Update quantity
            $newQuantity = $existing['quantity'] + $quantity;
            return $this->update($userId, $productId, $newQuantity);
        } else {
            // Insert new item
            $stmt = $this->db->prepare("INSERT INTO cart (user_id, product_id, quantity) VALUES (:user_id, :product_id, :quantity)");
            return $stmt->execute([
                'user_id' => $userId,
                'product_id' => $productId,
                'quantity' => $quantity
            ]);
        }
    }

    /**
     * Update product quantity in cart
     * @param int $userId
     * @param int $productId
     * @param int $quantity
     * @return bool
     */
    public function update($userId, $productId, $quantity) {
        if ($quantity <= 0) {
            return $this->delete($userId, $productId);
        }
        $stmt = $this->db->prepare("UPDATE cart SET quantity = :quantity WHERE user_id = :user_id AND product_id = :product_id");
        return $stmt->execute([
            'quantity' => $quantity,
            'user_id' => $userId,
            'product_id' => $productId
        ]);
    }

    /**
     * Delete product from cart
     * @param int $userId
     * @param int $productId
     * @return bool
     */
    public function delete($userId, $productId) {
        $stmt = $this->db->prepare("DELETE FROM cart WHERE user_id = :user_id AND product_id = :product_id");
        return $stmt->execute([
            'user_id' => $userId,
            'product_id' => $productId
        ]);
    }

    /**
     * Clear all items from a user's cart (after checkout)
     * @param int $userId
     * @return bool
     */
    public function clear($userId) {
        $stmt = $this->db->prepare("DELETE FROM cart WHERE user_id = :user_id");
        return $stmt->execute(['user_id' => $userId]);
    }

    /**
     * Merge Session Cart (Guest cart) into DB cart when user logs in
     * @param int $userId
     * @param array $sessionCart [product_id => quantity]
     */
    public function mergeSessionCart($userId, $sessionCart) {
        if (empty($sessionCart)) return;
        
        foreach ($sessionCart as $productId => $quantity) {
            $this->add($userId, intval($productId), intval($quantity));
        }
    }
}
