<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/Product.php';

class Order {
    private $db;
    private $productModel;

    public function __construct() {
        $this->db = getDB();
        $this->productModel = new Product();
    }

    /**
     * Create a new order inside a database transaction to ensure atomicity
     * @param int $userId
     * @param int $addressId
     * @param float $total
     * @param float $discount
     * @param string $paymentMethod
     * @param string $paymentStatus
     * @param array $cartItems List of cart items containing quantity, price, and product_id
     * @return int|false The created order ID, or false on rollback
     */
    public function create($userId, $addressId, $total, $discount, $paymentMethod, $paymentStatus, $cartItems) {
        try {
            // Begin Transaction
            $this->db->beginTransaction();

            // 1. Insert into orders table
            $stmt = $this->db->prepare("
                INSERT INTO orders (user_id, address_id, total, discount, payment_method, payment_status, order_status) 
                VALUES (:user_id, :address_id, :total, :discount, :payment_method, :payment_status, 'Placed')
            ");
            
            $stmt->execute([
                'user_id' => $userId,
                'address_id' => $addressId,
                'total' => $total,
                'discount' => $discount,
                'payment_method' => $paymentMethod,
                'payment_status' => $paymentStatus
            ]);
            
            $orderId = $this->db->lastInsertId();

            // 2. Insert items and decrement stock
            $stmt_item = $this->db->prepare("
                INSERT INTO order_items (order_id, product_id, quantity, price) 
                VALUES (:order_id, :product_id, :quantity, :price)
            ");

            foreach ($cartItems as $item) {
                $pid = intval($item['product_id']);
                $qty = intval($item['quantity']);
                // Calculate net price
                $netPrice = getDiscountedPrice($item['price'], $item['discount']);

                // Verify stock availability once more
                $stock = $this->productModel->getStock($pid);
                if ($stock < $qty) {
                    // Fail the whole order if stock ran out
                    throw new Exception("Product '{$item['name']}' went out of stock before payment could complete.");
                }

                // Insert order item
                $stmt_item->execute([
                    'order_id' => $orderId,
                    'product_id' => $pid,
                    'quantity' => $qty,
                    'price' => $netPrice
                ]);

                // Decrement stock
                $this->productModel->updateStock($pid, -$qty);
            }

            // Commit Transaction
            $this->db->commit();
            return $orderId;

        } catch (Exception $e) {
            // Rollback if any error occurs
            $this->db->rollBack();
            error_log("Order creation failed: " . $e->getMessage());
            $_SESSION['error'] = $e->getMessage();
            return false;
        }
    }

    /**
     * Get order details by ID
     * @param int $id
     * @return array|false
     */
    public function findById($id) {
        $stmt = $this->db->prepare("
            SELECT o.*, a.full_address, a.city, a.state, a.zipcode, a.country, u.name as user_name, u.email as user_email, u.mobile as user_mobile
            FROM orders o
            LEFT JOIN addresses a ON o.address_id = a.id
            JOIN users u ON o.user_id = u.id
            WHERE o.id = :id
        ");
        $stmt->execute(['id' => $id]);
        return $stmt->fetch();
    }

    /**
     * Get order details by ID and verify user ownership
     * @param int $id
     * @param int $userId
     * @return array|false
     */
    public function findByIdAndUser($id, $userId) {
        $stmt = $this->db->prepare("
            SELECT o.*, a.full_address, a.city, a.state, a.zipcode, a.country 
            FROM orders o
            LEFT JOIN addresses a ON o.address_id = a.id
            WHERE o.id = :id AND o.user_id = :user_id
        ");
        $stmt->execute(['id' => $id, 'user_id' => $userId]);
        return $stmt->fetch();
    }

    /**
     * Get all orders for a specific user
     * @param int $userId
     * @return array
     */
    public function getByUser($userId) {
        $stmt = $this->db->prepare("
            SELECT id, total, discount, payment_method, payment_status, order_status, created_at 
            FROM orders 
            WHERE user_id = :user_id 
            ORDER BY id DESC
        ");
        $stmt->execute(['user_id' => $userId]);
        return $stmt->fetchAll();
    }

    /**
     * Get items in a specific order
     * @param int $orderId
     * @return array
     */
    public function getOrderItems($orderId) {
        $stmt = $this->db->prepare("
            SELECT oi.*, p.name, p.image, p.weight, p.unit, p.brand
            FROM order_items oi
            JOIN products p ON oi.product_id = p.id
            WHERE oi.order_id = :order_id
        ");
        $stmt->execute(['order_id' => $orderId]);
        return $stmt->fetchAll();
    }

    /**
     * Cancel an order (updates status and returns stock to products)
     * @param int $orderId
     * @param int $userId
     * @return bool
     */
    public function cancelByUser($orderId, $userId) {
        try {
            $this->db->beginTransaction();

            // Fetch order and verify it can be cancelled (only Placed or Packed can be cancelled)
            $stmt = $this->db->prepare("SELECT order_status FROM orders WHERE id = :id AND user_id = :user_id");
            $stmt->execute(['id' => $orderId, 'user_id' => $userId]);
            $status = $stmt->fetchColumn();

            if (!$status || in_array($status, ['Shipped', 'Out for Delivery', 'Delivered', 'Cancelled'])) {
                throw new Exception("Order cannot be cancelled in its current state.");
            }

            // Update order status
            $stmt_update = $this->db->prepare("UPDATE orders SET order_status = 'Cancelled' WHERE id = :id");
            $stmt_update->execute(['id' => $orderId]);

            // Restore stocks
            $items = $this->getOrderItems($orderId);
            foreach ($items as $item) {
                $this->productModel->updateStock($item['product_id'], $item['quantity']);
            }

            $this->db->commit();
            return true;
        } catch (Exception $e) {
            $this->db->rollBack();
            error_log("Order cancellation failed: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Admin Panel: Fetch all orders
     * @return array
     */
    public function getAllOrders() {
        $stmt = $this->db->query("
            SELECT o.id, o.total, o.order_status, o.payment_method, o.created_at, u.name as user_name 
            FROM orders o
            JOIN users u ON o.user_id = u.id
            ORDER BY o.id DESC
        ");
        return $stmt->fetchAll();
    }

    /**
     * Admin Panel: Update order status
     * @param int $orderId
     * @param string $status
     * @return bool
     */
    public function updateStatus($orderId, $status) {
        $stmt = $this->db->prepare("UPDATE orders SET order_status = :status WHERE id = :id");
        return $stmt->execute([
            'status' => $status,
            'id' => $orderId
        ]);
    }

    /**
     * Admin Panel: Update payment status
     * @param int $orderId
     * @param string $status
     * @return bool
     */
    public function updatePaymentStatus($orderId, $status) {
        $stmt = $this->db->prepare("UPDATE orders SET payment_status = :status WHERE id = :id");
        return $stmt->execute([
            'status' => $status,
            'id' => $orderId
        ]);
    }

    /**
     * Fetch order statistics (for admin dashboard cards)
     * @return array
     */
    public function getStatistics() {
        $stats = [];
        // Total orders
        $stats['total_orders'] = intval($this->db->query("SELECT COUNT(*) FROM orders")->fetchColumn());
        // Revenue
        $stats['revenue'] = floatval($this->db->query("SELECT SUM(total) FROM orders WHERE order_status != 'Cancelled'")->fetchColumn());
        // Pending orders
        $stats['pending_orders'] = intval($this->db->query("SELECT COUNT(*) FROM orders WHERE order_status IN ('Placed', 'Packed')")->fetchColumn());
        return $stats;
    }
}
