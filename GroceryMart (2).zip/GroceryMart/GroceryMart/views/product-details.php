<?php
$page_title = $product['name'];
include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/navbar.php';

$discounted_price = getDiscountedPrice($product['price'], $product['discount']);
?>

<div class="container my-5">
    <!-- Breadcrumb -->
    <nav aria-label="breadcrumb" class="mb-4">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="index.php" class="text-success text-decoration-none">Home</a></li>
            <li class="breadcrumb-item"><a href="shop.php" class="text-success text-decoration-none">Shop</a></li>
            <li class="breadcrumb-item"><a href="shop.php?category=<?php echo $product['category_id']; ?>" class="text-success text-decoration-none"><?php echo htmlspecialchars($product['category_name']); ?></a></li>
            <li class="breadcrumb-item active" aria-current="page"><?php echo htmlspecialchars($product['name']); ?></li>
        </ol>
    </nav>

    <!-- Product Profile Card -->
    <div class="row g-5">
        <!-- Product Image -->
        <div class="col-md-6">
            <div class="card card-custom p-3 text-center bg-white" style="position: sticky; top: 100px;">
                <!-- Discount Badge -->
                <?php if ($product['discount'] > 0): ?>
                    <span class="discount-badge" style="font-size: 14px; padding: 6px 12px;"><?php echo round($product['discount']); ?>% OFF</span>
                <?php endif; ?>

                <!-- Wishlist Toggle -->
                <?php 
                    $in_wishlist = false; 
                    if (isset($_SESSION['user_id'])) {
                        $wish_stmt = getDB()->prepare("SELECT COUNT(*) FROM wishlist WHERE user_id = :uid AND product_id = :pid");
                        $wish_stmt->execute(['uid' => $_SESSION['user_id'], 'pid' => $product['id']]);
                        $in_wishlist = $wish_stmt->fetchColumn() > 0;
                    }
                ?>
                <button class="wishlist-btn <?php echo $in_wishlist ? 'active' : ''; ?>" onclick="toggleWishlist(<?php echo $product['id']; ?>, this)" title="Add to Wishlist" style="width: 44px; height: 44px; font-size: 20px;">
                    <i class="<?php echo $in_wishlist ? 'fa-solid' : 'fa-regular'; ?> fa-heart"></i>
                </button>

                <div class="product-img-wrapper" style="height: 400px; background-color: transparent;">
                    <img src="<?php echo getProductImage($product['image'], $product['name']); ?>" alt="<?php echo htmlspecialchars($product['name']); ?>" class="img-fluid" style="max-height: 100%; object-fit: contain;">
                </div>
            </div>
        </div>

        <!-- Product Details -->
        <div class="col-md-6">
            <div class="ps-lg-3">
                <span class="text-success small fw-bold text-uppercase tracking-wider"><?php echo htmlspecialchars($product['brand'] ?? 'GroceryMart'); ?></span>
                <h2 class="fw-bold mt-1 mb-2"><?php echo htmlspecialchars($product['name']); ?></h2>
                
                <!-- Ratings overview -->
                <div class="d-flex align-items-center gap-2 mb-4 text-warning">
                    <div class="small">
                        <?php
                            $stars = round($averageRating > 0 ? $averageRating : 4.5);
                            for ($i = 1; $i <= 5; $i++) {
                                echo $i <= $stars ? '<i class="fa-solid fa-star"></i>' : '<i class="fa-regular fa-star"></i>';
                            }
                        ?>
                    </div>
                    <span class="text-dark fw-medium small">(<?php echo $averageRating > 0 ? number_format($averageRating, 1) : '4.5'; ?> / 5)</span>
                    <span class="text-muted small">|</span>
                    <a href="#reviewsSection" class="text-success text-decoration-none small"><?php echo count($reviews); ?> Reviews</a>
                </div>

                <!-- Price and details -->
                <div class="mb-4 bg-light p-3 rounded-4 border border-light">
                    <div class="d-flex align-items-baseline gap-3">
                        <h3 class="fw-bold text-success mb-0"><?php echo formatPrice($discounted_price); ?></h3>
                        <?php if ($product['discount'] > 0): ?>
                            <span class="text-muted text-decoration-line-through fs-5"><?php echo formatPrice($product['price']); ?></span>
                        <?php endif; ?>
                    </div>
                    <small class="text-muted">Prices include all applicable taxes</small>
                </div>

                <div class="row g-3 mb-4">
                    <div class="col-6">
                        <span class="text-muted small d-block">Pack Weight / Size:</span>
                        <span class="fw-semibold text-dark fs-6"><i class="fa-solid fa-weight-scale me-1 text-success"></i> <?php echo htmlspecialchars($product['weight'] ?? '1 unit'); ?></span>
                    </div>
                    <div class="col-6">
                        <span class="text-muted small d-block">Stock Status:</span>
                        <?php if ($product['stock'] > 10): ?>
                            <span class="badge bg-success-subtle text-success border border-success-subtle px-3 py-1 rounded-pill"><i class="fa-solid fa-circle-check me-1"></i> In Stock</span>
                        <?php elseif ($product['stock'] > 0): ?>
                            <span class="badge bg-warning-subtle text-warning border border-warning-subtle px-3 py-1 rounded-pill"><i class="fa-solid fa-circle-exclamation me-1"></i> Low Stock (Only <?php echo $product['stock']; ?> left!)</span>
                        <?php else: ?>
                            <span class="badge bg-danger-subtle text-danger border border-danger-subtle px-3 py-1 rounded-pill"><i class="fa-solid fa-circle-xmark me-1"></i> Out of Stock</span>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Description -->
                <div class="mb-4">
                    <h6 class="fw-bold mb-2">Description</h6>
                    <p class="text-muted small"><?php echo nl2br(htmlspecialchars($product['description'])); ?></p>
                </div>

                <!-- Cart Actions Form -->
                <?php if ($product['stock'] > 0): ?>
                    <div class="d-flex align-items-center gap-3 mt-4 pt-3 border-top">
                        <div class="quantity-selector">
                            <label class="form-label small text-muted mb-1 d-block">Quantity</label>
                            <input type="number" class="form-control text-center rounded-pill py-2" id="prodQuantity" value="1" min="1" max="<?php echo $product['stock']; ?>" style="width: 100px;">
                        </div>
                        <div class="flex-grow-1 pt-4">
                            <button onclick="addToCart(<?php echo $product['id']; ?>, $('#prodQuantity').val())" class="btn btn-primary-custom w-100 py-2.5 rounded-pill shadow-sm">
                                <i class="fa-solid fa-basket-shopping me-2"></i> Add To Shopping Cart
                            </button>
                        </div>
                    </div>
                <?php else: ?>
                    <div class="alert alert-warning alert-custom mt-4" role="alert">
                        <i class="fa-solid fa-bell me-2"></i> This product is currently sold out. We are restock-inspecting this item soon.
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Related Products -->
    <?php if (!empty($relatedProducts)): ?>
        <section class="my-5 pt-5 border-top">
            <h3 class="fw-bold mb-4">Related Products</h3>
            <div class="row g-4">
                <?php foreach ($relatedProducts as $related): ?>
                    <div class="col-sm-6 col-md-3">
                        <div class="card card-custom h-100">
                            <!-- Image -->
                            <div class="product-img-wrapper">
                                <a href="product.php?id=<?php echo $related['id']; ?>">
                                    <img src="<?php echo getProductImage($related['image'], $related['name']); ?>" alt="<?php echo htmlspecialchars($related['name']); ?>" class="product-img">
                                </a>
                            </div>
                            <div class="card-body d-flex flex-column p-3">
                                <span class="text-muted small mb-1"><?php echo htmlspecialchars($related['brand'] ?? 'GroceryMart'); ?></span>
                                <h6 class="card-title mb-2">
                                    <a href="product.php?id=<?php echo $related['id']; ?>" class="text-dark text-decoration-none fw-semibold">
                                        <?php echo htmlspecialchars($related['name']); ?>
                                    </a>
                                </h6>
                                <div class="mt-auto d-flex justify-content-between align-items-center pt-2 border-top">
                                    <span class="fw-bold text-success"><?php echo formatPrice(getDiscountedPrice($related['price'], $related['discount'])); ?></span>
                                    <a href="product.php?id=<?php echo $related['id']; ?>" class="btn btn-outline-primary-custom btn-sm rounded-pill py-1 px-2.5 small">View</a>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </section>
    <?php endif; ?>

    <!-- Reviews and Ratings Section -->
    <section class="my-5 pt-5 border-top" id="reviewsSection">
        <div class="row g-4">
            <!-- Review statistics summary -->
            <div class="col-md-4">
                <div class="card card-custom p-4 bg-light border-0">
                    <h5 class="fw-bold mb-3">Customer Reviews</h5>
                    <div class="d-flex align-items-center gap-3 mb-3">
                        <h1 class="fw-bold text-success mb-0"><?php echo $averageRating > 0 ? number_format($averageRating, 1) : '4.5'; ?></h1>
                        <div>
                            <div class="text-warning small">
                                <?php
                                    for ($i = 1; $i <= 5; $i++) {
                                        echo $i <= $stars ? '<i class="fa-solid fa-star"></i>' : '<i class="fa-regular fa-star"></i>';
                                    }
                                ?>
                            </div>
                            <span class="text-muted small">Based on <?php echo count($reviews); ?> reviews</span>
                        </div>
                    </div>
                    
                    <p class="text-muted small mb-0">Share your thoughts on this grocery product with other shoppers!</p>
                </div>
            </div>

            <!-- Reviews list & write review form -->
            <div class="col-md-8">
                <!-- Submit a Review Form -->
                <div class="card card-custom p-4 mb-4 border border-light">
                    <h5 class="fw-bold mb-3">Write a Review</h5>
                    <?php if (isset($_SESSION['user_id'])): ?>
                        <form action="product.php" method="POST" class="needs-validation" novalidate>
                            <input type="hidden" name="product_id" value="<?php echo $product['id']; ?>">
                            
                            <div class="mb-3">
                                <label class="form-label small fw-medium">Rating (1 to 5 Stars)</label>
                                <select class="form-select bg-light border-0" name="rating" required>
                                    <option value="5">★★★★★ (5 Stars - Excellent)</option>
                                    <option value="4">★★★★☆ (4 Stars - Good)</option>
                                    <option value="3">★★★☆☆ (3 Stars - Average)</option>
                                    <option value="2">★★☆☆☆ (2 Stars - Poor)</option>
                                    <option value="1">★☆☆☆☆ (1 Star - Terrible)</option>
                                </select>
                            </div>

                            <div class="mb-3">
                                <label for="review" class="form-label small fw-medium">Your Review Comment</label>
                                <textarea class="form-control bg-light border-0" id="review" name="review" rows="3" required placeholder="What did you like or dislike about this product? (e.g. freshness, taste, weight, package quality)"></textarea>
                                <div class="invalid-feedback">Please enter your review comments.</div>
                            </div>

                            <button type="submit" name="submit_review" class="btn btn-primary-custom px-4 rounded-pill">Submit Review</button>
                        </form>
                    <?php else: ?>
                        <div class="alert alert-secondary alert-custom d-flex align-items-center justify-content-between mb-0" role="alert">
                            <span class="small"><i class="fa-solid fa-lock text-muted me-2"></i> You must be logged in to submit a review for this product.</span>
                            <a href="login.php" class="btn btn-primary-custom btn-sm rounded-pill px-3">Sign In</a>
                        </div>
                    <?php endif; ?>
                </div>

                <!-- Reviews Listing -->
                <h5 class="fw-bold mb-3">Recent Feedback (<?php echo count($reviews); ?>)</h5>
                <?php if (!empty($reviews)): ?>
                    <div class="d-flex flex-column gap-3">
                        <?php foreach ($reviews as $rev): ?>
                            <div class="bg-white p-3 rounded-4 border border-light shadow-sm">
                                <div class="d-flex justify-content-between align-items-center mb-2">
                                    <div>
                                        <h6 class="fw-bold mb-0 small"><?php echo htmlspecialchars($rev['user_name']); ?></h6>
                                        <span class="text-warning small" style="font-size: 10px;">
                                            <?php
                                                for ($i = 1; $i <= 5; $i++) {
                                                    echo $i <= $rev['rating'] ? '<i class="fa-solid fa-star"></i>' : '<i class="fa-regular fa-star"></i>';
                                                }
                                            ?>
                                        </span>
                                    </div>
                                    <span class="text-muted small" style="font-size: 11px;"><?php echo date('d M Y', strtotime($rev['created_at'])); ?></span>
                                </div>
                                <p class="text-muted small mb-0"><?php echo nl2br(htmlspecialchars($rev['review'])); ?></p>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <p class="text-muted small text-center py-4 bg-white rounded-4 border">No reviews yet for this product. Be the first to share your experience!</p>
                <?php endif; ?>
            </div>
        </div>
    </section>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>
