<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../controllers/AuthController.php';
require_once __DIR__ . '/utils.php';

// Enforce admin validation
AuthController::checkAdminAuth();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($page_title) ? $page_title . " - Admin Panel" : "Grocery Mart - Admin Control"; ?></title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <!-- Main Style CSS -->
    <link href="../assets/css/style.css" rel="stylesheet">
</head>
<body class="bg-light">

<!-- Admin Navigation Header -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark py-3">
    <div class="container-fluid px-4">
        <a class="navbar-brand fw-bold text-success" href="../index.php">
            <i class="fa-solid fa-basket-shopping"></i> GroceryMart Admin
        </a>
        <div class="d-flex align-items-center gap-3">
            <span class="text-white-50 small"><i class="fa-solid fa-user-shield text-success me-1"></i> Admin: <?php echo htmlspecialchars($_SESSION['admin_name'] ?? $_SESSION['user_name'] ?? 'System Admin'); ?></span>
            <a href="../admin/login.php?logout=1" class="btn btn-sm btn-outline-danger rounded-pill px-3 py-1 font-size-11">
                <i class="fa-solid fa-right-from-bracket me-1"></i> Logout
            </a>
        </div>
    </div>
</nav>

<div class="container-fluid px-4 my-4">
    <div class="row g-4">
