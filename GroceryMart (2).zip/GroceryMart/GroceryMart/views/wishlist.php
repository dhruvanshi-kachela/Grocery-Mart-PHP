<?php
$page_title = "My Wishlist";
include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/navbar.php';
?>

<div class="container my-5" style="min-height: 70vh;">
    <!-- Breadcrumb -->
    <nav aria-label="breadcrumb" class="mb-4">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="index.php" class="text-success text-decoration-none">Home</a></li>
            <li class="breadcrumb-item active" aria-current="page">My Wishlist</li>
        </ol>
    </nav>

    <h3 class="fw-bold mb-4">My Wishlist</h3>

    <?php if (!empty($wishlist_items)): ?>
        <div class="row g-4 wishlist-grid">
            <?php foreach ($wishlist_items as $item): ?>
                <div class="col-sm-6 col-md-4 col-lg-3" id="wishlist-col-<?php echo $item['product_id']; ?>">
                    <div class="card card-custom h-100">
                        <!-- Discount Badge -->
                        <?php if ($item['discount'] > 0): ?>
                            <span class="discount-badge"><?php echo round($item['discount']); ?>% OFF</span>
                        <?php endif; ?>

                        <!-- Remove Button -->
                        <button class="wishlist-btn active" onclick="toggleWishlist(<?php echo $item['product_id']; ?>, this)" title="Remove from Wishlist">
                            <i class="fa-solid fa-heart"></i>
                        </button>

                        <!-- Image -->
                        <div class="product-img-wrapper">
                            <a href="product.php?id=<?php echo $item['product_id']; ?>">
                                <img src="<?php echo getProductImage($item['image'], $item['name']); ?>" alt="<?php echo htmlspecialchars($item['name']); ?>" class="product-img">
                            </a>
                        </div>

                        <!-- Card Body -->
                        <div class="card-body d-flex flex-column p-3">
                            <span class="text-muted small mb-1"><?php echo htmlspecialchars($item['brand'] ?? 'GroceryMart'); ?></span>
                            <h6 class="card-title mb-2">
                                <a href="product.php?id=<?php echo $item['product_id']; ?>" class="text-dark text-decoration-none fw-semibold">
                                    <?php echo htmlspecialchars($item['name']); ?>
                                </a>
                            </h6>
                            <div class="small text-muted mb-3">
                                Unit: <?php echo htmlspecialchars($item['weight'] ?? '1 unit'); ?>
                            </div>

                            <!-- Price and Add/Move to Cart -->
                            <div class="mt-auto d-flex justify-content-between align-items-center pt-2 border-top">
                                <div>
                                    <span class="fw-bold text-success fs-5">
                                        <?php echo formatPrice(getDiscountedPrice($item['price'], $item['discount'])); ?>
                                    </span>
                                    <?php if ($item['discount'] > 0): ?>
                                        <br>
                                        <span class="text-muted text-decoration-line-through small" style="font-size: 11px;">
                                            <?php echo formatPrice($item['price']); ?>
                                        </span>
                                    <?php endif; ?>
                                </div>
                                <?php if ($item['stock'] > 0): ?>
                                    <button onclick="moveToCart(<?php echo $item['product_id']; ?>)" class="btn btn-primary-custom px-3 py-2 rounded-pill small">
                                        <i class="fa-solid fa-cart-plus me-1"></i> Add
                                    </button>
                                <?php else: ?>
                                    <span class="badge bg-danger rounded-pill px-2 py-1">Out of Stock</span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php else: ?>
        <!-- Empty Wishlist State -->
        <div class="text-center py-5 bg-white rounded-4 border p-5">
            <div class="category-card-img-wrapper mb-4" style="width: 90px; height: 90px; display: inline-flex; align-items: center; justify-content: center; background-color: var(--accent-light);">
                <i class="fa-regular fa-heart text-warning" style="font-size: 40px;"></i>
            </div>
            <h4>Your Wishlist is Empty</h4>
            <p class="text-muted small">You haven't saved any grocery favorites yet. Start browsing now!</p>
            <a href="shop.php" class="btn btn-primary-custom rounded-pill mt-3 px-4 py-2">Start Shopping</a>
        </div>
    <?php endif; ?>
</div>

<script>
// Move item from Wishlist to Cart (Add to Cart + Remove from Wishlist)
function moveToCart(productId) {
    // 1. Add item to cart
    $.ajax({
        url: 'cart.php',
        method: 'POST',
        data: {
            action: 'add',
            product_id: productId,
            quantity: 1
        },
        dataType: 'json',
        success: function(cartResponse) {
            if (cartResponse.success) {
                // Update cart badge
                updateCartBadge(cartResponse.cart_count);
                
                // 2. Remove item from wishlist
                $.ajax({
                    url: 'wishlist.php',
                    method: 'POST',
                    data: {
                        action: 'toggle',
                        product_id: productId
                    },
                    dataType: 'json',
                    success: function(wishResponse) {
                        if (wishResponse.success) {
                            showToast("Item successfully moved to cart!", 'success');
                            
                            // Animate removal from grid
                            $(`#wishlist-col-${productId}`).fadeOut(500, function() {
                                $(this).remove();
                                // If no items are left, refresh page to show empty state
                                if ($('.wishlist-grid').children(':visible').length === 0) {
                                    window.location.reload();
                                }
                            });
                            
                            // Update wishlist count
                            updateWishlistBadge(wishResponse.wishlist_count);
                        }
                    }
                });
            } else {
                showToast(cartResponse.message || 'Error adding to cart', 'danger');
            }
        },
        error: function() {
            showToast('Network error, please try again.', 'danger');
        }
    });
}
</script>

<?php include __DIR__ . '/../includes/footer.php'; ?>
