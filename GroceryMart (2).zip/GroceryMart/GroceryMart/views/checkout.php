<?php
$page_title = "Checkout";
include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/navbar.php';
?>

<div class="container my-5">
    <!-- Breadcrumb -->
    <nav aria-label="breadcrumb" class="mb-4">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="index.php" class="text-success text-decoration-none">Home</a></li>
            <li class="breadcrumb-item"><a href="cart.php" class="text-success text-decoration-none">Cart</a></li>
            <li class="breadcrumb-item active" aria-current="page">Checkout</li>
        </ol>
    </nav>

    <h3 class="fw-bold mb-4">Secure Checkout</h3>

    <form action="checkout.php" method="POST" id="checkoutForm" class="needs-validation" novalidate>
        <input type="hidden" name="place_order" value="1">
        
        <div class="row g-4">
            <!-- Left Side - Address and Payment options -->
            <div class="col-lg-8">
                <!-- Section 1: Shipping Address -->
                <div class="card card-custom p-4 border-light shadow-sm mb-4">
                    <h5 class="fw-bold mb-3"><i class="fa-solid fa-location-dot text-success me-2"></i>1. Shipping Address</h5>
                    
                    <?php if (!empty($addresses)): ?>
                        <div class="row g-3 mb-4">
                            <?php foreach ($addresses as $index => $addr): ?>
                                <div class="col-md-6">
                                    <div class="card p-3 rounded-4 border <?php echo $index === 0 ? 'border-success bg-success-subtle' : 'border-light bg-light'; ?> h-100 address-card">
                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="address_id" id="addr_<?php echo $addr['id']; ?>" value="<?php echo $addr['id']; ?>" <?php echo $index === 0 ? 'checked' : ''; ?> onchange="highlightAddress(this)">
                                            <label class="form-check-label fw-semibold text-dark small d-block mb-1" for="addr_<?php echo $addr['id']; ?>">
                                                Address #<?php echo $index + 1; ?>
                                            </label>
                                            <p class="text-muted small mb-0 mt-1">
                                                <?php echo htmlspecialchars($addr['full_address']); ?>, <br>
                                                <?php echo htmlspecialchars($addr['city']); ?>, <?php echo htmlspecialchars($addr['state']); ?> - <?php echo htmlspecialchars($addr['zipcode']); ?>
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php else: ?>
                        <div class="alert alert-warning py-3 px-4 alert-custom mb-4" role="alert">
                            <i class="fa-solid fa-triangle-exclamation me-2"></i> You have no saved shipping addresses. Please add a shipping address below.
                        </div>
                    <?php endif; ?>

                    <!-- Add Address Button trigger -->
                    <button class="btn btn-outline-primary-custom btn-sm rounded-pill px-3" type="button" data-bs-toggle="collapse" data-bs-target="#newAddressCollapse" aria-expanded="false" aria-controls="newAddressCollapse">
                        <i class="fa-solid fa-plus me-1"></i> Add New Shipping Address
                    </button>

                    <!-- Add Address Collapse Form -->
                    <div class="collapse mt-4" id="newAddressCollapse">
                        <div class="card p-4 rounded-4 border border-light bg-light">
                            <h6 class="fw-bold mb-3">Add Shipping Location</h6>
                            <!-- Alternate form submitting to the same file with add_address action -->
                            <div class="needs-validation-address">
                                <div class="mb-3">
                                    <label for="full_address" class="form-label small fw-medium">Street Address / Landmark</label>
                                    <input type="text" class="form-control bg-white border-0 py-2" id="full_address" placeholder="e.g. Flat 301, Lakeview Residency">
                                </div>
                                <div class="row g-3 mb-3">
                                    <div class="col-md-4">
                                        <label for="city" class="form-label small fw-medium">City</label>
                                        <input type="text" class="form-control bg-white border-0 py-2" id="city" placeholder="e.g. Bangalore">
                                    </div>
                                    <div class="col-md-4">
                                        <label for="state" class="form-label small fw-medium">State</label>
                                        <input type="text" class="form-control bg-white border-0 py-2" id="state" placeholder="e.g. Karnataka">
                                    </div>
                                    <div class="col-md-4">
                                        <label for="zipcode" class="form-label small fw-medium">Zip Code / PIN</label>
                                        <input type="text" class="form-control bg-white border-0 py-2" id="zipcode" placeholder="e.g. 560103">
                                    </div>
                                </div>
                                <button type="button" class="btn btn-success btn-sm rounded-pill px-4 py-2" onclick="saveAddressAJAX()">Save Address</button>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Section 2: Payment Method -->
                <div class="card card-custom p-4 border-light shadow-sm mb-4">
                    <h5 class="fw-bold mb-3"><i class="fa-solid fa-credit-card text-success me-2"></i>2. Payment Method</h5>

                    <div class="d-flex flex-column gap-3">
                        <!-- COD option -->
                        <div class="card p-3 rounded-4 border border-success bg-success-subtle payment-method-card">
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="payment_method" id="pay_cod" value="COD" checked onchange="togglePaymentFields(this)">
                                <label class="form-check-label fw-bold text-dark small" for="pay_cod">
                                    <i class="fa-solid fa-hand-holding-dollar me-2 text-success"></i> Cash on Delivery (COD)
                                </label>
                                <p class="text-muted small mb-0 mt-1">Pay with cash when your groceries are delivered to your door.</p>
                            </div>
                        </div>

                        <!-- Card option -->
                        <div class="card p-3 rounded-4 border border-light bg-light payment-method-card">
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="payment_method" id="pay_card" value="Card" onchange="togglePaymentFields(this)">
                                <label class="form-check-label fw-bold text-dark small" for="pay_card">
                                    <i class="fa-solid fa-credit-card me-2 text-primary"></i> Credit / Debit Card
                                </label>
                                <p class="text-muted small mb-0 mt-1">Pay securely with your Visa, Mastercard, or RuPay card.</p>
                            </div>

                            <!-- Card fields (hidden by default) -->
                            <div id="cardDetailsBlock" class="mt-3" style="display:none;">
                                <div class="mb-3">
                                    <label for="card_number" class="form-label small fw-medium">Card Number</label>
                                    <input type="text" class="form-control bg-white border-0 py-2 font-monospace" id="card_number" name="card_number" placeholder="4111 2222 3333 4444" maxlength="19">
                                </div>
                                <div class="row g-3">
                                    <div class="col-6">
                                        <label for="card_expiry" class="form-label small fw-medium">Expiry Date</label>
                                        <input type="text" class="form-control bg-white border-0 py-2 text-center" id="card_expiry" name="card_expiry" placeholder="MM/YY" maxlength="5">
                                    </div>
                                    <div class="col-6">
                                        <label for="card_cvv" class="form-label small fw-medium">CVV</label>
                                        <input type="password" class="form-control bg-white border-0 py-2 text-center" id="card_cvv" name="card_cvv" placeholder="123" maxlength="3">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Right Side - Summary and Checkout Actions -->
            <div class="col-lg-4">
                <div class="card card-custom p-4 border-light shadow-sm" style="position: sticky; top: 100px;">
                    <h5 class="fw-bold mb-3">Order Items</h5>
                    
                    <!-- Scrollable items listing -->
                    <div class="d-flex flex-column gap-3 mb-4" style="max-height: 250px; overflow-y: auto; padding-right: 5px;">
                        <?php foreach ($cart_items as $item): 
                            $price = getDiscountedPrice($item['price'], $item['discount']);
                        ?>
                            <div class="d-flex align-items-center justify-content-between gap-2 border-bottom pb-2">
                                <div class="d-flex align-items-center gap-2">
                                    <div class="rounded bg-light border p-1" style="width: 45px; height: 45px; display: flex; align-items: center; justify-content: center; flex-shrink: 0;">
                                        <img src="<?php echo getProductImage($item['image'], $item['name']); ?>" alt="" style="max-height: 100%; max-width: 100%; object-fit: contain;">
                                    </div>
                                    <div>
                                        <h6 class="mb-0 fw-semibold text-truncate small" style="max-width: 150px;"><?php echo htmlspecialchars($item['name']); ?></h6>
                                        <span class="text-muted small" style="font-size: 11px;">Qty: <?php echo $item['quantity']; ?> x <?php echo htmlspecialchars($item['weight']); ?></span>
                                    </div>
                                </div>
                                <span class="fw-semibold text-dark small"><?php echo formatPrice($price * $item['quantity']); ?></span>
                            </div>
                        <?php endforeach; ?>
                    </div>

                    <!-- Cost breakdowns -->
                    <div class="d-flex justify-content-between mb-2 small text-muted">
                        <span>Items Subtotal</span>
                        <span class="text-dark fw-medium"><?php echo formatPrice($subtotal); ?></span>
                    </div>

                    <?php if ($coupon_discount > 0): ?>
                        <div class="d-flex justify-content-between mb-2 small text-muted">
                            <span>Coupon Discount (<?php echo htmlspecialchars($coupon_code); ?>)</span>
                            <span class="text-danger fw-medium">- <?php echo formatPrice($coupon_discount); ?></span>
                        </div>
                    <?php endif; ?>

                    <div class="d-flex justify-content-between mb-3 small text-muted">
                        <span>Shipping Charges</span>
                        <span class="text-dark fw-medium"><?php echo $shipping == 0 ? '<span class="text-success fw-bold">FREE</span>' : formatPrice($shipping); ?></span>
                    </div>

                    <hr class="my-3">

                    <div class="d-flex justify-content-between mb-4">
                        <span class="fw-bold">Grand Total</span>
                        <span class="fw-bold text-success fs-5"><?php echo formatPrice($total); ?></span>
                    </div>

                    <!-- Submit Checkout Form button -->
                    <div class="d-grid">
                        <button type="submit" class="btn btn-primary-custom py-2.5 rounded-pill fs-6">
                            <i class="fa-solid fa-lock-open me-1"></i> Place My Order
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </form>
</div>

<script>
// Toggle card payment fields
function togglePaymentFields(radio) {
    const parentCards = $('.payment-method-card');
    parentCards.removeClass('border-success bg-success-subtle').addClass('border-light bg-light');
    
    $(radio).closest('.payment-method-card').removeClass('border-light bg-light').addClass('border-success bg-success-subtle');
    
    if (radio.value === 'Card') {
        $('#cardDetailsBlock').slideDown(400);
        $('#card_number, #card_expiry, #card_cvv').prop('required', true);
    } else {
        $('#cardDetailsBlock').slideUp(400);
        $('#card_number, #card_expiry, #card_cvv').prop('required', false).val('');
    }
}

// Highlight address select card
function highlightAddress(radio) {
    const cards = $('.address-card');
    cards.removeClass('border-success bg-success-subtle').addClass('border-light bg-light');
    $(radio).closest('.address-card').removeClass('border-light bg-light').addClass('border-success bg-success-subtle');
}

// Save Address using inline form post submission
function saveAddressAJAX() {
    const addr = $('#full_address').val().trim();
    const city = $('#city').val().trim();
    const state = $('#state').val().trim();
    const zip = $('#zipcode').val().trim();

    if (addr === '' || city === '' || state === '' || zip === '') {
        alert("Please fill in all shipping address fields.");
        return;
    }

    // Submit a form programmatically
    const form = $('<form action="checkout.php" method="POST">' +
        '<input type="hidden" name="action" value="add_address">' +
        '<input type="hidden" name="full_address" value="' + addr + '">' +
        '<input type="hidden" name="city" value="' + city + '">' +
        '<input type="hidden" name="state" value="' + state + '">' +
        '<input type="hidden" name="zipcode" value="' + zip + '">' +
        '</form>');
    $('body').append(form);
    form.submit();
}
</script>

<?php include __DIR__ . '/../includes/footer.php'; ?>
