// Grocery Mart - Main JavaScript & AJAX Controllers

$(document).ready(function() {
    // Form Validation helper
    const forms = document.querySelectorAll('.needs-validation');
    Array.from(forms).forEach(form => {
        form.addEventListener('submit', event => {
            if (!form.checkValidity()) {
                event.preventDefault();
                event.stopPropagation();
            }
            form.classList.add('was-validated');
        }, false);
    });

    // Initialize Toast Notification container if not already exists
    if ($('.toast-container').length === 0) {
        $('body').append('<div class="toast-container"></div>');
    }
});

/**
 * Show a modern floating toast notification
 * @param {string} message
 * @param {string} type 'success' | 'danger' | 'warning' | 'info'
 */
function showToast(message, type = 'success') {
    const icon = type === 'success' ? 'circle-check' : 'circle-exclamation';
    const alertClass = type === 'success' ? 'alert-success' : 'alert-danger';
    
    const toastId = 'toast_' + Date.now();
    const toastHTML = `
        <div id="${toastId}" class="alert ${alertClass} alert-custom shadow border-0 py-3 px-4 mb-2 fade show" style="min-width: 280px; pointer-events: auto;">
            <div class="d-flex align-items-center justify-content-between gap-3">
                <span><i class="fa-solid fa-${icon} me-2"></i> ${message}</span>
                <button type="button" class="btn-close ms-2" onclick="$('#${toastId}').remove()" style="font-size: 11px;"></button>
            </div>
        </div>
    `;
    
    $('.toast-container').append(toastHTML);
    
    // Auto remove after 4 seconds
    setTimeout(() => {
        $(`#${toastId}`).fadeOut(500, function() {
            $(this).remove();
        });
    }, 4000);
}

/**
 * AJAX - Add Product to Cart
 * @param {number} productId
 * @param {number} quantity
 */
function addToCart(productId, quantity = 1) {
    $.ajax({
        url: 'cart.php',
        method: 'POST',
        data: {
            action: 'add',
            product_id: productId,
            quantity: quantity
        },
        dataType: 'json',
        success: function(response) {
            if (response.success) {
                showToast(response.message, 'success');
                // Update badge count
                updateCartBadge(response.cart_count);
            } else {
                showToast(response.message || 'Failed to add item to cart', 'danger');
                if (response.redirect) {
                    setTimeout(() => {
                        window.location.href = response.redirect;
                    }, 1000);
                }
            }
        },
        error: function(xhr, status, error) {
            console.error('Cart AJAX Error:', error);
            showToast('Network error, please try again.', 'danger');
        }
    });
}

/**
 * AJAX - Toggle Wishlist Item (Add/Remove)
 * @param {number} productId
 * @param {HTMLElement} element
 */
function toggleWishlist(productId, element) {
    $.ajax({
        url: 'wishlist.php',
        method: 'POST',
        data: {
            action: 'toggle',
            product_id: productId
        },
        dataType: 'json',
        success: function(response) {
            if (response.success) {
                showToast(response.message, 'success');
                if (response.status === 'added') {
                    $(element).addClass('active').find('i').removeClass('fa-regular').addClass('fa-solid');
                } else {
                    $(element).removeClass('active').find('i').removeClass('fa-solid').addClass('fa-regular');
                    // If we are currently on the wishlist page, remove the product card from the UI
                    if (window.location.pathname.indexOf('wishlist.php') !== -1) {
                        $(element).closest('.col-md-3, .col-sm-6').fadeOut(500, function() {
                            $(this).remove();
                            if ($('.wishlist-grid').children(':visible').length === 0) {
                                window.location.reload();
                            }
                        });
                    }
                }
                
                // Update wishlist badge if count is available
                if (response.wishlist_count !== undefined) {
                    updateWishlistBadge(response.wishlist_count);
                }
            } else {
                showToast(response.message || 'Failed to update wishlist', 'danger');
                if (response.redirect) {
                    setTimeout(() => {
                        window.location.href = response.redirect;
                    }, 1000);
                }
            }
        },
        error: function(xhr, status, error) {
            console.error('Wishlist AJAX Error:', error);
            showToast('Network error, please try again.', 'danger');
        }
    });
}

/**
 * Update the navbar shopping cart badge count
 * @param {number} count
 */
function updateCartBadge(count) {
    const badge = $('#cart-badge-count');
    if (count > 0) {
        if (badge.length > 0) {
            badge.text(count).show();
        } else {
            // Append badge if not present
            $('a[href="cart.php"]').append(`<span class="badge-badge" id="cart-badge-count">${count}</span>`);
        }
    } else {
        badge.hide();
    }
}

/**
 * Update the navbar wishlist badge count
 * @param {number} count
 */
function updateWishlistBadge(count) {
    const badge = $('a[href="wishlist.php"]').find('.badge-badge');
    if (count > 0) {
        if (badge.length > 0) {
            badge.text(count).show();
        } else {
            $('a[href="wishlist.php"]').append(`<span class="badge-badge">${count}</span>`);
        }
    } else {
        badge.hide();
    }
}
