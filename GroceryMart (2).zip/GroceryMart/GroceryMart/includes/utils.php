<?php
/**
 * Utility functions for Grocery Mart
 */

/**
 * Format price in INR (Rupees)
 * @param float $price
 * @return string
 */
function formatPrice($price) {
    return '₹' . number_format($price, 2);
}

/**
 * Calculate the discounted price
 * @param float $price
 * @param float $discountPercentage
 * @return float
 */
function getDiscountedPrice($price, $discountPercentage) {
    if ($discountPercentage <= 0) {
        return $price;
    }
    return $price * (1 - ($discountPercentage / 100));
}

/**
 * Get Product Image path or Unsplash premium fallback
 * @param string|null $imageName
 * @param string $productName
 * @return string Image URL
 */
function getProductImage($imageName, $productName = '') {
    // Map common seed products to beautiful Unsplash images
    $fallbacks = [
        'apple.png' => 'https://images.unsplash.com/photo-1560806887-1e4cd0b6cbd6?auto=format&fit=crop&w=400&q=80', // Apple
        'banana.png' => 'https://images.unsplash.com/photo-1571771894821-ce9b6c11b08e?auto=format&fit=crop&w=400&q=80', // Banana
        'mango.png' => 'https://images.unsplash.com/photo-1553279768-865429fa0078?auto=format&fit=crop&w=400&q=80', // Mango
        'potato.png' => 'https://images.unsplash.com/photo-1518977676601-b53f82aba655?auto=format&fit=crop&w=400&q=80', // Potato
        'tomato.png' => 'https://images.unsplash.com/photo-1595855759920-86582396756a?auto=format&fit=crop&w=400&q=80', // Tomato
        'onion.png' => 'https://images.unsplash.com/photo-1508747703725-719ae257c26a?auto=format&fit=crop&w=400&q=80', // Onion
        'milk.png' => 'https://images.unsplash.com/photo-1550583724-b2692b85b150?auto=format&fit=crop&w=400&q=80', // Milk
        'butter.png' => 'https://images.unsplash.com/photo-1589985270826-4b7bb135bc9d?auto=format&fit=crop&w=400&q=80', // Butter
        'paneer.png' => 'https://images.unsplash.com/photo-1631452180519-c014fe946bc7?auto=format&fit=crop&w=400&q=80', // Paneer
        'bread.png' => 'https://images.unsplash.com/photo-1509440159596-0249088772ff?auto=format&fit=crop&w=400&q=80', // Bread
        'cookies.png' => 'https://images.unsplash.com/photo-1499636136210-6f4ee915583e?auto=format&fit=crop&w=400&q=80', // Cookies
        'orange_juice.png' => 'https://images.unsplash.com/photo-1621506289937-a8e4df240d0b?auto=format&fit=crop&w=400&q=80', // Juice
        'tea.png' => 'https://images.unsplash.com/photo-1576092768241-dec231879fc3?auto=format&fit=crop&w=400&q=80', // Tea
        'chips.png' => 'https://images.unsplash.com/photo-1566478989037-eec170784d0b?auto=format&fit=crop&w=400&q=80', // Chips
        'cashews.png' => 'https://images.unsplash.com/photo-1508061253366-f7da158b6d46?auto=format&fit=crop&w=400&q=80', // Cashews
        'rice.png' => 'https://images.unsplash.com/photo-1586201375761-83865001e31c?auto=format&fit=crop&w=400&q=80', // Rice
        'oil.png' => 'https://images.unsplash.com/photo-1474979266404-7eaacbcd87c5?auto=format&fit=crop&w=400&q=80', // Cooking Oil
        'dishwash.png' => 'https://images.unsplash.com/photo-1607006342465-15a05b3dd84d?auto=format&fit=crop&w=400&q=80', // Dishwash
        'floor_cleaner.png' => 'https://images.unsplash.com/photo-1581578731548-c64695cc6952?auto=format&fit=crop&w=400&q=80', // Floor cleaner
    ];

    if ($imageName && isset($fallbacks[$imageName])) {
        return $fallbacks[$imageName];
    }

    if ($imageName && file_exists(__DIR__ . '/../assets/uploads/products/' . $imageName)) {
        return '/GroceryMart/GroceryMart/assets/uploads/products/' . $imageName;
    }

    return 'https://images.unsplash.com/photo-1542838132-92c53300491e?auto=format&fit=crop&w=400&q=80';
}

/**
 * Get Category Image path or Unsplash premium fallback
 * @param string|null $imageName
 * @param string $categoryName
 * @return string Image URL
 */
function getCategoryImage($imageName, $categoryName = '') {
    // 1. Check if local file exists
    if ($imageName && file_exists(__DIR__ . '/../assets/uploads/categories/' . $imageName)) {
        return '/GroceryMart/GroceryMart/assets/uploads/categories/' . $imageName;
    }

    $cName   = strtolower(trim($categoryName));
    $imgName = strtolower(trim($imageName ?? ''));

    // 2. Keyword-based matching for high-res Unsplash photos
    if (str_contains($cName, 'fruit') || str_contains($imgName, 'fruit')) {
        return 'https://images.unsplash.com/photo-1619546813926-a78fa6372cd2?auto=format&fit=crop&w=400&q=80';
    }
    if (str_contains($cName, 'veg') || str_contains($imgName, 'veg')) {
        return 'https://images.unsplash.com/photo-1540420773420-3366772f4999?auto=format&fit=crop&w=400&q=80';
    }
    if (str_contains($cName, 'dairy') || str_contains($cName, 'egg') || str_contains($cName, 'milk') || str_contains($imgName, 'dairy')) {
        return 'https://images.unsplash.com/photo-1563636619-e9143da7973b?auto=format&fit=crop&w=400&q=80';
    }
    if (str_contains($cName, 'baker') || str_contains($cName, 'bread') || str_contains($imgName, 'baker')) {
        return 'https://images.unsplash.com/photo-1509440159596-0249088772ff?auto=format&fit=crop&w=400&q=80';
    }
    if (str_contains($cName, 'beverag') || str_contains($cName, 'drink') || str_contains($cName, 'juice') || str_contains($imgName, 'beverag')) {
        return 'https://images.unsplash.com/photo-1527960656366-ee2a999e32e6?auto=format&fit=crop&w=400&q=80';
    }
    if (str_contains($cName, 'snack') || str_contains($cName, 'munch') || str_contains($cName, 'biscuit') || str_contains($imgName, 'snack')) {
        return 'https://images.unsplash.com/photo-1599490659213-e2b9527bc087?auto=format&fit=crop&w=400&q=80';
    }
    if (str_contains($cName, 'staple') || str_contains($cName, 'spice') || str_contains($cName, 'grain') || str_contains($cName, 'rice') || str_contains($imgName, 'staple')) {
        return 'https://images.unsplash.com/photo-1590080875515-8a3a8dc5735e?auto=format&fit=crop&w=400&q=80';
    }
    if (str_contains($cName, 'clean') || str_contains($cName, 'house') || str_contains($imgName, 'clean')) {
        return 'https://images.unsplash.com/photo-1563453392212-326f5e854473?auto=format&fit=crop&w=400&q=80';
    }

    // Default premium fallback
    return 'https://images.unsplash.com/photo-1542838132-92c53300491e?auto=format&fit=crop&w=400&q=80';
}
