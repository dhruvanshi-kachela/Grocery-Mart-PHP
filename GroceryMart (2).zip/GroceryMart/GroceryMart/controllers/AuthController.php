<?php
require_once __DIR__ . '/../models/User.php';
require_once __DIR__ . '/../models/Admin.php';

class AuthController {
    private $userModel;
    private $adminModel;

    public function __construct() {
        $this->userModel = new User();
        $this->adminModel = new Admin();
    }

    /**
     * Handle Customer Registration
     */
    public function register() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $name = trim($_POST['name'] ?? '');
            $email = trim($_POST['email'] ?? '');
            $mobile = trim($_POST['mobile'] ?? '');
            $password = $_POST['password'] ?? '';
            $confirm_password = $_POST['confirm_password'] ?? '';

            // Validation rules
            if (empty($name) || empty($email) || empty($mobile) || empty($password)) {
                $_SESSION['error'] = "All fields are required.";
                return;
            }

            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                $_SESSION['error'] = "Invalid email format.";
                return;
            }

            if (strlen($password) < 8) {
                $_SESSION['error'] = "Password must be at least 8 characters long.";
                return;
            }

            if ($password !== $confirm_password) {
                $_SESSION['error'] = "Passwords do not match.";
                return;
            }

            if (!preg_match('/^[0-9]{10}$/', $mobile)) {
                $_SESSION['error'] = "Mobile number must be exactly 10 digits.";
                return;
            }

            if ($this->userModel->emailExists($email)) {
                $_SESSION['error'] = "Email is already registered.";
                return;
            }

            // Create User
            $userId = $this->userModel->create($name, $email, $mobile, $password);
            if ($userId) {
                $_SESSION['success'] = "Registration successful! Please log in.";
                header("Location: login.php");
                exit();
            } else {
                $_SESSION['error'] = "Something went wrong. Please try again.";
            }
        }
    }

    /**
     * Handle Customer Login
     */
    public function login() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $email = trim($_POST['email'] ?? '');
            $password = $_POST['password'] ?? '';
            $remember = isset($_POST['remember']);

            if (empty($email) || empty($password)) {
                $_SESSION['error'] = "Email and Password are required.";
                return;
            }

            $user = $this->userModel->findByEmail($email);
            if ($user && password_verify($password, $user['password'])) {
                // Successful login
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['user_name'] = $user['name'];
                $_SESSION['user_email'] = $user['email'];
                $_SESSION['user_role'] = $user['role'];

                // Merge Session Cart if any guest items exist
                if (isset($_SESSION['cart']) && !empty($_SESSION['cart'])) {
                    require_once __DIR__ . '/../models/Cart.php';
                    $cartObj = new Cart();
                    $cartObj->mergeSessionCart($user['id'], $_SESSION['cart']);
                    unset($_SESSION['cart']);
                }

                // Handle Remember Me (optional university enhancement)
                if ($remember) {
                    setcookie('remember_user_email', $email, time() + (86400 * 30), "/"); // 30 days
                } else {
                    if (isset($_cookie['remember_user_email'])) {
                        setcookie('remember_user_email', '', time() - 3600, "/");
                    }
                }

                $_SESSION['success'] = "Welcome back, " . $user['name'] . "!";
                
                // If it is admin, redirect to admin dashboard, else home page
                if ($user['role'] === 'admin') {
                    header("Location: admin/dashboard.php");
                } else {
                    header("Location: index.php");
                }
                exit();
            } else {
                $_SESSION['error'] = "Invalid Email or Password.";
            }
        }
    }

    /**
     * Handle Admin-Specific Login (if they log in via the separate admin panel)
     */
    public function adminLogin() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $email = trim($_POST['email'] ?? '');
            $password = $_POST['password'] ?? '';

            if (empty($email) || empty($password)) {
                $_SESSION['error'] = "Email and Password are required.";
                return;
            }

            // Check in separate admins table
            $admin = $this->adminModel->findByEmail($email);
            if ($admin && password_verify($password, $admin['password'])) {
                $_SESSION['admin_id'] = $admin['id'];
                $_SESSION['admin_name'] = $admin['name'];
                $_SESSION['admin_email'] = $admin['email'];
                $_SESSION['admin_role'] = 'admin';

                $_SESSION['success'] = "Admin login successful!";
                header("Location: dashboard.php"); // From within admin/ directory
                exit();
            } else {
                $_SESSION['error'] = "Invalid Admin Credentials.";
            }
        }
    }

    /**
     * Handle Logout
     */
    public function logout() {
        // Clear customer or admin sessions
        $_SESSION = [];
        if (ini_get("session.use_cookies")) {
            $params = session_get_cookie_params();
            setcookie(session_name(), '', time() - 42000,
                $params["path"], $params["domain"],
                $params["secure"], $params["httponly"]
            );
        }
        session_destroy();
        
        session_start();
        $_SESSION['success'] = "You have been logged out successfully.";
        header("Location: landing.php");
        exit();
    }

    /**
     * Handle Admin Logout
     */
    public function adminLogout() {
        unset($_SESSION['admin_id']);
        unset($_SESSION['admin_name']);
        unset($_SESSION['admin_email']);
        unset($_SESSION['admin_role']);

        $_SESSION['success'] = "Admin logged out successfully.";
        header("Location: login.php"); // admin/login.php
        exit();
    }

    /**
     * Auth Guard for customers
     */
    public static function checkAuth() {
        if (session_status() == PHP_SESSION_NONE) {
            session_start();
        }
        if (!isset($_SESSION['user_id'])) {
            $_SESSION['error'] = "Please log in to access this page.";
            header("Location: login.php");
            exit();
        }
    }

    /**
     * Auth Guard for admins
     */
    public static function checkAdminAuth() {
        if (session_status() == PHP_SESSION_NONE) {
            session_start();
        }
        // Accepts either a user model admin session or separate admin table session
        if (!isset($_SESSION['admin_id']) && (!isset($_SESSION['user_role']) || $_SESSION['user_role'] !== 'admin')) {
            $_SESSION['error'] = "Admin access required.";
            header("Location: login.php");
            exit();
        }
    }
}
