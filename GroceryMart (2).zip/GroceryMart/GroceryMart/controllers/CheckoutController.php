<?php
require_once __DIR__ . '/../models/Cart.php';
require_once __DIR__ . '/../models/Address.php';
require_once __DIR__ . '/../models/Order.php';
require_once __DIR__ . '/../models/Coupon.php';
require_once __DIR__ . '/../includes/utils.php';
require_once __DIR__ . '/AuthController.php';

class CheckoutController {
    private $cartModel;
    private $addressModel;
    private $orderModel;
    private $couponModel;

    public function __construct() {
        $this->cartModel = new Cart();
        $this->addressModel = new Address();
        $this->orderModel = new Order();
        $this->couponModel = new Coupon();
    }

    /**
     * Render Checkout page and process Order Placement
     */
    public function checkout() {
        // Enforce user authentication
        AuthController::checkAuth();
        $userId = $_SESSION['user_id'];

        // Retrieve cart items
        $cart_items = $this->cartModel->getItems($userId);
        if (empty($cart_items)) {
            $_SESSION['error'] = "Your cart is empty. Please add items before checking out.";
            header("Location: cart.php");
            exit();
        }

        // Calculate checkout pricing
        $subtotal = 0;
        foreach ($cart_items as $item) {
            $subtotal += (getDiscountedPrice($item['price'], $item['discount']) * $item['quantity']);
        }
        $shipping = ($subtotal >= 499.00) ? 0.00 : 40.00;

        $coupon_discount = 0.00;
        $coupon_code = '';
        if (isset($_SESSION['applied_coupon'])) {
            $coupon_code = $_SESSION['applied_coupon']['code'];
            $coupon = $this->couponModel->findByCode($coupon_code);
            if ($coupon && $this->couponModel->validate($coupon, $subtotal)['valid']) {
                $coupon_discount = floatval($coupon['discount']);
            }
        }
        $total = ($subtotal + $shipping) - $coupon_discount;
        if ($total < 0) $total = 0;

        // Process Address Book Add via AJAX/POST during checkout
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'add_address') {
            $full_address = trim($_POST['full_address'] ?? '');
            $city = trim($_POST['city'] ?? '');
            $state = trim($_POST['state'] ?? '');
            $zipcode = trim($_POST['zipcode'] ?? '');

            if (!empty($full_address) && !empty($city) && !empty($state) && !empty($zipcode)) {
                $addressId = $this->addressModel->add($userId, $full_address, $city, $state, $zipcode);
                if ($addressId) {
                    $_SESSION['success'] = "Shipping address added successfully!";
                } else {
                    $_SESSION['error'] = "Failed to add address.";
                }
            } else {
                $_SESSION['error'] = "Please fill in all address fields.";
            }
            header("Location: checkout.php");
            exit();
        }

        // Process Order Submission
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['place_order'])) {
            $addressId = intval($_POST['address_id'] ?? 0);
            $paymentMethod = $_POST['payment_method'] ?? 'COD';

            if ($addressId <= 0) {
                $_SESSION['error'] = "Please select a shipping address.";
                header("Location: checkout.php");
                exit();
            }

            // Verify address belongs to user
            $address = $this->addressModel->findById($addressId, $userId);
            if (!$address) {
                $_SESSION['error'] = "Invalid shipping address.";
                header("Location: checkout.php");
                exit();
            }

            // Validate payment method
            $allowedMethods = ['COD', 'Card'];
            if (!in_array($paymentMethod, $allowedMethods)) {
                $_SESSION['error'] = "Invalid payment method selected.";
                header("Location: checkout.php");
                exit();
            }

            // Set payment status based on method
            $paymentStatus = ($paymentMethod === 'Card') ? 'Paid' : 'Pending';

            // Create the order inside transaction
            $orderId = $this->orderModel->create($userId, $addressId, $total, $coupon_discount, $paymentMethod, $paymentStatus, $cart_items);
            
            if ($orderId) {
                // Clear cart in database
                $this->cartModel->clear($userId);
                // Clear applied coupon from session
                unset($_SESSION['applied_coupon']);
                
                // Send order confirmation email if enabled
                if (function_exists('sendOrderConfirmationEmail')) {
                    sendOrderConfirmationEmail($orderId, $userId);
                }

                $_SESSION['success'] = "Order placed successfully! Thank you for shopping with us.";
                header("Location: checkout.php?success=1&order_id=" . $orderId);
                exit();
            } else {
                // Error description was already saved in session inside orderModel->create
                header("Location: checkout.php");
                exit();
            }
        }

        // Fetch saved shipping addresses
        $addresses = $this->addressModel->getByUser($userId);

        // Load view
        include __DIR__ . '/../views/checkout.php';
    }

    /**
     * Render Checkout Success / Order Confirmation screen
     */
    public function success() {
        AuthController::checkAuth();
        $userId = $_SESSION['user_id'];
        
        $orderId = isset($_GET['order_id']) ? intval($_GET['order_id']) : 0;
        if ($orderId <= 0) {
            header("Location: index.php");
            exit();
        }

        // Retrieve order details and verify ownership
        $order = $this->orderModel->findByIdAndUser($orderId, $userId);
        if (!$order) {
            $_SESSION['error'] = "Order not found.";
            header("Location: index.php");
            exit();
        }

        $orderItems = $this->orderModel->getOrderItems($orderId);

        include __DIR__ . '/../views/order-success.php';
    }
}
